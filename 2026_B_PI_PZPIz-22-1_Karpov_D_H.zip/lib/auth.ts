import { cookies } from "next/headers";
import { SessionsDB, UsersDB, type User } from "./db";
import crypto from "crypto";

export const SESSION_COOKIE = "vtc_session";
export const SESSION_DURATION_DAYS = 30;

export function generateToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export function generateId(): string {
  return crypto.randomBytes(16).toString("hex");
}

export async function createSession(userId: string): Promise<string> {
  const token = generateToken();
  const now = new Date();
  const expires = new Date(now);
  expires.setDate(expires.getDate() + SESSION_DURATION_DAYS);

  SessionsDB.create({
    token,
    userId,
    createdAt: now.toISOString(),
    expiresAt: expires.toISOString(),
  });

  return token;
}

export async function getSessionUser(): Promise<User | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE)?.value;
    if (!token) return null;

    const session = SessionsDB.findByToken(token);
    if (!session) return null;

    if (new Date(session.expiresAt) < new Date()) {
      SessionsDB.delete(token);
      return null;
    }

    return UsersDB.findById(session.userId) ?? null;
  } catch {
    return null;
  }
}

export async function deleteSession(): Promise<void> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(SESSION_COOKIE)?.value;
    if (token) SessionsDB.delete(token);
  } catch {}
}
