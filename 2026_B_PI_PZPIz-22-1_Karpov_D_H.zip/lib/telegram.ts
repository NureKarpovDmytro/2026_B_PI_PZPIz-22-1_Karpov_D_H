// lib/telegram.ts

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const API_BASE = `https://api.telegram.org/bot${BOT_TOKEN}`;

export async function sendTelegramMessage(
  chatId: string,
  text: string
): Promise<boolean> {
  if (!BOT_TOKEN || !chatId) return false;
  try {
    const res = await fetch(`${API_BASE}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function setWebhook(url: string): Promise<boolean> {
  if (!BOT_TOKEN) return false;
  try {
    const res = await fetch(
      `${API_BASE}/setWebhook?url=${encodeURIComponent(url)}`
    );
    const data = await res.json();
    return data.ok;
  } catch {
    return false;
  }
}

export async function deleteWebhook(): Promise<boolean> {
  if (!BOT_TOKEN) return false;
  const res = await fetch(`${API_BASE}/deleteWebhook`);
  return res.ok;
}
