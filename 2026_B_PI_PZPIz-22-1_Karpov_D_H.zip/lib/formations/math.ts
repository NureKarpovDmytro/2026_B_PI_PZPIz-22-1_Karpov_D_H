// lib/formations/math.ts

import type { Candle } from "./types";

export function calcATR(c: Candle[], p = 14): number {
  if (c.length < p + 1) return (c[c.length - 1]?.high - c[c.length - 1]?.low) || 0.001;
  const slice = c.slice(-p - 1);
  const trs = slice.map((x, i, a) =>
    i === 0 ? x.high - x.low
      : Math.max(x.high - x.low, Math.abs(x.high - a[i - 1].close), Math.abs(x.low - a[i - 1].close))
  );
  return trs.slice(1).reduce((a, b) => a + b, 0) / p;
}

export function calcSMAVol(c: Candle[], p = 20): number {
  const s = c.slice(-p);
  return s.reduce((a, x) => a + x.volume, 0) / s.length || 1;
}

export function getSwingHighs(c: Candle[], lb = 5): { idx: number; price: number }[] {
  const res: { idx: number; price: number }[] = [];
  for (let i = lb; i < c.length - lb; i++) {
    let isHigh = true;
    for (let j = 1; j <= lb; j++) {
      if (c[i].high <= c[i - j].high || c[i].high <= c[i + j].high) { isHigh = false; break; }
    }
    if (isHigh) res.push({ idx: i, price: c[i].high });
  }
  return res;
}

export function getSwingLows(c: Candle[], lb = 5): { idx: number; price: number }[] {
  const res: { idx: number; price: number }[] = [];
  for (let i = lb; i < c.length - lb; i++) {
    let isLow = true;
    for (let j = 1; j <= lb; j++) {
      if (c[i].low >= c[i - j].low || c[i].low >= c[i + j].low) { isLow = false; break; }
    }
    if (isLow) res.push({ idx: i, price: c[i].low });
  }
  return res;
}
