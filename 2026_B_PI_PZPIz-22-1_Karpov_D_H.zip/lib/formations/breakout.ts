// lib/formations/breakout.ts
import type { Candle, FormationResult, FormationAnnotation, Lang } from "./types";
import { calcATR, calcSMAVol, getSwingHighs, getSwingLows } from "./math";
import { tf } from "./translations";

export function detectBreakout(
  candles: Candle[], symbol: string, exchange: string, interval: string,
  chartCandles: Candle[], lang: Lang = "ru"
): FormationResult[] {
  const results: FormationResult[] = [];
  const n = candles.length;
  if (n < 150) return results; 

  const atr = calcATR(candles);
  const now = Date.now();
  
  const scanDepth = 1000; 
  const startIndex = Math.max(0, n - scanDepth);

  const SH = getSwingHighs(candles, 5).filter(p => p.idx >= startIndex);
  const SL = getSwingLows(candles, 5).filter(p => p.idx >= startIndex);

  const push = (dir: "bull"|"bear", str: 1|2|3, desc: string, ann: FormationAnnotation[], customCandles?: Candle[]) =>
    results.push({ symbol, exchange, interval, type: "breakout", direction: dir, strength: str, description: desc, timestamp: now, candles: customCandles || chartCandles, allCandles: candles, annotations: ann });

  const tol = atr * 0.4; 

  const resistanceClusters: { maxPrice: number, minPrice: number, firstIdx: number, lastIdx: number, touches: number[], exactPrices: number[] }[] = [];
  
  for (const sh of SH) {
    let added = false;
    for (const cluster of resistanceClusters) {
      if (sh.price >= cluster.minPrice - tol && sh.price <= cluster.maxPrice + tol) {
        cluster.touches.push(sh.idx);
        cluster.exactPrices.push(sh.price);
        cluster.maxPrice = Math.max(cluster.maxPrice, sh.price);
        cluster.minPrice = Math.min(cluster.minPrice, sh.price);
        cluster.lastIdx = Math.max(cluster.lastIdx, sh.idx);
        cluster.firstIdx = Math.min(cluster.firstIdx, sh.idx);
        added = true;
        break;
      }
    }
    if (!added) {
      resistanceClusters.push({
        maxPrice: sh.price, minPrice: sh.price, firstIdx: sh.idx, lastIdx: sh.idx, touches: [sh.idx], exactPrices: [sh.price]
      });
    }
  }

  for (const cluster of resistanceClusters) {
    if (cluster.touches.length < 2) continue; 
    if (cluster.lastIdx - cluster.firstIdx < 15) continue; 

    if (cluster.maxPrice - cluster.minPrice > atr * 1.0) continue;

    let isClean = true;
    let wickPierces = 0;

    for (let i = cluster.firstIdx; i < n - 2; i++) {
      if (candles[i].close > cluster.maxPrice + atr * 0.1) {
        isClean = false;
        break;
      }
      if (candles[i].high > cluster.maxPrice + atr * 0.3) {
        wickPierces++;
      }
    }

    if (!isClean || wickPierces > 3) continue;

    const currentC = candles[n - 1];
    const distanceToLevel = cluster.maxPrice - currentC.close;
    
    if (distanceToLevel <= atr * 5 && currentC.close <= cluster.maxPrice + atr * 0.5) {
      let str: 1|2|3 = 1;
      let desc = tf(lang, "approachResistance", { price: cluster.maxPrice.toFixed(4), touches: cluster.touches.length });
      
      if (distanceToLevel <= atr * 1.5) {
        str = 2;
        desc = tf(lang, "squeezeResistance", { price: cluster.maxPrice.toFixed(4) });
      }
      if (currentC.close > cluster.maxPrice) {
        str = 3;
        desc = tf(lang, "breakoutResistance", { price: cluster.maxPrice.toFixed(4) });
      }

      const anns: FormationAnnotation[] = [];
      const uniquePrices = Array.from(new Set(cluster.exactPrices));
      
      const startTime = candles[cluster.firstIdx].time;
      const endTime = currentC.time;

      for (const p of uniquePrices) {
        // @ts-ignore
        anns.push({ type: "hline", color: "rgba(156, 163, 175, 0.4)", price: p, time1: startTime, time2: endTime }); 
      }
      // @ts-ignore
      anns.push({ type: "hline", color: "rgba(34, 197, 94, 0.9)", price: cluster.maxPrice, time1: startTime, time2: endTime }); 
      // @ts-ignore
      anns.push({ type: "hzone", color: "rgba(34, 197, 94, 0.1)", price: cluster.minPrice, price2: cluster.maxPrice, time1: startTime, time2: endTime });
      
      anns.push({ type: "arrow", color: "#22c55e", time: currentC.time, direction: "up" });

      const startVisibleIdx = Math.max(0, cluster.firstIdx - 30);
      const formationCandles = candles.slice(startVisibleIdx);

      push("bull", str, desc, anns, formationCandles);
    }
  }


  const supportClusters: { maxPrice: number, minPrice: number, firstIdx: number, lastIdx: number, touches: number[], exactPrices: number[] }[] = [];
  
  for (const sl of SL) {
    let added = false;
    for (const cluster of supportClusters) {
      if (sl.price >= cluster.minPrice - tol && sl.price <= cluster.maxPrice + tol) {
        cluster.touches.push(sl.idx);
        cluster.exactPrices.push(sl.price);
        cluster.maxPrice = Math.max(cluster.maxPrice, sl.price);
        cluster.minPrice = Math.min(cluster.minPrice, sl.price);
        cluster.lastIdx = Math.max(cluster.lastIdx, sl.idx);
        cluster.firstIdx = Math.min(cluster.firstIdx, sl.idx);
        added = true;
        break;
      }
    }
    if (!added) {
      supportClusters.push({
        maxPrice: sl.price, minPrice: sl.price, firstIdx: sl.idx, lastIdx: sl.idx, touches: [sl.idx], exactPrices: [sl.price]
      });
    }
  }

  for (const cluster of supportClusters) {
    if (cluster.touches.length < 2) continue;
    if (cluster.lastIdx - cluster.firstIdx < 15) continue;

    if (cluster.maxPrice - cluster.minPrice > atr * 1.0) continue;

    let isClean = true;
    let wickPierces = 0;

    for (let i = cluster.firstIdx; i < n - 2; i++) {
      if (candles[i].close < cluster.minPrice - atr * 0.1) {
        isClean = false;
        break;
      }
      if (candles[i].low < cluster.minPrice - atr * 0.3) {
        wickPierces++;
      }
    }

    if (!isClean || wickPierces > 3) continue;

    const currentC = candles[n - 1];
    const distanceToLevel = currentC.close - cluster.minPrice;
    
    if (distanceToLevel <= atr * 5 && currentC.close >= cluster.minPrice - atr * 0.5) {
      let str: 1|2|3 = 1;
      let desc = tf(lang, "approachSupport", { price: cluster.minPrice.toFixed(4), touches: cluster.touches.length });
      
      if (distanceToLevel <= atr * 1.5) {
        str = 2;
        desc = tf(lang, "squeezeSupport", { price: cluster.minPrice.toFixed(4) });
      }
      if (currentC.close < cluster.minPrice) {
        str = 3;
        desc = tf(lang, "breakoutSupport", { price: cluster.minPrice.toFixed(4) });
      }

      const anns: FormationAnnotation[] = [];
      const uniquePrices = Array.from(new Set(cluster.exactPrices));
      
      const startTime = candles[cluster.firstIdx].time;
      const endTime = currentC.time;

      for (const p of uniquePrices) {
        // @ts-ignore
        anns.push({ type: "hline", color: "rgba(156, 163, 175, 0.4)", price: p, time1: startTime, time2: endTime }); 
      }
      // @ts-ignore
      anns.push({ type: "hline", color: "rgba(239, 68, 68, 0.9)", price: cluster.minPrice, time1: startTime, time2: endTime }); 
      // @ts-ignore
      anns.push({ type: "hzone", color: "rgba(239, 68, 68, 0.1)", price: cluster.minPrice, price2: cluster.maxPrice, time1: startTime, time2: endTime });
      
      anns.push({ type: "arrow", color: "#ef4444", time: currentC.time, direction: "down" });

      const startVisibleIdx = Math.max(0, cluster.firstIdx - 30);
      const formationCandles = candles.slice(startVisibleIdx);

      push("bear", str, desc, anns, formationCandles);
    }
  }

  return results;
}