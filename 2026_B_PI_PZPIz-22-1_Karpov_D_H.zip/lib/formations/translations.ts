// lib/formations/translations.ts

import type { Lang } from "./types";

type Dict = Record<Lang, string>;

const DICT: Record<string, Dict> = {
  // ── breakout.ts ──────────────────────────────────────────────
  approachResistance: {
    ru: "Подход к сопр. {price} (касаний: {touches})",
    en: "Approaching resistance {price} (touches: {touches})",
    uk: "Підхід до опору {price} (дотиків: {touches})",
    zh: "接近阻力位 {price}（触及次数：{touches}）",
    es: "Acercamiento a resistencia {price} (toques: {touches})",
    pt: "Aproximação da resistência {price} (toques: {touches})",
  },
  squeezeResistance: {
    ru: "Поджатие к сопр. {price}",
    en: "Squeezing toward resistance {price}",
    uk: "Стиснення до опору {price}",
    zh: "逼近阻力位 {price}",
    es: "Compresión hacia resistencia {price}",
    pt: "Compressão em direção à resistência {price}",
  },
  breakoutResistance: {
    ru: "🔥 Идет ПРОБОЙ сопр. {price}",
    en: "🔥 BREAKOUT in progress at resistance {price}",
    uk: "🔥 Триває ПРОБИТТЯ опору {price}",
    zh: "🔥 正在突破阻力位 {price}",
    es: "🔥 RUPTURA en curso de resistencia {price}",
    pt: "🔥 ROMPIMENTO em curso da resistência {price}",
  },
  approachSupport: {
    ru: "Подход к подд. {price} (касаний: {touches})",
    en: "Approaching support {price} (touches: {touches})",
    uk: "Підхід до підтримки {price} (дотиків: {touches})",
    zh: "接近支撑位 {price}（触及次数：{touches}）",
    es: "Acercamiento a soporte {price} (toques: {touches})",
    pt: "Aproximação do suporte {price} (toques: {touches})",
  },
  squeezeSupport: {
    ru: "Поджатие к подд. {price}",
    en: "Squeezing toward support {price}",
    uk: "Стиснення до підтримки {price}",
    zh: "逼近支撑位 {price}",
    es: "Compresión hacia soporte {price}",
    pt: "Compressão em direção ao suporte {price}",
  },
  breakoutSupport: {
    ru: "🔥 Идет ПРОБОЙ подд. {price}",
    en: "🔥 BREAKOUT in progress at support {price}",
    uk: "🔥 Триває ПРОБИТТЯ підтримки {price}",
    zh: "🔥 正在跌破支撑位 {price}",
    es: "🔥 RUPTURA en curso de soporte {price}",
    pt: "🔥 ROMPIMENTO em curso do suporte {price}",
  },

  // ── bounce.ts ────────────────────────────────────────────────
  sweepResistance: {
    ru: "Закол сопр. {price} | касаний: {touches} | фитиль: {pct}% ATR",
    en: "Resistance sweep {price} | touches: {touches} | wick: {pct}% ATR",
    uk: "Виніс опору {price} | дотиків: {touches} | ґніт: {pct}% ATR",
    zh: "扫出阻力位 {price} | 触及：{touches} | 影线：{pct}% ATR",
    es: "Barrido de resistencia {price} | toques: {touches} | mecha: {pct}% ATR",
    pt: "Varredura da resistência {price} | toques: {touches} | pavio: {pct}% ATR",
  },
  approachResistanceDist: {
    ru: "Подход к сопр. {price} | касаний: {touches} | дистанция: {dist} ATR",
    en: "Approaching resistance {price} | touches: {touches} | distance: {dist} ATR",
    uk: "Підхід до опору {price} | дотиків: {touches} | дистанція: {dist} ATR",
    zh: "接近阻力位 {price} | 触及：{touches} | 距离：{dist} ATR",
    es: "Acercamiento a resistencia {price} | toques: {touches} | distancia: {dist} ATR",
    pt: "Aproximação da resistência {price} | toques: {touches} | distância: {dist} ATR",
  },
  sweepSupport: {
    ru: "Закол подд. {price} | касаний: {touches} | фитиль: {pct}% ATR",
    en: "Support sweep {price} | touches: {touches} | wick: {pct}% ATR",
    uk: "Виніс підтримки {price} | дотиків: {touches} | ґніт: {pct}% ATR",
    zh: "扫出支撑位 {price} | 触及：{touches} | 影线：{pct}% ATR",
    es: "Barrido de soporte {price} | toques: {touches} | mecha: {pct}% ATR",
    pt: "Varredura do suporte {price} | toques: {touches} | pavio: {pct}% ATR",
  },
  approachSupportDist: {
    ru: "Подход к подд. {price} | касаний: {touches} | дистанция: {dist} ATR",
    en: "Approaching support {price} | touches: {touches} | distance: {dist} ATR",
    uk: "Підхід до підтримки {price} | дотиків: {touches} | дистанція: {dist} ATR",
    zh: "接近支撑位 {price} | 触及：{touches} | 距离：{dist} ATR",
    es: "Acercamiento a soporte {price} | toques: {touches} | distancia: {dist} ATR",
    pt: "Aproximação do suporte {price} | toques: {touches} | distância: {dist} ATR",
  },

  // ── retest.ts ────────────────────────────────────────────────
  retestSupport: {
    ru: "Ретест подд. {price} | закол {pct}% ATR",
    en: "Retest of support {price} | sweep {pct}% ATR",
    uk: "Ретест підтримки {price} | виніс {pct}% ATR",
    zh: "回测支撑位 {price} | 扫出 {pct}% ATR",
    es: "Retest de soporte {price} | barrido {pct}% ATR",
    pt: "Reteste do suporte {price} | varredura {pct}% ATR",
  },
  approachSupportDelta: {
    ru: "Подход к подд. {price} | Δ {delta} ATR",
    en: "Approaching support {price} | Δ {delta} ATR",
    uk: "Підхід до підтримки {price} | Δ {delta} ATR",
    zh: "接近支撑位 {price} | Δ {delta} ATR",
    es: "Acercamiento a soporte {price} | Δ {delta} ATR",
    pt: "Aproximação do suporte {price} | Δ {delta} ATR",
  },
  retestResistance: {
    ru: "Ретест сопр. {price} | закол {pct}% ATR",
    en: "Retest of resistance {price} | sweep {pct}% ATR",
    uk: "Ретест опору {price} | виніс {pct}% ATR",
    zh: "回测阻力位 {price} | 扫出 {pct}% ATR",
    es: "Retest de resistencia {price} | barrido {pct}% ATR",
    pt: "Reteste da resistência {price} | varredura {pct}% ATR",
  },
  approachResistanceDelta: {
    ru: "Подход к сопр. {price} | Δ {delta} ATR",
    en: "Approaching resistance {price} | Δ {delta} ATR",
    uk: "Підхід до опору {price} | Δ {delta} ATR",
    zh: "接近阻力位 {price} | Δ {delta} ATR",
    es: "Acercamiento a resistencia {price} | Δ {delta} ATR",
    pt: "Aproximação da resistência {price} | Δ {delta} ATR",
  },

  // ── bos.ts ───────────────────────────────────────────────────
  bosDown: {
    ru: "BOS вниз: слом бычьей структуры (HL={price})",
    en: "BOS down: bullish structure broken (HL={price})",
    uk: "BOS вниз: злам бичачої структури (HL={price})",
    zh: "BOS 向下：多头结构破坏（HL={price}）",
    es: "BOS bajista: ruptura de estructura alcista (HL={price})",
    pt: "BOS de baixa: rompimento da estrutura de alta (HL={price})",
  },
  bosUp: {
    ru: "BOS вверх: слом медвежьей структуры (LH={price})",
    en: "BOS up: bearish structure broken (LH={price})",
    uk: "BOS вгору: злам ведмежої структури (LH={price})",
    zh: "BOS 向上：空头结构破坏（LH={price}）",
    es: "BOS alcista: ruptura de estructura bajista (LH={price})",
    pt: "BOS de alta: rompimento da estrutura de baixa (LH={price})",
  },

  // ── consolidation_vspike.ts ──────────────────────────────────
  consolidationBase: {
    ru: "База {pct}%, объём -{volDrop}%, {len} свечей",
    en: "Base {pct}%, volume -{volDrop}%, {len} candles",
    uk: "База {pct}%, обсяг -{volDrop}%, {len} свічок",
    zh: "盘整 {pct}%，成交量 -{volDrop}%，{len} 根K线",
    es: "Base {pct}%, volumen -{volDrop}%, {len} velas",
    pt: "Base {pct}%, volume -{volDrop}%, {len} velas",
  },
  consolidationBreakout: {
    ru: "🔥 Выход из базы ({len} свечей)",
    en: "🔥 Breaking out of base ({len} candles)",
    uk: "🔥 Вихід із бази ({len} свічок)",
    zh: "🔥 突破盘整区（{len} 根K线）",
    es: "🔥 Ruptura de la base ({len} velas)",
    pt: "🔥 Rompimento da base ({len} velas)",
  },
  volumeSpike: {
    ru: "Z={z}, ×{mult} от среднего (30 свечей)",
    en: "Z={z}, ×{mult} of average (30 candles)",
    uk: "Z={z}, ×{mult} від середнього (30 свічок)",
    zh: "Z={z}，×{mult} 倍于均值（30根K线）",
    es: "Z={z}, ×{mult} del promedio (30 velas)",
    pt: "Z={z}, ×{mult} da média (30 velas)",
  },

  // ── trend_level.ts ───────────────────────────────────────────
  trendlineUp: {
    ru: "Касание восх. ТЛ ~{price}, R²={r2}",
    en: "Touch of ascending TL ~{price}, R²={r2}",
    uk: "Дотик висх. ТЛ ~{price}, R²={r2}",
    zh: "触及上升趋势线 ~{price}，R²={r2}",
    es: "Toque de LT ascendente ~{price}, R²={r2}",
    pt: "Toque na LT ascendente ~{price}, R²={r2}",
  },
  trendlineDown: {
    ru: "Касание нисх. ТЛ ~{price}, R²={r2}",
    en: "Touch of descending TL ~{price}, R²={r2}",
    uk: "Дотик низх. ТЛ ~{price}, R²={r2}",
    zh: "触及下降趋势线 ~{price}，R²={r2}",
    es: "Toque de LT descendente ~{price}, R²={r2}",
    pt: "Toque na LT descendente ~{price}, R²={r2}",
  },
};


export function tf(
  lang: Lang,
  key: keyof typeof DICT,
  params: Record<string, string | number> = {}
): string {
  const entry = DICT[key];
  let str = entry ? entry[lang] ?? entry.ru ?? entry.en : String(key);
  for (const [k, v] of Object.entries(params)) {
    str = str.split(`{${k}}`).join(String(v));
  }
  return str;
}
