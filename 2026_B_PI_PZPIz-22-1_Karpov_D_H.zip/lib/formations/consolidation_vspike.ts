// lib/formations/consolidation_vspike.ts
import type { Candle, FormationResult, Lang } from "./types";
import { calcSMAVol, calcATR } from "./math"; 
import { tf } from "./translations";

export function detectConsolidation(
  candles: Candle[], symbol: string, exchange: string, interval: string,
  chartCandles: Candle[], lang: Lang = "ru"
): FormationResult[] {
  const n = candles.length;
  if (n < 50) return [];
  
  const atr = calcATR(candles);
  const W = 25; 
  let bestConsolidation: any = null;

  for (let endIdx = n - 1; endIdx >= n - 100; endIdx--) {
    const startIdx = endIdx - W + 1;
    if (startIdx < 0) break;

    const wCandles = candles.slice(startIdx, endIdx + 1);

    const bodyMax = Math.max(...wCandles.map(c => Math.max(c.open, c.close)));
    const bodyMin = Math.min(...wCandles.map(c => Math.min(c.open, c.close)));
    const bodyRangePct = ((bodyMax - bodyMin) / (bodyMin || 1)) * 100;

    const absHi = Math.max(...wCandles.map(c => c.high));
    const absLo = Math.min(...wCandles.map(c => c.low));
    const absRangePct = ((absHi - absLo) / (absLo || 1)) * 100;

    if (bodyRangePct <= 1.5 && absRangePct <= 4.0) { 

     
      const half = Math.floor(W / 2);
      const firstHalfAvg = wCandles.slice(0, half).reduce((a, c) => a + c.close, 0) / half;
      const secondHalfAvg = wCandles.slice(half).reduce((a, c) => a + c.close, 0) / (W - half);
      
      const driftPct = Math.abs(firstHalfAvg - secondHalfAvg) / firstHalfAvg * 100;

  
      if (driftPct > bodyRangePct * 0.5) continue; 
      // =================================================

      let isCanceled = false;
      let isBreakingOut = false;
      
      for (let k = endIdx + 1; k < n; k++) {
        if (candles[k].close > bodyMax + atr * 1.5 || candles[k].close < bodyMin - atr * 1.5) {
          isCanceled = true;
          break;
        }
        if (k >= n - 3 && (candles[k].close > bodyMax + atr * 0.2 || candles[k].close < bodyMin - atr * 0.2)) {
          isBreakingOut = true;
        }
      }

      if (isCanceled) continue;

      const vol1 = wCandles.slice(0, 12).reduce((a, c) => a + c.volume, 0) / 12;
      const vol2 = wCandles.slice(12).reduce((a, c) => a + c.volume, 0) / 13;

      let actualStart = startIdx;
      for (let i = startIdx - 1; i >= Math.max(0, n - 200); i--) {
        const cMax = Math.max(candles[i].open, candles[i].close);
        const cMin = Math.min(candles[i].open, candles[i].close);
        
        if (cMax <= bodyMax * 1.002 && cMin >= bodyMin * 0.998) {
          actualStart = i;
        } else {
          break; 
        }
      }

      const actualLen = endIdx - actualStart + 1;

      if (vol2 < vol1 * 1.1) { 
        bestConsolidation = {
          actualStart, endIdx, bodyMax, bodyMin, actualLen, bodyRangePct, vol1, vol2, isBreakingOut
        };
        break; 
      }
    }
  }

  if (bestConsolidation) {
    const { actualStart, bodyMax, bodyMin, actualLen, bodyRangePct, vol1, vol2, isBreakingOut } = bestConsolidation;
    
    const str: 1|2|3 = bodyRangePct < 0.6 ? 3 : bodyRangePct < 1.0 ? 2 : 1;

    let desc = tf(lang, "consolidationBase", { pct: bodyRangePct.toFixed(2), volDrop: ((1 - vol2/vol1)*100).toFixed(0), len: actualLen });
    if (isBreakingOut) desc = tf(lang, "consolidationBreakout", { len: actualLen });

    const startTime = candles[actualStart].time;
    const endTime = candles[n - 1].time; 

    return [{
      symbol, exchange, interval, type: "consolidation",
      direction: "neutral", strength: str,
      description: desc,
      timestamp: Date.now(), candles: chartCandles, allCandles: candles,
      annotations: [
        { type: "hzone", color: "rgba(34,211,238,0.12)", price: bodyMin, price2: bodyMax, time1: startTime, time2: endTime },
        { type: "hline", color: "rgba(34,211,238,0.8)", price: bodyMax, time1: startTime, time2: endTime },
        { type: "hline", color: "rgba(34,211,238,0.8)", price: bodyMin, time1: startTime, time2: endTime },
      ],
    }];
  }

  return [];
}

export function detectVolumeSpike(
  candles: Candle[], symbol: string, exchange: string, interval: string,
  chartCandles: Candle[], lang: Lang = "ru"
): FormationResult[] {
  if (candles.length < 30) return [];
  const mean = calcSMAVol(candles, 30);
  const std = Math.sqrt(candles.slice(-30).reduce((a, c) => a + (c.volume - mean) ** 2, 0) / 30);

  const checkCandles = candles.slice(-3);
  for (const c of checkCandles) {
    const z = std > 0 ? (c.volume - mean) / std : 0;
    if (z <= 2.2) continue;

    const str: 1|2|3 = z > 4.5 ? 3 : z > 3 ? 2 : 1;
    const dir = c.close > c.open ? "bull" : "bear";
    return [{
      symbol, exchange, interval, type: "volume_spike",
      direction: dir, strength: str,
      description: tf(lang, "volumeSpike", { z: z.toFixed(1), mult: (c.volume/mean).toFixed(1) }),
      timestamp: Date.now(), candles: chartCandles, allCandles: candles,
      annotations: [
        { type: "arrow", color: "#fb923c", time: c.time, direction: dir === "bull" ? "up" : "down" },
        { type: "label", color: "#fb923c", time: c.time, price: c.high, text: `×${(c.volume/mean).toFixed(1)}` },
      ],
    }];
  }
  return [];
}