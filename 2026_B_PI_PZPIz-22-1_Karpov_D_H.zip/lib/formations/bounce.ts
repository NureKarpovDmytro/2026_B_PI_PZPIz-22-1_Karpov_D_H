
import type { Candle, FormationResult, FormationAnnotation, Lang } from "./types";
import { calcATR, calcSMAVol, getSwingHighs, getSwingLows } from "./math";
import { tf } from "./translations";

export function detectBounce(
  candles: Candle[],
  symbol: string,
  exchange: string,
  interval: string,
  chartCandles: Candle[],
  lang: Lang = "ru",
): FormationResult[] {
  const results: FormationResult[] = [];
  const n = candles.length;
  if (n < 50) return results;

  const atr = calcATR(candles);
  const smaVol = calcSMAVol(candles, 30);
  const now = Date.now();

  const tol = atr * 0.4;
  const scanDepth = 800;
  const startIndex = Math.max(0, n - scanDepth);

  const SH = getSwingHighs(candles, 5).filter((p) => p.idx >= startIndex);
  const SL = getSwingLows(candles, 5).filter((p) => p.idx >= startIndex);

  type Cluster = {
    maxPrice: number;
    minPrice: number;
    firstIdx: number;
    lastIdx: number;
    touches: number[];
    exactPrices: number[];
  };

  const push = (
    dir: "bull" | "bear",
    str: 1 | 2 | 3,
    desc: string,
    ann: FormationAnnotation[],
    triggerCandle: Candle,
  ) => {
    const startVisibleIdx = Math.max(0, n - 150);
    const formationCandles = candles.slice(startVisibleIdx);
    results.push({
      symbol,
      exchange,
      interval,
      type: "bounce",
      direction: dir,
      strength: str,
      description: desc,
      timestamp: now,
      candles: formationCandles,
      allCandles: candles,
      annotations: ann,
    });
  };


  const resistanceClusters: Cluster[] = [];
  for (const sh of SH) {
    let added = false;
    for (const cluster of resistanceClusters) {
      if (
        sh.price >= cluster.minPrice - tol &&
        sh.price <= cluster.maxPrice + tol
      ) {
        cluster.touches.push(sh.idx);
        cluster.exactPrices.push(sh.price);
        cluster.maxPrice = Math.max(cluster.maxPrice, sh.price);
        cluster.minPrice = Math.min(cluster.minPrice, sh.price);
        cluster.lastIdx = Math.max(cluster.lastIdx, sh.idx);
        cluster.firstIdx = Math.min(cluster.firstIdx, sh.idx);
        added = true;
        break;
      }
    }
    if (!added) {
      resistanceClusters.push({
        maxPrice: sh.price,
        minPrice: sh.price,
        firstIdx: sh.idx,
        lastIdx: sh.idx,
        touches: [sh.idx],
        exactPrices: [sh.price],
      });
    }
  }

  for (const cluster of resistanceClusters) {
    if (cluster.touches.length < 2) continue;
    if (cluster.lastIdx - cluster.firstIdx < 15) continue;
    if (cluster.maxPrice - cluster.minPrice > atr * 1.0) continue;

    let isClean = true;
    let cleanBreaches = 0;
    for (let i = cluster.firstIdx + 1; i < n; i++) {
      if (candles[i].close > cluster.maxPrice + atr * 0.1) {
        cleanBreaches++;
        if (cleanBreaches > 2) {
          isClean = false;
          break;
        }
      }
    }
    if (!isClean) continue;

    const lvl = cluster.maxPrice;
    const lastC = candles[n - 1];
    const currentDist = Math.abs(lastC.close - lvl);

    if (currentDist > atr * 2.5) continue; 

    let sweepFound = false;
    for (let i = n - 1; i >= Math.max(cluster.lastIdx, n - 150); i--) {
      const c = candles[i];

      const wickAbove = c.high - lvl;
      const bodyTop = Math.max(c.open, c.close);
      const bodySize = Math.abs(c.close - c.open);
      const range = c.high - c.low || 0.0001;

      const isRealBreakout = c.close > lvl;

      const conditions =
        c.high > lvl &&
        !isRealBreakout &&
        bodyTop < lvl + atr * 0.05 && 
        wickAbove >= atr * 0.08 &&
        wickAbove <= atr * 1.5 && 
        bodySize / range >= 0.3 && 
        c.volume >= smaVol * 1.2;

      if (!conditions) continue;

      const sweepIdx = i;
      let hasRollback = false;
      for (let j = sweepIdx + 1; j < n; j++) {
        if (candles[j].close < lvl) {
          hasRollback = true;
          break;
        }
      }
      if (!hasRollback) continue;

      let levelHeld = true;
      for (let j = sweepIdx + 1; j < n; j++) {
        if (candles[j].close > lvl + atr * 0.15) {
          levelHeld = false;
          break;
        }
      }
      if (!levelHeld) continue;

      let str: 1 | 2 | 3 = 1;
      if (c.volume > smaVol * 2.5 && cluster.touches.length >= 3) str = 3;
      else if (c.volume > smaVol * 1.8 || cluster.touches.length >= 3) str = 2;

      const startTime = candles[cluster.firstIdx].time;
      const endTime = c.time;

      const anns: FormationAnnotation[] = [
        {
          type: "hline",
          color: "rgba(96, 165, 250, 0.85)",
          price: lvl,
          time1: startTime,
          time2: endTime,
        },
        {
          type: "hzone",
          color: "rgba(96, 165, 250, 0.07)",
          price: cluster.minPrice - atr * 0.2,
          price2: cluster.maxPrice + atr * 0.2,
          time1: startTime,
          time2: endTime,
        },
        { type: "arrow", color: "#60a5fa", time: c.time, direction: "down" },
      ];

      push(
        "bear",
        str,
        tf(lang, "sweepResistance", { price: lvl.toFixed(4), touches: cluster.touches.length, pct: ((wickAbove / atr) * 100).toFixed(0) }),
        anns,
        c,
      );
      sweepFound = true;
      break;
    }


    if (!sweepFound && currentDist <= atr * 0.8 && lastC.close < lvl) {
      let hasRollbackAfterLastTouch = false;
      const lastTouchIdx = cluster.lastIdx;
      for (let j = lastTouchIdx + 1; j < n; j++) {
        if (candles[j].close < lvl) {
          hasRollbackAfterLastTouch = true;
          break;
        }
      }
      if (!hasRollbackAfterLastTouch) continue;

      let str: 1 | 2 | 3 = 1;
      if (cluster.touches.length >= 3) str = 2;

      const startTime = candles[cluster.firstIdx].time;
      const endTime = lastC.time;

      const anns: FormationAnnotation[] = [
        {
          type: "hline",
          color: "rgba(96, 165, 250, 0.85)",
          price: lvl,
          time1: startTime,
          time2: endTime,
        },
        {
          type: "hzone",
          color: "rgba(96, 165, 250, 0.07)",
          price: cluster.minPrice - atr * 0.2,
          price2: cluster.maxPrice + atr * 0.2,
          time1: startTime,
          time2: endTime,
        },
      ];

      push(
        "bear",
        str,
        tf(lang, "approachResistanceDist", { price: lvl.toFixed(4), touches: cluster.touches.length, dist: (currentDist / atr).toFixed(1) }),
        anns,
        lastC,
      );
    }

    if (results.length >= 3) break;
  }

  // ===============================================

  const supportClusters: Cluster[] = [];
  for (const sl of SL) {
    let added = false;
    for (const cluster of supportClusters) {
      if (
        sl.price >= cluster.minPrice - tol &&
        sl.price <= cluster.maxPrice + tol
      ) {
        cluster.touches.push(sl.idx);
        cluster.exactPrices.push(sl.price);
        cluster.maxPrice = Math.max(cluster.maxPrice, sl.price);
        cluster.minPrice = Math.min(cluster.minPrice, sl.price);
        cluster.lastIdx = Math.max(cluster.lastIdx, sl.idx);
        cluster.firstIdx = Math.min(cluster.firstIdx, sl.idx);
        added = true;
        break;
      }
    }
    if (!added) {
      supportClusters.push({
        maxPrice: sl.price,
        minPrice: sl.price,
        firstIdx: sl.idx,
        lastIdx: sl.idx,
        touches: [sl.idx],
        exactPrices: [sl.price],
      });
    }
  }

  const bearResults = results.length;

  for (const cluster of supportClusters) {
    if (cluster.touches.length < 2) continue;
    if (cluster.lastIdx - cluster.firstIdx < 15) continue;
    if (cluster.maxPrice - cluster.minPrice > atr * 1.0) continue;

    let isClean = true;
    let cleanBreaches = 0;
    for (let i = cluster.firstIdx + 1; i < n; i++) {
      if (candles[i].close < cluster.minPrice - atr * 0.1) {
        cleanBreaches++;
        if (cleanBreaches > 2) {
          isClean = false;
          break;
        }
      }
    }
    if (!isClean) continue;

    const lvl = cluster.minPrice;
    const lastC = candles[n - 1];
    const currentDist = Math.abs(lastC.close - lvl);

    if (currentDist > atr * 2.5) continue;

    // 1. 
    let sweepFound = false;
    for (let i = n - 1; i >= Math.max(cluster.lastIdx, n - 150); i--) {
      const c = candles[i];

      const wickBelow = lvl - c.low;
      const bodyBot = Math.min(c.open, c.close);
      const bodySize = Math.abs(c.close - c.open);
      const range = c.high - c.low || 0.0001;

      const isRealBreakout = c.close < lvl;

      const conditions =
        c.low < lvl &&
        !isRealBreakout &&
        bodyBot > lvl - atr * 0.05 &&
        wickBelow >= atr * 0.08 &&
        wickBelow <= atr * 1.5 &&
        bodySize / range >= 0.3 &&
        c.volume >= smaVol * 1.2;

      if (!conditions) continue;


      const sweepIdx = i;
      let hasRollback = false;
      for (let j = sweepIdx + 1; j < n; j++) {
        if (candles[j].close > lvl) {
          hasRollback = true;
          break;
        }
      }
      if (!hasRollback) continue;

      let levelHeld = true;
      for (let j = sweepIdx + 1; j < n; j++) {
        if (candles[j].close < lvl - atr * 0.15) {
          levelHeld = false;
          break;
        }
      }
      if (!levelHeld) continue;

      let str: 1 | 2 | 3 = 1;
      if (c.volume > smaVol * 2.5 && cluster.touches.length >= 3) str = 3;
      else if (c.volume > smaVol * 1.8 || cluster.touches.length >= 3) str = 2;

      const startTime = candles[cluster.firstIdx].time;
      const endTime = c.time;

      const anns: FormationAnnotation[] = [
        {
          type: "hline",
          color: "rgba(52, 211, 153, 0.85)",
          price: lvl,
          time1: startTime,
          time2: endTime,
        },
        {
          type: "hzone",
          color: "rgba(52, 211, 153, 0.07)",
          price: cluster.minPrice - atr * 0.2,
          price2: cluster.maxPrice + atr * 0.2,
          time1: startTime,
          time2: endTime,
        },
        { type: "arrow", color: "#34d399", time: c.time, direction: "up" },
      ];

      push(
        "bull",
        str,
        tf(lang, "sweepSupport", { price: lvl.toFixed(4), touches: cluster.touches.length, pct: ((wickBelow / atr) * 100).toFixed(0) }),
        anns,
        c,
      );
      sweepFound = true;
      break;
    }

    // 2. 
    if (!sweepFound && currentDist <= atr * 0.8 && lastC.close > lvl) {
      let hasRollbackAfterLastTouch = false;
      const lastTouchIdx = cluster.lastIdx;
      for (let j = lastTouchIdx + 1; j < n; j++) {
        if (candles[j].close > lvl) {
          hasRollbackAfterLastTouch = true;
          break;
        }
      }
      if (!hasRollbackAfterLastTouch) continue;

      let str: 1 | 2 | 3 = 1;
      if (cluster.touches.length >= 3) str = 2;

      const startTime = candles[cluster.firstIdx].time;
      const endTime = lastC.time;

      const anns: FormationAnnotation[] = [
        {
          type: "hline",
          color: "rgba(52, 211, 153, 0.85)",
          price: lvl,
          time1: startTime,
          time2: endTime,
        },
        {
          type: "hzone",
          color: "rgba(52, 211, 153, 0.07)",
          price: cluster.minPrice - atr * 0.2,
          price2: cluster.maxPrice + atr * 0.2,
          time1: startTime,
          time2: endTime,
        },
      ];

      push(
        "bull",
        str,
        tf(lang, "approachSupportDist", { price: lvl.toFixed(4), touches: cluster.touches.length, dist: (currentDist / atr).toFixed(1) }),
        anns,
        lastC,
      );
    }

    if (results.length - bearResults >= 3) break;
  }

  return results;
}
