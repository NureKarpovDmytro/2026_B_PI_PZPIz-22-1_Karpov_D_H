// lib/formations/types.ts

export type Lang = "en" | "uk" | "ru" | "zh" | "es" | "pt";

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type FormationType =
  | "breakout" | "bounce" | "retest" | "bos"
  | "consolidation" | "volume_spike" | "trend_level";

export interface FormationAnnotation {
  type: "hline" | "hzone" | "trendline" | "arrow" | "label";
  color: string;
  price?: number;
  price2?: number;
  time1?: number; priceA?: number;
  time2?: number; priceB?: number;
  time?: number;
  text?: string;
  direction?: "up" | "down";
}

export interface FormationResult {
  symbol: string;
  exchange: string;
  interval: string;
  type: FormationType;
  direction: "bull" | "bear" | "neutral";
  strength: 1 | 2 | 3;
  description: string;
  timestamp: number;
  candles: Candle[];      
  allCandles: Candle[];   
  annotations: FormationAnnotation[];
}
