// lib/formations/index.ts
export type { Candle, FormationResult, FormationAnnotation, FormationType, Lang } from "./types";

import type { Candle, FormationResult, Lang } from "./types";
import { detectBreakout } from "./breakout";
import { detectBounce } from "./bounce";
import { detectRetest } from "./retest";
import { detectBOS } from "./bos";
import { detectConsolidation, detectVolumeSpike } from "./consolidation_vspike";
import { detectTrendLevel } from "./trend_level";

const CHART_CANDLES = 80;

export function detectFormations(
  candles: Candle[],
  symbol: string,
  exchange: string,
  interval: string,
  enabledTypes: string[] = ["breakout", "bounce", "retest", "bos", "consolidation", "volume_spike", "trend_level"],
  lang: Lang = "ru"
): FormationResult[] {
  if (candles.length < 50) return [];

  const chartCandles = candles.slice(-CHART_CANDLES);
  const results: FormationResult[] = [];

  if (enabledTypes.includes("breakout")) results.push(...detectBreakout(candles, symbol, exchange, interval, chartCandles, lang));
  if (enabledTypes.includes("bounce")) results.push(...detectBounce(candles, symbol, exchange, interval, chartCandles, lang));
  if (enabledTypes.includes("retest")) results.push(...detectRetest(candles, symbol, exchange, interval, chartCandles, lang));
  if (enabledTypes.includes("bos")) results.push(...detectBOS(candles, symbol, exchange, interval, chartCandles, lang));
  if (enabledTypes.includes("consolidation")) results.push(...detectConsolidation(candles, symbol, exchange, interval, chartCandles, lang));
  if (enabledTypes.includes("volume_spike")) results.push(...detectVolumeSpike(candles, symbol, exchange, interval, chartCandles, lang));
  if (enabledTypes.includes("trend_level")) results.push(...detectTrendLevel(candles, symbol, exchange, interval, chartCandles, lang));

  return results;
}