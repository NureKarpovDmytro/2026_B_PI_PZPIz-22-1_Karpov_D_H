// lib/formations/retest.ts
import type { Candle, FormationResult, FormationAnnotation, Lang } from "./types";
import { calcATR, calcSMAVol, getSwingHighs, getSwingLows } from "./math";
import { tf } from "./translations";

type Cluster = {
  maxPrice: number; minPrice: number;
  firstIdx: number; lastIdx: number;
  touches: number[]; exactPrices: number[];
};

function buildClusters(
  pts: { idx: number; price: number }[],
  tol: number
): Cluster[] {
  const clusters: Cluster[] = [];
  for (const pt of pts) {
    let added = false;
    for (const cl of clusters) {
      if (pt.price >= cl.minPrice - tol && pt.price <= cl.maxPrice + tol) {
        cl.touches.push(pt.idx);
        cl.exactPrices.push(pt.price);
        cl.maxPrice = Math.max(cl.maxPrice, pt.price);
        cl.minPrice = Math.min(cl.minPrice, pt.price);
        cl.lastIdx = Math.max(cl.lastIdx, pt.idx);
        cl.firstIdx = Math.min(cl.firstIdx, pt.idx);
        added = true;
        break;
      }
    }
    if (!added) {
      clusters.push({
        maxPrice: pt.price, minPrice: pt.price,
        firstIdx: pt.idx, lastIdx: pt.idx,
        touches: [pt.idx], exactPrices: [pt.price],
      });
    }
  }
  return clusters;
}

export function detectRetest(
  candles: Candle[],
  symbol: string,
  exchange: string,
  interval: string,
  chartCandles: Candle[],
  lang: Lang = "ru"
): FormationResult[] {
  const results: FormationResult[] = [];
  const n = candles.length;
  if (n < 100) return results;

  const atr = calcATR(candles);
  const smaVol = calcSMAVol(candles, 30);
  const now = Date.now();
  const tol = atr * 0.35;

  const scanDepth = 1000;
  const startIndex = Math.max(0, n - scanDepth);

  const SH = getSwingHighs(candles, 7).filter(p => p.idx >= startIndex);
  const SL = getSwingLows(candles, 7).filter(p => p.idx >= startIndex);

  const push = (
    dir: "bull" | "bear", str: 1 | 2 | 3,
    desc: string, ann: FormationAnnotation[], customCandles: Candle[]
  ) => results.push({
    symbol, exchange, interval, type: "retest",
    direction: dir, strength: str, description: desc,
    timestamp: now,
    candles: customCandles,
    allCandles: candles,
    annotations: ann,
  });


  let bullCount = 0;

  for (const cluster of buildClusters(SH, tol)) {
    if (bullCount >= 2) break;
    const lvl = cluster.maxPrice; 

    let breakoutIdx = -1;
    let isChoppedBefore = false;
    for (let i = cluster.firstIdx; i < n - 5; i++) {
      if (candles[i].close > lvl + atr * 0.2) {
        if (candles[i].volume >= smaVol * 1.3) {
          breakoutIdx = i;
          break; 
        } else {
          isChoppedBefore = true;
          break;
        }
      }
    }
    
    if (isChoppedBefore || breakoutIdx === -1) continue;

    const touchesBeforeBreak = cluster.touches.filter(idx => idx < breakoutIdx).length;
    if (touchesBeforeBreak < 2) continue;
    if (breakoutIdx - cluster.firstIdx < 15) continue; 
    
    if (n - 1 - breakoutIdx < 8) continue;

    let maxClose = lvl;
    let isChoppedAfter = false;
    let clearAirCandles = 0;

    for (let i = breakoutIdx + 1; i < n - 1; i++) {
      const c = candles[i];
      if (c.close > maxClose) maxClose = c.close;

      if (c.close < lvl - atr * 0.25) {
        isChoppedAfter = true;
        break;
      }

      if (c.low > lvl + atr * 0.3) {
        clearAirCandles++;
      }
    }

    if (isChoppedAfter) continue;
    if (maxClose < lvl + atr * 1.2) continue; 
    if (clearAirCandles < 2) continue; 

    const currentC = candles[n - 1];
    const formationStart = Math.max(0, cluster.firstIdx - 10);
    const formationCandles = candles.slice(formationStart);

    const baseAnns: FormationAnnotation[] = [
      { type: "hline", color: "rgba(34, 197, 94, 0.85)", price: lvl, time1: candles[cluster.firstIdx].time, time2: currentC.time } as any,
      { type: "hzone", color: "rgba(34, 197, 94, 0.08)", price: lvl - atr * 0.5, price2: lvl, time1: candles[cluster.firstIdx].time, time2: currentC.time } as any,
      { type: "arrow", color: "#facc15", time: candles[breakoutIdx].time, direction: "up" },
    ];

    let scenarioBFound = false;
    for (let i = n - 5; i < n; i++) {
      const c = candles[i];
      const wickBelow = lvl - c.low;
      const bodyBot = Math.min(c.open, c.close);

      if (
        c.low < lvl && 
        bodyBot >= lvl - atr * 0.15 && 
        wickBelow >= atr * 0.08 && 
        wickBelow <= atr * 1.5 
      ) {
        const str = c.volume > smaVol * 2.0 && touchesBeforeBreak >= 3 ? 3 : c.volume > smaVol * 1.4 || touchesBeforeBreak >= 3 ? 2 : 1;
        push("bull", str, tf(lang, "retestSupport", { price: lvl.toFixed(4), pct: (wickBelow / atr * 100).toFixed(0) }), 
          [...baseAnns, { type: "arrow", color: "#34d399", time: c.time, direction: "up" }], formationCandles);
        bullCount++;
        scenarioBFound = true;
        break;
      }
    }
    if (scenarioBFound) continue;

    const distToLevel = currentC.close - lvl; 
    if (distToLevel >= 0 && distToLevel <= atr * 1.5) {
      const lookback5 = candles.slice(n - 6, n - 1);
      const movingTowardsLevel = lookback5.length >= 3 && lookback5[lookback5.length - 1].close < lookback5[0].close;
      if (!movingTowardsLevel) continue;

      const moveSize = lookback5[0].close - lookback5[lookback5.length - 1].close;
      if (moveSize < atr * 0.8) continue; 

      const str = distToLevel <= atr * 0.5 ? 2 : 1;
      push("bull", str, tf(lang, "approachSupportDelta", { price: lvl.toFixed(4), delta: (distToLevel / atr).toFixed(2) }), baseAnns, formationCandles);
      bullCount++;
    }
  }

  let bearCount = 0;

  for (const cluster of buildClusters(SL, tol)) {
    if (bearCount >= 2) break;
    const lvl = cluster.minPrice; 

    let breakoutIdx = -1;
    let isChoppedBefore = false;
    for (let i = cluster.firstIdx; i < n - 5; i++) {
      if (candles[i].close < lvl - atr * 0.2) {
        if (candles[i].volume >= smaVol * 1.3) {
          breakoutIdx = i;
          break;
        } else {
          isChoppedBefore = true;
          break;
        }
      }
    }
    
    if (isChoppedBefore || breakoutIdx === -1) continue;

    const touchesBeforeBreak = cluster.touches.filter(idx => idx < breakoutIdx).length;
    if (touchesBeforeBreak < 2) continue;
    if (breakoutIdx - cluster.firstIdx < 15) continue;
    
    if (n - 1 - breakoutIdx < 8) continue;

    let minClose = lvl;
    let isChoppedAfter = false;
    let clearAirCandles = 0;

    for (let i = breakoutIdx + 1; i < n - 1; i++) {
      const c = candles[i];
      if (c.close < minClose) minClose = c.close;

      if (c.close > lvl + atr * 0.25) {
        isChoppedAfter = true;
        break;
      }

      if (c.high < lvl - atr * 0.3) {
        clearAirCandles++;
      }
    }

    if (isChoppedAfter) continue;
    if (minClose > lvl - atr * 1.2) continue; // Было 1.5
    if (clearAirCandles < 2) continue; // Было 3

    const currentC = candles[n - 1];
    const formationStart = Math.max(0, cluster.firstIdx - 10);
    const formationCandles = candles.slice(formationStart);

    const baseAnns: FormationAnnotation[] = [
      { type: "hline", color: "rgba(239, 68, 68, 0.85)", price: lvl, time1: candles[cluster.firstIdx].time, time2: currentC.time } as any,
      { type: "hzone", color: "rgba(239, 68, 68, 0.08)", price: lvl, price2: lvl + atr * 0.5, time1: candles[cluster.firstIdx].time, time2: currentC.time } as any,
      { type: "arrow", color: "#facc15", time: candles[breakoutIdx].time, direction: "down" },
    ];

    let scenarioBFound = false;
    for (let i = n - 5; i < n; i++) {
      const c = candles[i];
      const wickAbove = c.high - lvl;
      const bodyTop = Math.max(c.open, c.close);

      if (
        c.high > lvl &&
        bodyTop <= lvl + atr * 0.15 &&
        wickAbove >= atr * 0.08 &&
        wickAbove <= atr * 1.5
      ) {
        const str = c.volume > smaVol * 2.0 && touchesBeforeBreak >= 3 ? 3 : c.volume > smaVol * 1.4 || touchesBeforeBreak >= 3 ? 2 : 1;
        push("bear", str, tf(lang, "retestResistance", { price: lvl.toFixed(4), pct: (wickAbove / atr * 100).toFixed(0) }), 
          [...baseAnns, { type: "arrow", color: "#ef4444", time: c.time, direction: "down" }], formationCandles);
        bearCount++;
        scenarioBFound = true;
        break;
      }
    }
    if (scenarioBFound) continue;

    const distToLevel = lvl - currentC.close;
    if (distToLevel >= 0 && distToLevel <= atr * 1.5) {
      const lookback5 = candles.slice(n - 6, n - 1);
      const movingTowardsLevel = lookback5.length >= 3 && lookback5[lookback5.length - 1].close > lookback5[0].close;
      if (!movingTowardsLevel) continue;

      const moveSize = lookback5[lookback5.length - 1].close - lookback5[0].close;
      if (moveSize < atr * 0.8) continue;

      const str = distToLevel <= atr * 0.5 ? 2 : 1;
      push("bear", str, tf(lang, "approachResistanceDelta", { price: lvl.toFixed(4), delta: (distToLevel / atr).toFixed(2) }), baseAnns, formationCandles);
      bearCount++;
    }
  }

  return results;
}