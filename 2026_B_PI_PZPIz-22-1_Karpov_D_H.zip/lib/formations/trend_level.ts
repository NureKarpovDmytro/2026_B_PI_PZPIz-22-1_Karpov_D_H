// lib/formations/trend_level.ts
import type { Candle, FormationResult, FormationAnnotation, Lang } from "./types";
import { calcATR, getSwingHighs, getSwingLows } from "./math";
import { tf } from "./translations";

function fitLine(pts: { idx: number; price: number }[]): { slope: number; intercept: number; r2: number } {
  const nn = pts.length;
  const sX = pts.reduce((a, p) => a + p.idx, 0);
  const sY = pts.reduce((a, p) => a + p.price, 0);
  const sXY = pts.reduce((a, p) => a + p.idx * p.price, 0);
  const sX2 = pts.reduce((a, p) => a + p.idx * p.idx, 0);
  const denom = nn * sX2 - sX * sX;
  if (Math.abs(denom) < 1e-10) return { slope: 0, intercept: sY / nn, r2: 0 };
  const slope = (nn * sXY - sX * sY) / denom;
  const intercept = (sY - slope * sX) / nn;
  const meanY = sY / nn;
  const ssRes = pts.reduce((a, p) => a + (p.price - (slope * p.idx + intercept)) ** 2, 0);
  const ssTot = pts.reduce((a, p) => a + (p.price - meanY) ** 2, 0);
  return { slope, intercept, r2: ssTot > 0 ? 1 - ssRes / ssTot : 0 };
}

function filterGap(pts: { idx: number; price: number }[], minGap: number) {
  const res: { idx: number; price: number }[] = [];
  for (const p of pts) {
    if (res.length === 0 || p.idx - res[res.length - 1].idx >= minGap) res.push(p);
  }
  return res;
}

export function detectTrendLevel(
  candles: Candle[], symbol: string, exchange: string, interval: string,
  chartCandles: Candle[], lang: Lang = "ru"
): FormationResult[] {
  const results: FormationResult[] = [];
  const atr = calcATR(candles);
  const last = candles[candles.length - 1];
  const n = candles.length;
  const now = Date.now();

  const SH = filterGap(getSwingHighs(candles, 7).filter(p => p.idx >= n - 400), 15);
  const SL = filterGap(getSwingLows(candles, 7).filter(p => p.idx >= n - 400), 15);

  const push = (dir: "bull"|"bear", str: 1|2|3, desc: string, ann: FormationAnnotation[]) =>
    results.push({ symbol, exchange, interval, type: "trend_level", direction: dir, strength: str, description: desc, timestamp: now, candles: chartCandles, allCandles: candles, annotations: ann });

  if (SL.length >= 3) {
    const pts = SL.slice(-4);
    const span = pts[pts.length - 1].idx - pts[0].idx;
    if (span >= 60) {
      const { slope, intercept, r2 } = fitLine(pts);
      if (slope > 0 && r2 >= 0.88) {
        const projY = slope * (n - 1) + intercept;
        const lastIdx = pts[pts.length - 1].idx;
        const broken = candles.slice(lastIdx + 1, n - 1).some((c, i) =>
          c.close < slope * (lastIdx + 1 + i) + intercept - atr * 0.6
        );
        if (!broken) {
          const dist = Math.abs(last.low - projY) / (projY || 1);
          if (dist < 0.004) {
            push("bull", r2 > 0.95 ? 3 : 2,
              tf(lang, "trendlineUp", { price: projY.toFixed(4), r2: r2.toFixed(2) }), [
              { type: "trendline", color: "rgba(52,211,153,0.85)", time1: candles[pts[0].idx].time, priceA: slope * pts[0].idx + intercept, time2: last.time, priceB: projY },
              { type: "arrow", color: "#34d399", time: last.time, direction: "up" },
            ]);
          }
        }
      }
    }
  }

  if (SH.length >= 3) {
    const pts = SH.slice(-4);
    const span = pts[pts.length - 1].idx - pts[0].idx;
    if (span >= 60) {
      const { slope, intercept, r2 } = fitLine(pts);
      if (slope < 0 && r2 >= 0.88) {
        const projY = slope * (n - 1) + intercept;
        const lastIdx = pts[pts.length - 1].idx;
        const broken = candles.slice(lastIdx + 1, n - 1).some((c, i) =>
          c.close > slope * (lastIdx + 1 + i) + intercept + atr * 0.6
        );
        if (!broken) {
          const dist = Math.abs(last.high - projY) / (projY || 1);
          if (dist < 0.004) {
            push("bear", r2 > 0.95 ? 3 : 2,
              tf(lang, "trendlineDown", { price: projY.toFixed(4), r2: r2.toFixed(2) }), [
              { type: "trendline", color: "rgba(248,113,113,0.85)", time1: candles[pts[0].idx].time, priceA: slope * pts[0].idx + intercept, time2: last.time, priceB: projY },
              { type: "arrow", color: "#f87171", time: last.time, direction: "down" },
            ]);
          }
        }
      }
    }
  }

  return results;
}