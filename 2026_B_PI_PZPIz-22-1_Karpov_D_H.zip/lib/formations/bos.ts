// lib/formations/bos.ts
import type { Candle, FormationResult, FormationAnnotation, Lang } from "./types";
import { calcATR, calcSMAVol, getSwingHighs, getSwingLows } from "./math";
import { tf } from "./translations";

export function detectBOS(
  candles: Candle[], symbol: string, exchange: string, interval: string,
  chartCandles: Candle[], lang: Lang = "ru"
): FormationResult[] {
  const results: FormationResult[] = [];
  const atr = calcATR(candles);
  const smaVol = calcSMAVol(candles, 30);
  const n = candles.length;
  const now = Date.now();

  const SH = getSwingHighs(candles, 5).filter(p => p.idx >= n - 200);
  const SL = getSwingLows(candles, 5).filter(p => p.idx >= n - 200);

  const push = (dir: "bull"|"bear", str: 1|2|3, desc: string, ann: FormationAnnotation[]) =>
    results.push({ symbol, exchange, interval, type: "bos", direction: dir, strength: str, description: desc, timestamp: now, candles: chartCandles, allCandles: candles, annotations: ann });

  if (SH.length < 2 || SL.length < 2) return results;

  const sh0 = SH[SH.length - 1];
  const sh1 = SH[SH.length - 2];
  const sl0 = SL[SL.length - 1];
  const sl1 = SL[SL.length - 2];

  const bullTrend = sh0.price > sh1.price && sl0.price > sl1.price;
  const bearTrend = sh0.price < sh1.price && sl0.price < sl1.price;


  const checkCandles = candles.slice(-5);

  if (bullTrend) {
    for (const c of checkCandles) {
      if (c.close < sl0.price - atr * 0.15 && c.volume > smaVol * 1.2) { 
        const str: 1|2|3 = c.volume > smaVol * 2.5 ? 3 : c.volume > smaVol * 1.7 ? 2 : 1;
        push("bear", str, tf(lang, "bosDown", { price: sl0.price.toFixed(4) }), [
          { type: "hline", color: "rgba(248,113,113,0.9)", price: sl0.price },
          { type: "label", color: "#f87171", time: candles[sl0.idx].time, price: sl0.price, text: "BOS↓" },
          { type: "arrow", color: "#f87171", time: c.time, direction: "down" },
        ]);
        break;
      }
    }
  }

  if (bearTrend) {
    for (const c of checkCandles) {
      if (c.close > sh0.price + atr * 0.15 && c.volume > smaVol * 1.2) {
        const str: 1|2|3 = c.volume > smaVol * 2.5 ? 3 : c.volume > smaVol * 1.7 ? 2 : 1;
        push("bull", str, tf(lang, "bosUp", { price: sh0.price.toFixed(4) }), [
          { type: "hline", color: "rgba(248,113,113,0.9)", price: sh0.price },
          { type: "label", color: "#f87171", time: candles[sh0.idx].time, price: sh0.price, text: "BOS↑" },
          { type: "arrow", color: "#f87171", time: c.time, direction: "up" },
        ]);
        break;
      }
    }
  }

  return results;
}