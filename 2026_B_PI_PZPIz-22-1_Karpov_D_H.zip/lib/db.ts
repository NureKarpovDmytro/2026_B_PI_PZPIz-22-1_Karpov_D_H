import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function getFilePath(name: string) {
  return path.join(DATA_DIR, `${name}.json`);
}

export function readDB<T>(name: string, defaultValue: T): T {
  const filePath = getFilePath(name);
  try {
    if (!fs.existsSync(filePath)) {
      writeDB(name, defaultValue);
      return defaultValue;
    }
    const raw = fs.readFileSync(filePath, "utf-8");
    return JSON.parse(raw) as T;
  } catch {
    return defaultValue;
  }
}

export function writeDB<T>(name: string, data: T): void {
  const filePath = getFilePath(name);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
}


export interface User {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  role: "free" | "premium";
  createdAt: string;
  telegramChatId?: string;
}

export interface Session {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
}

export interface UserSettings {
  userId: string;
  exchange: string;
  timeframe: string;
  minVolume: number;
}

export interface CoinGroup {
  userId: string;
  symbol: string;
  group: number;
}

export interface AlertLine {
  id: string;
  userId: string;
  symbol: string;
  price: number;
  direction: "above" | "below";
  createdAt: string;
  triggered: boolean;
}

export interface TelegramLinkCode {
  code: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
}


export const UsersDB = {
  getAll: () => readDB<User[]>("users", []),
  findByEmail: (email: string) =>
    readDB<User[]>("users", []).find((u) => u.email === email),
  findById: (id: string) =>
    readDB<User[]>("users", []).find((u) => u.id === id),
  create: (user: User) => {
    const users = readDB<User[]>("users", []);
    users.push(user);
    writeDB("users", users);
  },
  update: (id: string, patch: Partial<User>) => {
    const users = readDB<User[]>("users", []);
    const idx = users.findIndex((u) => u.id === id);
    if (idx !== -1) {
      users[idx] = { ...users[idx], ...patch };
      writeDB("users", users);
    }
  },
};

export const SessionsDB = {
  getAll: () => readDB<Session[]>("sessions", []),
  findByToken: (token: string) =>
    readDB<Session[]>("sessions", []).find((s) => s.token === token),
  create: (session: Session) => {
    const sessions = readDB<Session[]>("sessions", []);
    sessions.push(session);
    writeDB("sessions", sessions);
  },
  delete: (token: string) => {
    const sessions = readDB<Session[]>("sessions", []).filter(
      (s) => s.token !== token
    );
    writeDB("sessions", sessions);
  },
  cleanup: () => {
    const now = new Date().toISOString();
    const sessions = readDB<Session[]>("sessions", []).filter(
      (s) => s.expiresAt > now
    );
    writeDB("sessions", sessions);
  },
};

export const SettingsDB = {
  get: (userId: string): UserSettings => {
    const all = readDB<UserSettings[]>("settings", []);
    return (
      all.find((s) => s.userId === userId) ?? {
        userId,
        exchange: "BINANCE",
        timeframe: "15m",
        minVolume: 0,
      }
    );
  },
  save: (settings: UserSettings) => {
    const all = readDB<UserSettings[]>("settings", []);
    const idx = all.findIndex((s) => s.userId === settings.userId);
    if (idx !== -1) all[idx] = settings;
    else all.push(settings);
    writeDB("settings", all);
  },
};

export const GroupsDB = {
  getByUser: (userId: string) =>
    readDB<CoinGroup[]>("groups", []).filter((g) => g.userId === userId),
  saveAll: (userId: string, groups: Record<string, number>) => {
    const all = readDB<CoinGroup[]>("groups", []).filter(
      (g) => g.userId !== userId
    );
    const newEntries: CoinGroup[] = Object.entries(groups).map(
      ([symbol, group]) => ({ userId, symbol, group })
    );
    writeDB("groups", [...all, ...newEntries]);
  },
};

export const AlertsDB = {
  getByUser: (userId: string) =>
    readDB<AlertLine[]>("alerts", []).filter((a) => a.userId === userId),
  create: (alert: AlertLine) => {
    const all = readDB<AlertLine[]>("alerts", []);
    all.push(alert);
    writeDB("alerts", all);
  },
  delete: (id: string, userId: string) => {
    const all = readDB<AlertLine[]>("alerts", []).filter(
      (a) => !(a.id === id && a.userId === userId)
    );
    writeDB("alerts", all);
  },
  update: (id: string, patch: Partial<AlertLine>) => {
    const all = readDB<AlertLine[]>("alerts", []);
    const idx = all.findIndex((a) => a.id === id);
    if (idx !== -1) all[idx] = { ...all[idx], ...patch };
    writeDB("alerts", all);
  },
};


export const TelegramCodesDB = {
  create: (userId: string, code: string) => {
    const all = readDB<TelegramLinkCode[]>("tg_codes", []);
    const filtered = all.filter((c) => c.userId !== userId);
    const now = new Date();
    const expires = new Date(now.getTime() + 15 * 60 * 1000);
    filtered.push({
      code,
      userId,
      createdAt: now.toISOString(),
      expiresAt: expires.toISOString(),
    });
    writeDB("tg_codes", filtered);
  },

  consumeByCode: (code: string): TelegramLinkCode | null => {
    const all = readDB<TelegramLinkCode[]>("tg_codes", []);
    const entry = all.find((c) => c.code === code);
    if (!entry) return null;
    if (new Date(entry.expiresAt) < new Date()) {
      writeDB("tg_codes", all.filter((c) => c.code !== code));
      return null;
    }
    writeDB("tg_codes", all.filter((c) => c.code !== code));
    return entry;
  },

  cleanup: () => {
    const now = new Date().toISOString();
    const all = readDB<TelegramLinkCode[]>("tg_codes", []).filter(
      (c) => c.expiresAt > now
    );
    writeDB("tg_codes", all);
  },
};