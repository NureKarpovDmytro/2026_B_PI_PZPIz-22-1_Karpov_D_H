"use client";
import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  Maximize2,
  Zap,
  Link as LinkIcon,
  TrendingUp,
  TrendingDown,
  Minus,
  Bell,
  EyeOff,
  Layers, 
} from "lucide-react";
import { useAlerts } from "@/components/terminal/AlertContext";
import { useChartWS } from "@/components/terminal/ChartWSContext";
import { useLanguage } from "@/lib/i18n"; 

// ─────────────────────────────────────────────
//  TYPES
// ─────────────────────────────────────────────
interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  value: number;
  color: string;
}

interface DrawnLine {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

type DrawMode = "none" | "line";

interface RealChartCardProps {
  symbol: string;
  interval?: string;
  onExpand?: () => void;
  isDark?: boolean;
  primaryExchange: string;
  isFocusMode?: boolean;
  label?: string;
  highlighted?: boolean;
  group?: number | null;
  onSetGroup?: (group: number | null) => void;
  indicators?: IndicatorSettings;
}

// ─────────────────────────────────────────────
//  MATH HELPERS
// ─────────────────────────────────────────────
function calcEMA(data: number[], period: number): (number | null)[] {
  const k = 2 / (period + 1);
  const result: (number | null)[] = new Array(data.length).fill(null);
  let prev: number | null = null;
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) continue;
    if (prev === null) {
      prev = data.slice(0, period).reduce((a, b) => a + b, 0) / period;
      result[i] = prev;
    } else {
      prev = data[i] * k + prev * (1 - k);
      result[i] = prev;
    }
  }
  return result;
}

// ─────────────────────────────────────────────
//  INDICATOR MATH
// ─────────────────────────────────────────────
function calcRSI(closes: number[], period = 14): (number | null)[] {
  const result: (number | null)[] = new Array(closes.length).fill(null);
  if (closes.length < period + 1) return result;
  let avgGain = 0, avgLoss = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) avgGain += d; else avgLoss -= d;
  }
  avgGain /= period; avgLoss /= period;
  result[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    const gain = d > 0 ? d : 0;
    const loss = d < 0 ? -d : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    result[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return result;
}

interface BB { upper: number | null; mid: number | null; lower: number | null; }
function calcBB(closes: number[], period = 20, mult = 2): BB[] {
  const result: BB[] = new Array(closes.length).fill({ upper: null, mid: null, lower: null });
  for (let i = period - 1; i < closes.length; i++) {
    const slice = closes.slice(i - period + 1, i + 1);
    const mean = slice.reduce((a, b) => a + b, 0) / period;
    const std = Math.sqrt(slice.reduce((s, v) => s + (v - mean) ** 2, 0) / period);
    result[i] = { upper: mean + mult * std, mid: mean, lower: mean - mult * std };
  }
  return result;
}

interface MACDPoint { macd: number | null; signal: number | null; hist: number | null; }
function calcMACD(closes: number[], fast = 12, slow = 26, signal = 9): MACDPoint[] {
  const result: MACDPoint[] = new Array(closes.length).fill({ macd: null, signal: null, hist: null });
  const emaFast = calcEMA(closes, fast);
  const emaSlw = calcEMA(closes, slow);
  const macdLine: (number | null)[] = closes.map((_, i) =>
    emaFast[i] !== null && emaSlw[i] !== null ? (emaFast[i] as number) - (emaSlw[i] as number) : null
  );
  const macdValues = macdLine.map((v) => v ?? 0);
  const signalLine = calcEMA(macdValues, signal);
  for (let i = 0; i < closes.length; i++) {
    const m = macdLine[i]; const s = signalLine[i];
    result[i] = { macd: m, signal: s, hist: m !== null && s !== null ? m - s : null };
  }
  return result;
}

export interface IndicatorSettings {
  sessions: boolean;
  sessionDays: number;
  bb: boolean;
  rsi: boolean;
  macd: boolean;
}

const SESSIONS = [
  { name: "Asia",  startH: 1, startM: 0,  endH: 5,  endM: 0,  color: "rgba(59,130,246,0.07)",  border: "rgba(59,130,246,0.35)",  label: "rgba(59,130,246,0.7)"  },
  { name: "Lon",   startH: 7, startM: 0,  endH: 9,  endM: 55, color: "rgba(249,115,22,0.07)",  border: "rgba(249,115,22,0.35)",  label: "rgba(249,115,22,0.7)"  },
  { name: "NY",    startH: 12,startM: 0,  endH: 14, endM: 55, color: "rgba(16,185,129,0.07)",  border: "rgba(16,185,129,0.35)",  label: "rgba(16,185,129,0.7)"  },
];

// ─────────────────────────────────────────────
//  CHART ENGINE
// ─────────────────────────────────────────────
const PRICE_AXIS_W = 62;
const TIME_AXIS_H = 22;
const VOL_H_RATIO = 0.15;
const RIGHT_PADDING = 5;

interface ViewState {
  offset: number;
  scale: number;
  scaleY: number;
  offsetY: number;
}

function useChartEngine(
  canvasRef: React.RefObject<HTMLCanvasElement | null>,
  candlesRef: React.RefObject<Candle[]>,
  alertsRef: React.RefObject<ReturnType<typeof useAlerts>["alerts"]>,
  symbol: string,
  drawnLinesRef: React.RefObject<DrawnLine[]>,
  showEMA20Ref: React.RefObject<boolean>,
  showEMA50Ref: React.RefObject<boolean>,
  currentPriceRef: React.RefObject<number>,
  onAlertDragged: (id: string, newPrice: number) => void,
  onCanvasRightClick: (price: number, y: number) => void,
  onLineDrawn: (line: DrawnLine) => void,
  drawModeRef: React.RefObject<DrawMode>,
  onNeedMoreCandles: () => void,
  indicatorsRef: React.RefObject<IndicatorSettings>,
) {
  const viewRef = useRef<ViewState>({
    offset: 0,
    scale: 6,
    scaleY: 1,
    offsetY: 0,
  });
  const isDragging = useRef(false);
  const dragStartX = useRef(0);
  const dragStartOffset = useRef(0);
  const isDraggingY = useRef(false);
  const dragStartY = useRef(0);
  const dragStartOffsetY = useRef(0);
  const dragStartScaleY = useRef(1);
  const draggingAlertId = useRef<string | null>(null);
  const isDrawingLine = useRef(false);
  const lineStart = useRef<{ cx: number; price: number } | null>(null);
  const linePreviewEnd = useRef<{ cx: number; price: number } | null>(null);
  const rafRef = useRef<number>(0);
  const initialOffsetSetRef = useRef(false);
  const prevCandleCountRef = useRef(0);
  const onNeedMoreCandlesRef = useRef(onNeedMoreCandles);
  
  useEffect(() => {
    onNeedMoreCandlesRef.current = onNeedMoreCandles;
  });
  
  const isFetchingMoreRef = useRef(false);

  const priceRangeRef = useRef({
    min: 0,
    max: 1,
    chartH: 1,
    chartW: 1,
    candleW: 10,
    startIdx: 0,
    endIdx: 0,
  });

  const getPriceRange = (vis: Candle[]) => {
    if (!vis.length) return { min: 0, max: 1 };
    let rawMin = Infinity;
    let rawMax = -Infinity;
    for (const c of vis) {
      if (c.low < rawMin) rawMin = c.low;
      if (c.high > rawMax) rawMax = c.high;
    }
    const pad = (rawMax - rawMin) * 0.08;
    rawMin -= pad;
    rawMax += pad;
    const { scaleY, offsetY } = viewRef.current;
    const center = (rawMax + rawMin) / 2 + offsetY;
    const halfRange = ((rawMax - rawMin) / 2) * (1 / scaleY);
    return { min: center - halfRange, max: center + halfRange };
  };

  const priceToY = (price: number, min: number, max: number, chartH: number, volH: number) => 
    ((max - price) / (max - min)) * (chartH - volH - TIME_AXIS_H);

  const yToPrice = (y: number, min: number, max: number, chartH: number, volH: number) => 
    max - (y / (chartH - volH - TIME_AXIS_H)) * (max - min);

  const ciToX = (idx: number, startIdx: number, candleW: number) =>
    (idx - startIdx) * candleW + candleW / 2;

  const xToCI = (x: number, startIdx: number, candleW: number) =>
    startIdx + (x - candleW / 2) / candleW;

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const candles = candlesRef.current ?? [];
    if (!canvas || !candles.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const alerts = alertsRef.current ?? [];
    const drawnLines = drawnLinesRef.current ?? [];
    const showEMA20 = showEMA20Ref.current ?? false;
    const showEMA50 = showEMA50Ref.current ?? false;
    const currentPrice = currentPriceRef.current ?? 0;
    const indicators = indicatorsRef.current ?? { sessions: false, sessionDays: 1, bb: false, rsi: false, macd: false };

    const W = canvas.width;
    const H = canvas.height;
    const chartW = W - PRICE_AXIS_W;
    const volH = (H - TIME_AXIS_H) * VOL_H_RATIO;
    const priceH = H - volH - TIME_AXIS_H;

    if (!initialOffsetSetRef.current && candles.length > 0) {
      const candleW = Math.max(2, viewRef.current.scale);
      const visCount = Math.floor(chartW / candleW);
      viewRef.current = {
        ...viewRef.current,
        offset: Math.max(0, candles.length - visCount + RIGHT_PADDING),
      };
      initialOffsetSetRef.current = true;
      prevCandleCountRef.current = candles.length;
    }

    if (candles.length > prevCandleCountRef.current) {
      const candleW = Math.max(2, viewRef.current.scale);
      const visCount = Math.floor(chartW / candleW);
      const isAtRightEdge = viewRef.current.offset >= candles.length - visCount + RIGHT_PADDING - 3;
      if (isAtRightEdge) {
        viewRef.current = {
          ...viewRef.current,
          offset: candles.length - visCount + RIGHT_PADDING,
        };
      }
      prevCandleCountRef.current = candles.length;
    }

    const { offset, scale } = viewRef.current;
    const candleW = Math.max(2, scale);
    const visCount = Math.ceil(chartW / candleW) + 1;
    const startIdx = Math.max(0, Math.floor(offset));
    const endIdx = Math.min(candles.length - 1, startIdx + visCount);
    const visCandles = candles.slice(startIdx, endIdx + 1);

    if (startIdx <= 20 && !isFetchingMoreRef.current && candles.length > 0) {
      isFetchingMoreRef.current = true;
      onNeedMoreCandlesRef.current();
    }

    const { min, max } = getPriceRange(visCandles);
    priceRangeRef.current = { min, max, chartH: H, chartW, candleW, startIdx, endIdx };

    ctx.fillStyle = "#0d0d0d";
    ctx.fillRect(0, 0, W, H);

    if (indicators.sessions) {
      const sessionDays = Math.max(1, Math.min(7, indicators.sessionDays ?? 1));
      const utcDaySet = new Set<string>();
      for (let i = startIdx; i <= endIdx; i++) {
        const c = candles[i];
        if (!c) continue;
        const d = new Date(c.time * 1000);
        utcDaySet.add(`${d.getUTCFullYear()}-${d.getUTCMonth()}-${d.getUTCDate()}`);
      }
      const utcDays = [...utcDaySet].slice(-sessionDays);

      for (const sess of SESSIONS) {
        const startMins = sess.startH * 60 + sess.startM;
        const endMins   = sess.endH   * 60 + sess.endM;

        for (const day of utcDays) {
          let sessStartX: number | null = null;
          let sessEndX:   number | null = null;
          let sessHigh = -Infinity, sessLow = Infinity;

          for (let i = startIdx; i <= endIdx; i++) {
            const c = candles[i];
            if (!c) continue;
            const d = new Date(c.time * 1000);
            const cDay = `${d.getUTCFullYear()}-${d.getUTCMonth()}-${d.getUTCDate()}`;
            if (cDay !== day) continue;

            const mins = d.getUTCHours() * 60 + d.getUTCMinutes();
            if (mins < startMins || mins >= endMins) continue;

            const cx = ciToX(i, startIdx, candleW);
            if (sessStartX === null) sessStartX = cx - candleW / 2;
            sessEndX = cx + candleW / 2;
            if (c.high > sessHigh) sessHigh = c.high;
            if (c.low  < sessLow)  sessLow  = c.low;
          }

          if (sessStartX === null || sessEndX === null) continue;

          const y1 = priceToY(sessHigh, min, max, H, volH);
          const y2 = priceToY(sessLow,  min, max, H, volH);
          const rectW = sessEndX - sessStartX;

          ctx.fillStyle = sess.color;
          ctx.fillRect(sessStartX, y1, rectW, y2 - y1);
          
          ctx.strokeStyle = sess.border;
          ctx.lineWidth = 1;
          ctx.setLineDash([]);
          ctx.strokeRect(sessStartX, y1, rectW, y2 - y1);
          
          ctx.setLineDash([3, 3]);
          ctx.lineWidth = 0.8;
          [sessHigh, sessLow].forEach((price) => {
            const py = priceToY(price, min, max, H, volH);
            ctx.strokeStyle = sess.border;
            ctx.beginPath();
            ctx.moveTo(sessEndX!, py);
            ctx.lineTo(Math.min(sessEndX! + 40, chartW), py);
            ctx.stroke();
          });
          ctx.setLineDash([]);
          
          if (rectW > 16) {
            ctx.fillStyle = sess.label;
            ctx.font = "bold 9px monospace";
            ctx.textAlign = "left";
            ctx.fillText(sess.name, sessStartX + 3, y1 + 10);
          }
        }
      }
    }

    ctx.strokeStyle = "#161616";
    ctx.lineWidth = 1;
    ctx.setLineDash([]);
    for (let i = 0; i <= 5; i++) {
      const y = (i / 5) * priceH;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartW, y);
      ctx.stroke();
    }

    ctx.fillStyle = "#3a3a3a";
    ctx.font = "10px 'JetBrains Mono', 'Fira Mono', monospace";
    ctx.textAlign = "left";
    for (let i = 0; i <= 5; i++) {
      const y = (i / 5) * priceH;
      const price = max - (i / 5) * (max - min);
      const lbl =
        price < 0.01
          ? price.toFixed(6)
          : price < 1
            ? price.toFixed(4)
            : price < 100
              ? price.toFixed(2)
              : price.toFixed(0);
      ctx.fillText(lbl, chartW + 4, y + 3);
    }

    if (indicators.rsi) {
      const rsi = calcRSI(candles.map((c) => c.close));
      const rsiY = (v: number) => H - TIME_AXIS_H - volH + (1 - v / 100) * volH * 0.9 + volH * 0.05;
      
      ctx.strokeStyle = "rgba(255,255,255,0.06)";
      ctx.lineWidth = 0.8;
      ctx.setLineDash([2, 2]);
      [30, 50, 70].forEach((lvl) => {
        const y = rsiY(lvl);
        ctx.beginPath(); 
        ctx.moveTo(0, y); 
        ctx.lineTo(chartW, y); 
        ctx.stroke();
        
        ctx.fillStyle = "rgba(255,255,255,0.2)";
        ctx.font = "8px monospace"; 
        ctx.textAlign = "left";
        ctx.fillText(String(lvl), 2, y - 1);
      });
      ctx.setLineDash([]);
      
      ctx.strokeStyle = "rgba(234,179,8,0.9)";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      let rsiStarted = false;
      for (let i = startIdx; i <= endIdx; i++) {
        const v = rsi[i];
        if (v === null) continue;
        const x = ciToX(i, startIdx, candleW);
        const y = rsiY(v);
        if (!rsiStarted) { 
          ctx.moveTo(x, y); 
          rsiStarted = true; 
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
      
    } else if (indicators.macd) {
      const macdData = calcMACD(candles.map((c) => c.close));
      const vis = macdData.slice(startIdx, endIdx + 1).filter((p) => p.hist !== null);
      
      if (vis.length > 0) {
        const histVals = vis.map((p) => Math.abs(p.hist as number));
        const macdMax = Math.max(...histVals, 0.0001);
        const macdY = (v: number) => {
          const mid = H - TIME_AXIS_H - volH / 2;
          return mid - (v / macdMax) * (volH * 0.42);
        };
        
        ctx.strokeStyle = "rgba(255,255,255,0.1)";
        ctx.lineWidth = 0.8; 
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(0, H - TIME_AXIS_H - volH / 2);
        ctx.lineTo(chartW, H - TIME_AXIS_H - volH / 2);
        ctx.stroke();
        
        for (let i = startIdx; i <= endIdx; i++) {
          const p = macdData[i];
          if (p.hist === null) continue;
          const x = ciToX(i, startIdx, candleW);
          const mid = H - TIME_AXIS_H - volH / 2;
          const barH = Math.abs(p.hist / macdMax) * volH * 0.42;
          ctx.fillStyle = p.hist >= 0 ? "rgba(38,166,154,0.5)" : "rgba(239,83,80,0.5)";
          ctx.fillRect(x - candleW * 0.35, p.hist >= 0 ? mid - barH : mid, candleW * 0.7, barH);
        }
        
        ctx.strokeStyle = "rgba(59,130,246,0.85)";
        ctx.lineWidth = 1; 
        ctx.beginPath();
        let ms = false;
        for (let i = startIdx; i <= endIdx; i++) {
          const p = macdData[i];
          if (p.macd === null) continue;
          const x = ciToX(i, startIdx, candleW);
          const y = macdY(p.macd);
          if (!ms) { 
            ctx.moveTo(x, y); 
            ms = true; 
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
        
        ctx.strokeStyle = "rgba(249,115,22,0.85)";
        ctx.lineWidth = 1; 
        ctx.beginPath();
        let ss = false;
        for (let i = startIdx; i <= endIdx; i++) {
          const p = macdData[i];
          if (p.signal === null) continue;
          const x = ciToX(i, startIdx, candleW);
          const y = macdY(p.signal);
          if (!ss) { 
            ctx.moveTo(x, y); 
            ss = true; 
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }
    } else {
      const volMax = Math.max(...visCandles.map((c) => c.value), 1);
      for (let i = startIdx; i <= endIdx; i++) {
        const c = candles[i];
        if (!c) continue;
        const x = ciToX(i, startIdx, candleW);
        const barH = (c.value / volMax) * volH * 0.9;
        ctx.fillStyle = c.close >= c.open ? "rgba(38,166,154,0.3)" : "rgba(239,83,80,0.3)";
        ctx.fillRect(x - candleW * 0.4, H - TIME_AXIS_H - barH, candleW * 0.8, barH);
      }
    }

    if (showEMA20) {
      const ema = calcEMA(candles.map((c) => c.close), 20);
      ctx.strokeStyle = "rgba(59,130,246,0.85)";
      ctx.lineWidth = 1.2;
      ctx.setLineDash([]);
      ctx.beginPath();
      let started = false;
      for (let i = startIdx; i <= endIdx; i++) {
        const v = ema[i];
        if (v === null) continue;
        const x = ciToX(i, startIdx, candleW);
        const y = priceToY(v, min, max, H, volH);
        if (!started) {
          ctx.moveTo(x, y);
          started = true;
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
      
      if (started) {
        const last = ema[Math.min(endIdx, candles.length - 1)];
        if (last !== null) {
          const ly = priceToY(last, min, max, H, volH);
          ctx.fillStyle = "rgba(59,130,246,0.9)";
          ctx.font = "bold 9px monospace";
          ctx.fillText("EMA20", chartW - 46, ly - 3);
        }
      }
    }

    if (showEMA50) {
      const ema = calcEMA(candles.map((c) => c.close), 50);
      ctx.strokeStyle = "rgba(249,115,22,0.85)";
      ctx.lineWidth = 1.2;
      ctx.setLineDash([]);
      ctx.beginPath();
      let started = false;
      for (let i = startIdx; i <= endIdx; i++) {
        const v = ema[i];
        if (v === null) continue;
        const x = ciToX(i, startIdx, candleW);
        const y = priceToY(v, min, max, H, volH);
        if (!started) {
          ctx.moveTo(x, y);
          started = true;
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
      
      if (started) {
        const last = ema[Math.min(endIdx, candles.length - 1)];
        if (last !== null) {
          const ly = priceToY(last, min, max, H, volH);
          ctx.fillStyle = "rgba(249,115,22,0.9)";
          ctx.font = "bold 9px monospace";
          ctx.fillText("EMA50", chartW - 46, ly - 3);
        }
      }
    }

    if (indicators.bb) {
      const bbData = calcBB(candles.map((c) => c.close));
      const drawBBLine = (values: (number | null)[], color: string, dash: number[] = []) => {
        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        ctx.setLineDash(dash);
        ctx.beginPath();
        let started = false;
        for (let i = startIdx; i <= endIdx; i++) {
          const v = values[i];
          if (v === null) continue;
          const x = ciToX(i, startIdx, candleW);
          const y = priceToY(v, min, max, H, volH);
          if (!started) { 
            ctx.moveTo(x, y); 
            started = true; 
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
        ctx.setLineDash([]);
      };
      
      ctx.beginPath();
      let filled = false;
      for (let i = startIdx; i <= endIdx; i++) {
        const b = bbData[i];
        if (!b.upper) continue;
        const x = ciToX(i, startIdx, candleW);
        const y = priceToY(b.upper, min, max, H, volH);
        if (!filled) { 
          ctx.moveTo(x, y); 
          filled = true; 
        } else {
          ctx.lineTo(x, y);
        }
      }
      for (let i = endIdx; i >= startIdx; i--) {
        const b = bbData[i];
        if (!b.lower) continue;
        const x = ciToX(i, startIdx, candleW);
        const y = priceToY(b.lower, min, max, H, volH);
        ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fillStyle = "rgba(147,197,253,0.04)";
      ctx.fill();
      
      drawBBLine(bbData.map((b) => b.upper), "rgba(147,197,253,0.5)", [3, 3]);
      drawBBLine(bbData.map((b) => b.mid),   "rgba(147,197,253,0.3)", []);
      drawBBLine(bbData.map((b) => b.lower), "rgba(147,197,253,0.5)", [3, 3]);
    }

    for (let i = startIdx; i <= endIdx; i++) {
      const c = candles[i];
      if (!c) continue;
      const x = ciToX(i, startIdx, candleW);
      const isGreen = c.close >= c.open;
      const col = isGreen ? "#26a69a" : "#ef5350";
      const bTop = priceToY(Math.max(c.open, c.close), min, max, H, volH);
      const bBot = priceToY(Math.min(c.open, c.close), min, max, H, volH);
      const wTop = priceToY(c.high, min, max, H, volH);
      const wBot = priceToY(c.low, min, max, H, volH);
      const bH = Math.max(1, bBot - bTop);
      const bW = Math.max(1, candleW * 0.7);
      
      ctx.strokeStyle = col;
      ctx.lineWidth = 1;
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(x, wTop);
      ctx.lineTo(x, wBot);
      ctx.stroke();
      
      ctx.fillStyle = col;
      ctx.fillRect(x - bW / 2, bTop, bW, bH);
    }

    ctx.setLineDash([]);
    for (const line of drawnLines) {
      const x1 = ciToX(line.x1, startIdx, candleW);
      const y1 = priceToY(line.y1, min, max, H, volH);
      const x2 = ciToX(line.x2, startIdx, candleW);
      const y2 = priceToY(line.y2, min, max, H, volH);
      
      ctx.strokeStyle = "rgba(147,197,253,0.75)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      
      ctx.fillStyle = "rgba(147,197,253,0.9)";
      ctx.beginPath();
      ctx.arc(x1, y1, 3, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.beginPath();
      ctx.arc(x2, y2, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    if (isDrawingLine.current && lineStart.current && linePreviewEnd.current) {
      const s = lineStart.current;
      const e = linePreviewEnd.current;
      ctx.strokeStyle = "rgba(147,197,253,0.4)";
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(
        ciToX(s.cx, startIdx, candleW),
        priceToY(s.price, min, max, H, volH),
      );
      ctx.lineTo(
        ciToX(e.cx, startIdx, candleW),
        priceToY(e.price, min, max, H, volH),
      );
      ctx.stroke();
      ctx.setLineDash([]);
    }

    const symAlerts = alerts.filter(
      (a) => a.symbol === symbol && a.status === "active",
    );
    for (const al of symAlerts) {
      if (al.targetPrice == null) continue;
      const y = priceToY(al.targetPrice, min, max, H, volH);
      if (y < -10 || y > priceH + 10) continue;
      const isDrag = draggingAlertId.current === al.id;

      ctx.save();
      ctx.shadowColor = isDrag ? "#eab308" : "rgba(234,179,8,0.35)";
      ctx.shadowBlur = isDrag ? 12 : 6;
      ctx.strokeStyle = isDrag ? "#fde047" : "#eab308";
      ctx.lineWidth = isDrag ? 2 : 1.5;
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartW, y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      ctx.fillStyle = isDrag ? "rgba(234,179,8,0.2)" : "rgba(234,179,8,0.1)";
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(chartW - 20, y - 9, 18, 18, 3);
      else ctx.rect(chartW - 20, y - 9, 18, 18);
      ctx.fill();

      ctx.fillStyle = isDrag ? "#fde047" : "#d97706";
      ctx.font = "bold 9px monospace";
      ctx.textAlign = "left";
      const pl =
        al.targetPrice < 0.01
          ? al.targetPrice.toFixed(6)
          : al.targetPrice < 1
            ? al.targetPrice.toFixed(4)
            : al.targetPrice < 100
              ? al.targetPrice.toFixed(2)
              : al.targetPrice.toFixed(0);
      ctx.fillText(pl, chartW + 4, y + 4);
    }

    if (currentPrice > 0 && currentPrice >= min && currentPrice <= max) {
      const py = priceToY(currentPrice, min, max, H, volH);
      const lastCandle = candles[candles.length - 1];
      const isUp = lastCandle ? lastCandle.close >= lastCandle.open : true;
      const lineColor = isUp ? "#26a69a" : "#ef5350";

      ctx.save();
      ctx.strokeStyle = lineColor;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.globalAlpha = 0.75;
      ctx.beginPath();
      ctx.moveTo(0, py);
      ctx.lineTo(chartW, py);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.globalAlpha = 1;

      const priceLabel =
        currentPrice < 0.01
          ? currentPrice.toFixed(6)
          : currentPrice < 1
            ? currentPrice.toFixed(4)
            : currentPrice < 100
              ? currentPrice.toFixed(2)
              : currentPrice.toFixed(0);
      
      const labelW = PRICE_AXIS_W - 4;
      const labelH = 14;
      
      ctx.fillStyle = lineColor;
      if (ctx.roundRect) {
        ctx.roundRect(chartW + 2, py - labelH / 2, labelW, labelH, 2);
      } else {
        ctx.rect(chartW + 2, py - labelH / 2, labelW, labelH);
      }
      ctx.fill();
      
      ctx.fillStyle = "#0d0d0d";
      ctx.font = "bold 9px monospace";
      ctx.textAlign = "left";
      ctx.fillText(priceLabel, chartW + 5, py + 4);
      ctx.restore();
    }

    ctx.fillStyle = "#2a2a2a";
    ctx.font = "9px monospace";
    ctx.textAlign = "center";
    ctx.setLineDash([]);
    const step = Math.max(1, Math.floor(20 / candleW));
    for (let i = startIdx; i <= endIdx; i += step) {
      const c = candles[i];
      if (!c) continue;
      const x = ciToX(i, startIdx, candleW);
      const d = new Date(c.time * 1000);
      const lbl = `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
      ctx.fillText(lbl, x, H - TIME_AXIS_H + 14);
    }

    ctx.strokeStyle = "#1e1e1e";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, H - TIME_AXIS_H - volH);
    ctx.lineTo(chartW, H - TIME_AXIS_H - volH);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(chartW, 0);
    ctx.lineTo(chartW, H);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(0, H - TIME_AXIS_H);
    ctx.lineTo(W, H - TIME_AXIS_H);
    ctx.stroke();
    
  }, [symbol]); // eslint-disable-line react-hooks/exhaustive-deps

  const scheduleRedraw = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(draw);
  }, [draw]);

  const getAlertAtY = useCallback(
    (y: number): string | null => {
      const { min, max, chartH } = priceRangeRef.current;
      const volH = (chartH - TIME_AXIS_H) * VOL_H_RATIO;
      const alerts = alertsRef.current ?? [];
      
      for (const al of alerts) {
        if (al.symbol !== symbol || al.status !== "active") continue;
        const ay = priceToY(al.targetPrice, min, max, chartH, volH);
        if (Math.abs(y - ay) < 9) return al.id;
      }
      return null;
    },
    [symbol, alertsRef],
  );

  const handleWheel = useCallback(
    (e: WheelEvent) => {
      e.preventDefault();
      const { offset, scale, scaleY, offsetY } = viewRef.current;
      
      if (e.shiftKey) {
        const newScaleY = Math.max(
          0.001,
          scaleY * (e.deltaY < 0 ? 1.12 : 0.89),
        );
        viewRef.current = { offset, scale, scaleY: newScaleY, offsetY };
      } else {
        const newScale = Math.max(
          2,
          Math.min(80, scale * (e.deltaY < 0 ? 1.15 : 0.87)),
        );
        viewRef.current = { offset, scale: newScale, scaleY, offsetY };
      }
      scheduleRedraw();
    },
    [scheduleRedraw],
  );

  const getCanvasPos = (e: MouseEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) * (canvas.width / rect.width),
      y: (e.clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  const handleMouseDown = useCallback(
    (e: MouseEvent) => {
      if (e.button === 2) return;
      
      const { x, y } = getCanvasPos(e);
      const { min, max, chartH, chartW, candleW, startIdx } =
        priceRangeRef.current;
      const volH = (chartH - TIME_AXIS_H) * VOL_H_RATIO;
      const price = yToPrice(y, min, max, chartH, volH);
      const drawMode = drawModeRef.current ?? "none";

      if (x >= chartW) {
        isDraggingY.current = true;
        dragStartY.current = e.clientY;
        dragStartOffsetY.current = viewRef.current.offsetY;
        dragStartScaleY.current = viewRef.current.scaleY;
        (isDraggingY as any)._isPan = e.ctrlKey || e.metaKey;
        canvasRef.current!.style.cursor = "ns-resize";
        return;
      }

      if (drawMode === "line") {
        if (!isDrawingLine.current) {
          isDrawingLine.current = true;
          lineStart.current = { cx: xToCI(x, startIdx, candleW), price };
          linePreviewEnd.current = { cx: xToCI(x, startIdx, candleW), price };
        } else if (lineStart.current) {
          onLineDrawn({
            id: `line-${Date.now()}`,
            x1: lineStart.current.cx,
            y1: lineStart.current.price,
            x2: xToCI(x, startIdx, candleW),
            y2: price,
          });
          isDrawingLine.current = false;
          lineStart.current = null;
          linePreviewEnd.current = null;
          scheduleRedraw();
        }
        return;
      }

      const alertId = getAlertAtY(y);
      if (alertId) {
        draggingAlertId.current = alertId;
        canvasRef.current!.style.cursor = "ns-resize";
        return;
      }

      isDragging.current = true;
      dragStartX.current = e.clientX;
      dragStartY.current = e.clientY;
      dragStartOffset.current = viewRef.current.offset;
      dragStartOffsetY.current = viewRef.current.offsetY;
      canvasRef.current!.style.cursor = "grabbing";
    },
    [getAlertAtY, onLineDrawn, scheduleRedraw, drawModeRef],
  );

  const handleMouseMove = useCallback(
    (e: MouseEvent) => {
      const { x, y } = getCanvasPos(e);
      const { min, max, chartH, chartW, candleW, startIdx } =
        priceRangeRef.current;
      const volH = (chartH - TIME_AXIS_H) * VOL_H_RATIO;
      const candles = candlesRef.current ?? [];
      const drawMode = drawModeRef.current ?? "none";

      if (isDraggingY.current) {
        const pixelDelta = e.clientY - dragStartY.current;
        const isPan = (isDraggingY as any)._isPan;
        
        if (isPan) {
          const priceRange = max - min;
          const canvas = canvasRef.current!;
          const priceDelta = (pixelDelta / canvas.height) * priceRange;
          viewRef.current = {
            ...viewRef.current,
            offsetY: dragStartOffsetY.current - priceDelta,
          };
        } else {
          const factor = Math.pow(1.008, -pixelDelta);
          const newScaleY = Math.max(0.001, dragStartScaleY.current * factor);
          viewRef.current = {
            ...viewRef.current,
            scaleY: newScaleY,
          };
        }
        scheduleRedraw();
        return;
      }
      
      if (draggingAlertId.current) {
        onAlertDragged(
          draggingAlertId.current,
          yToPrice(y, min, max, chartH, volH),
        );
        scheduleRedraw();
        return;
      }
      
      if (isDrawingLine.current && lineStart.current) {
        linePreviewEnd.current = {
          cx: xToCI(x, startIdx, candleW),
          price: yToPrice(y, min, max, chartH, volH),
        };
        scheduleRedraw();
        return;
      }
      
      if (isDragging.current) {
        const deltaX = (e.clientX - dragStartX.current) / viewRef.current.scale;
        
        const priceRange = max - min;
        const canvas = canvasRef.current!;
        const deltaY = (e.clientY - dragStartY.current) / canvas.height * priceRange;
        
        viewRef.current = {
          ...viewRef.current,
          offset: Math.min(candles.length - 1, dragStartOffset.current - deltaX),
          offsetY: dragStartOffsetY.current + deltaY,
        };
        scheduleRedraw();
        return;
      }
      
      if (x < chartW) {
        canvasRef.current!.style.cursor =
          drawMode === "line"
            ? "crosshair"
            : getAlertAtY(y)
              ? "ns-resize"
              : "crosshair";
      } else {
        canvasRef.current!.style.cursor = "ns-resize";
      }
    },
    [candlesRef, drawModeRef, getAlertAtY, onAlertDragged, scheduleRedraw],
  );

  const handleMouseUp = useCallback(() => {
    if (draggingAlertId.current) {
      draggingAlertId.current = null;
      scheduleRedraw();
    }
    isDragging.current = false;
    isDraggingY.current = false;
    if (canvasRef.current) canvasRef.current.style.cursor = "crosshair";
  }, [scheduleRedraw]);

  const handleContextMenu = useCallback(
    (e: MouseEvent) => {
      e.preventDefault();
      const { x, y } = getCanvasPos(e);
      const { min, max, chartH, chartW } = priceRangeRef.current;
      
      if (x > chartW) return;
      
      const volH = (chartH - TIME_AXIS_H) * VOL_H_RATIO;
      const price = yToPrice(y, min, max, chartH, volH);
      
      if (price > 0) {
        onCanvasRightClick(
          price,
          e.clientY - canvasRef.current!.getBoundingClientRect().top,
        );
      }
    },
    [onCanvasRightClick],
  );

  const handleDblClick = useCallback(
    (e: MouseEvent) => {
      const { x } = getCanvasPos(e);
      const { chartW } = priceRangeRef.current;
      
      if (x >= chartW) {
        const canvas = canvasRef.current;
        const candles = candlesRef.current ?? [];
        const visCount = canvas
          ? Math.floor((canvas.width - PRICE_AXIS_W) / Math.max(2, viewRef.current.scale))
          : 50;
          
        viewRef.current = {
          ...viewRef.current,
          scaleY: 1,
          offsetY: 0,
          offset: Math.max(0, candles.length - visCount + RIGHT_PADDING),
        };
        scheduleRedraw();
      }
    },
    [scheduleRedraw, candlesRef],
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    canvas.addEventListener("wheel", handleWheel, { passive: false });
    canvas.addEventListener("mousedown", handleMouseDown);
    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseup", handleMouseUp);
    canvas.addEventListener("mouseleave", handleMouseUp);
    canvas.addEventListener("contextmenu", handleContextMenu);
    canvas.addEventListener("dblclick", handleDblClick);
    
    return () => {
      canvas.removeEventListener("wheel", handleWheel);
      canvas.removeEventListener("mousedown", handleMouseDown);
      canvas.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseup", handleMouseUp);
      canvas.removeEventListener("mouseleave", handleMouseUp);
      canvas.removeEventListener("contextmenu", handleContextMenu);
      canvas.removeEventListener("dblclick", handleDblClick);
    };
  }, [
    handleWheel,
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    handleContextMenu,
    handleDblClick,
  ]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ro = new ResizeObserver(() => {
      const p = canvas.parentElement;
      if (p) {
        canvas.width = p.clientWidth;
        canvas.height = p.clientHeight;
      }
      scheduleRedraw();
    });
    
    const p = canvas.parentElement;
    if (p) {
      canvas.width = p.clientWidth;
      canvas.height = p.clientHeight;
      ro.observe(p);
    }
    
    return () => ro.disconnect();
  }, [scheduleRedraw]);

  const prevSymbolRef = useRef(symbol);
  useEffect(() => {
    if (prevSymbolRef.current !== symbol) {
      initialOffsetSetRef.current = false;
      prevSymbolRef.current = symbol;
    }
  }, [symbol]);

  return { scheduleRedraw, isFetchingMoreRef };
}

// ─────────────────────────────────────────────
//  COMPONENT
// ─────────────────────────────────────────────
export default function RealChartCard({
  symbol,
  interval = "15m",
  onExpand,
  isDark = true,
  primaryExchange,
  isFocusMode = false,
  label,
  highlighted = false,
  group = null,
  onSetGroup,
  indicators,
}: RealChartCardProps) {
  const { t } = useLanguage(); 
  const [showGroupPicker, setShowGroupPicker] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [chartData, setChartData] = useState<Candle[]>([]);
  const [source, setSource] = useState("...");
  const [stats, setStats] = useState({
    change: 0,
    range: 0,
    natr: 0,
    correlation: 0,
    vol: "0",
    price: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isVisible, setIsVisible] = useState(true);
  const [alertPopup, setAlertPopup] = useState<{
    price: number;
    y: number;
  } | null>(null);
  const [drawnLines, setDrawnLines] = useState<DrawnLine[]>([]);
  const [drawMode, setDrawMode] = useState<DrawMode>("none");
  const [showEMA20, setShowEMA20] = useState(false);
  const [showEMA50, setShowEMA50] = useState(false);

  const [densityHighlight, setDensityHighlight] = useState<"BID" | "ASK" | null>(() => {
    if (typeof window !== "undefined") {
      const pending = (window as any).__pendingDensityHighlight;
      if (pending && pending.symbol === symbol && Date.now() < pending.expires) {
        return pending.type;
      }
    }
    return null;
  });

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;

    if (typeof window !== "undefined") {
      const pending = (window as any).__pendingDensityHighlight;
      if (pending && pending.symbol === symbol && Date.now() < pending.expires) {
        setDensityHighlight(pending.type);
        timer = setTimeout(() => {
          setDensityHighlight(null);
          (window as any).__pendingDensityHighlight = null;
        }, 4000); 
      }
    }

    const handler = (e: any) => {
      if (e.detail.symbol === symbol) {
        setDensityHighlight(e.detail.type);
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => setDensityHighlight(null), 4000);
      }
    };
    
    window.addEventListener("density-focus", handler);
    return () => {
      window.removeEventListener("density-focus", handler);
      if (timer) clearTimeout(timer);
    };
  }, [symbol]);

  const { alerts, addAlert, triggerAlert, removeAlert } = useAlerts();

  const chartDataRef = useRef<Candle[]>([]);
  const alertsRef = useRef(alerts);
  const drawnLinesRef = useRef<DrawnLine[]>([]);
  const showEMA20Ref = useRef(false);
  const showEMA50Ref = useRef(false);
  const currentPriceRef = useRef(0);
  const drawModeRef = useRef<DrawMode>("none");
  const indicatorsRef = useRef<IndicatorSettings>(
    indicators ?? { sessions: false, sessionDays: 1, bb: false, rsi: false, macd: false }
  );

  useEffect(() => {
    indicatorsRef.current = indicators ?? { sessions: false, sessionDays: 1, bb: false, rsi: false, macd: false };
  }, [indicators]);

  chartDataRef.current = chartData;
  alertsRef.current = alerts;
  drawnLinesRef.current = drawnLines;
  showEMA20Ref.current = showEMA20;
  
  useEffect(() => {
    showEMA50Ref.current = showEMA50;
  }, [showEMA50]);
  
  useEffect(() => {
    currentPriceRef.current = stats.price;
  }, [stats.price]);
  
  useEffect(() => {
    drawModeRef.current = drawMode;
  }, [drawMode]);

  const playAlertSound = useCallback(() => {
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new Ctx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      
      osc.start();
      gain.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + 0.5);
      osc.stop(ctx.currentTime + 0.5);
    } catch {}
  }, []);

  useEffect(() => {
    if (stats.price === 0) return;
    alerts.forEach((a) => {
      if (a.symbol === symbol && a.status === "active") {
        if (
          (a.direction === "up" && stats.price >= a.targetPrice) ||
          (a.direction === "down" && stats.price <= a.targetPrice)
        ) {
          playAlertSound();
          triggerAlert(a.id);
        }
      }
    });
  }, [stats.price, alerts, symbol, playAlertSound, triggerAlert]);

  const handleAlertDragged = useCallback(
    (id: string, newPrice: number) => {
      const al = alertsRef.current.find((a) => a.id === id);
      if (!al) return;
      removeAlert(id);
      addAlert(al.symbol, newPrice, al.initialPrice);
    },
    [removeAlert, addAlert],
  );

  const handleLineDrawn = useCallback((line: DrawnLine) => {
    setDrawnLines((prev) => [...prev, line]);
    setDrawMode("none");
  }, []);

  const handleCanvasRightClick = useCallback((price: number, y: number) => {
    setAlertPopup({ price, y });
  }, []);

  const isLoadingMoreRef = useRef(false);
  const oldestTimeRef = useRef<number | null>(null);
  const currentSourceRef = useRef(source);
  const currentIntervalRef = useRef(interval);
  const currentSymbolRef = useRef(symbol);
  
  useEffect(() => {
    currentSourceRef.current = source;
    currentIntervalRef.current = interval;
    currentSymbolRef.current = symbol;
  });

  const handleNeedMoreCandles = useCallback(() => {
    if (isLoadingMoreRef.current) return;
    if (oldestTimeRef.current === null) return;
    isLoadingMoreRef.current = true;

    const src = currentSourceRef.current;
    const sym = currentSymbolRef.current;
    const ivl = currentIntervalRef.current;
    const priority = src.includes("BY")
      ? "BYBIT"
      : src.includes("OKX")
        ? "OKX"
        : "BINANCE";
    const endTime = oldestTimeRef.current * 1000 - 1;

    fetch(
      `/api/candles?symbol=${sym}&interval=${ivl}&priority=${priority}&endTime=${endTime}`,
    )
      .then((r) => r.json())
      .then((data) => {
        if (data.candles && Array.isArray(data.candles) && data.candles.length >= 5) {
          const older: Candle[] = data.candles.map((d: any) => ({
            time: parseFloat(d.time),
            open: parseFloat(d.open),
            high: parseFloat(d.high),
            low: parseFloat(d.low),
            close: parseFloat(d.close),
            value: parseFloat(d.value),
            color: d.color,
          }));
          setChartData((prev) => {
            const prevTimes = new Set(prev.map((c) => c.time));
            const newOlder = older.filter((c) => !prevTimes.has(c.time));
            if (!newOlder.length) return prev;
            const merged = [...newOlder, ...prev].sort((a, b) => a.time - b.time);
            oldestTimeRef.current = merged[0].time;
            return merged;
          });
        }
      })
      .catch(() => {})
      .finally(() => {
        isLoadingMoreRef.current = false;
        if (engineRef.current) {
          engineRef.current.isFetchingMoreRef.current = false;
        }
      });
  }, []);

  const engineRef = useRef<ReturnType<typeof useChartEngine> | null>(null);

  const { scheduleRedraw, isFetchingMoreRef } = useChartEngine(
    canvasRef,
    chartDataRef,
    alertsRef,
    symbol,
    drawnLinesRef,
    showEMA20Ref,
    showEMA50Ref,
    currentPriceRef,
    handleAlertDragged,
    handleCanvasRightClick,
    handleLineDrawn,
    drawModeRef,
    handleNeedMoreCandles,
    indicatorsRef,
  );

  useEffect(() => {
    engineRef.current = { scheduleRedraw, isFetchingMoreRef };
  });

  useEffect(() => {
    scheduleRedraw();
  }, [
    chartData,
    alerts,
    drawnLines,
    showEMA20,
    showEMA50,
    indicators,
    stats.price,
    scheduleRedraw,
  ]);

  useEffect(() => {
    let active = true;
    setChartData([]);
    setSource("Loading...");
    setIsLoading(true);
    setIsVisible(true);
    oldestTimeRef.current = null;
    isLoadingMoreRef.current = false;
    
    if (isFetchingMoreRef) isFetchingMoreRef.current = false;
    
    const kill = setTimeout(() => {
      if (active) setIsVisible(false);
    }, 15000);

    (async () => {
      try {
        const priority = `${primaryExchange},BYBIT,OKX`;
        const res = await fetch(
          `/api/candles?symbol=${symbol}&interval=${interval}&priority=${priority}`,
        );
        if (!active) return;
        if (!res.ok) {
          setIsVisible(false);
          return;
        }
        const data = await res.json();
        if (
          data.candles &&
          Array.isArray(data.candles) &&
          data.candles.length >= 10
        ) {
          const mapped: Candle[] = data.candles.map((d: any) => ({
            time: parseFloat(d.time),
            open: parseFloat(d.open),
            high: parseFloat(d.high),
            low: parseFloat(d.low),
            close: parseFloat(d.close),
            value: parseFloat(d.value),
            color: d.color,
          }));

          const closes = mapped.map((c) => c.close);
          const priceMin = Math.min(...closes);
          const priceMax = Math.max(...closes);
          const totalVolume = mapped.reduce((s, c) => s + c.value, 0);
          
          const isDead =
            priceMax === priceMin ||
            totalVolume === 0 ||
            (priceMax - priceMin) / priceMin < 0.0001;

          if (isDead) {
            setIsVisible(false);
            return;
          }
          
          oldestTimeRef.current = mapped[0]?.time ?? null;
          setChartData(mapped);
          
          if (data.source) setSource(data.source);
          if (data.stats) setStats(data.stats);
        } else {
          setIsVisible(false);
        }
      } catch {
        if (active) setIsVisible(false);
      } finally {
        if (active) setIsLoading(false);
        clearTimeout(kill);
      }
    })();
    
    return () => {
      active = false;
      clearTimeout(kill);
    };
  }, [symbol, interval, primaryExchange]);

  const sourceRef = useRef(source);
  useEffect(() => {
    sourceRef.current = source;
  }, [source]);

  useEffect(() => {
    if (!isVisible) return;
    if (isLoading) return;

    const poll = async () => {
      try {
        const priority = `${primaryExchange},BYBIT,OKX`;
        const res = await fetch(
          `/api/candles?symbol=${symbol}&interval=${interval}&priority=${priority}`,
        );
        if (!res.ok) return;
        const data = await res.json();
        if (!data.candles || data.candles.length < 2) return;

        const fresh: Candle[] = data.candles.slice(-5).map((d: any) => ({
          time: parseFloat(d.time),
          open: parseFloat(d.open),
          high: parseFloat(d.high),
          low: parseFloat(d.low),
          close: parseFloat(d.close),
          value: parseFloat(d.value),
          color: d.color,
        }));

        setChartData((prev) => {
          if (!prev.length) return prev;
          let next = [...prev];
          for (const c of fresh) {
            const idx = next.findIndex((x) => x.time === c.time);
            if (idx >= 0) {
              next[idx] = c;
            } else if (c.time > next[next.length - 1].time) {
              next.push(c);
            }
          }
          chartDataRef.current = next;
          return next;
        });

        const lastCandle = fresh[fresh.length - 1];
        setStats((prev) => ({ ...prev, price: lastCandle.close }));
        if (data.stats) {
          setStats(data.stats);
        }
        engineRef.current?.scheduleRedraw();
      } catch {}
    };

    const id = setInterval(poll, 3000);
    return () => clearInterval(id);
  }, [symbol, interval, primaryExchange, isVisible, isLoading]);

  useChartWS(symbol, interval, useCallback((candle: Candle) => {
    if (!isVisible) return;
    setChartData((prev) => {
      const last = prev[prev.length - 1];
      const next = last?.time === candle.time
        ? [...prev.slice(0, -1), candle]
        : [...prev, candle];
      chartDataRef.current = next;
      return next;
    });
    setStats((prev) => ({ ...prev, price: candle.close }));
    engineRef.current?.scheduleRedraw();
  }, [isVisible]));

  const heatmap = (v: number, lo: number, hi: number) => {
    const a = Math.abs(v);
    const neg = v < 0;
    if (a > hi)
      return neg
        ? "bg-rose-500/20 text-rose-500 border-rose-500/40"
        : "bg-cyan-500/20 text-cyan-500 border-cyan-500/40";
    if (a > lo)
      return neg
        ? "bg-rose-500/10 text-rose-400 border-rose-500/20"
        : "bg-cyan-500/10 text-cyan-400 border-cyan-500/20";
    return "text-gray-500 border-[#222] bg-[#111]/50";
  };

  if (!isVisible) return null;

  const isPos = stats.change >= 0;
  const activeAlerts = alerts.filter(
    (a) => a.symbol === symbol && a.status === "active",
  );

  const GROUP_BORDER: Record<number, string> = {
    1: "border-blue-500   shadow-[0_0_12px_rgba(59,130,246,0.2)]",
    2: "border-violet-500 shadow-[0_0_12px_rgba(139,92,246,0.2)]",
    3: "border-amber-500  shadow-[0_0_12px_rgba(245,158,11,0.2)]",
    4: "border-rose-500   shadow-[0_0_12px_rgba(244,63,94,0.2)]",
    5: "border-emerald-500shadow-[0_0_12px_rgba(16,185,129,0.2)]",
  };
  const GROUP_DOT_BG: Record<number, string> = {
    1: "bg-blue-500", 2: "bg-violet-500", 3: "bg-amber-500", 4: "bg-rose-500", 5: "bg-emerald-500",
  };
  const GROUP_LABELS: Record<number, string> = {
    1: t("colorBlue"), 2: t("colorViolet"), 3: t("colorYellow"), 4: t("colorRed"), 5: t("colorGreen"),
  };

  const borderClass = (highlighted || densityHighlight)
    ? (densityHighlight === "ASK" ? "border-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.4)] z-10" : 
       densityHighlight === "BID" ? "border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.4)] z-10" :
       "border-amber-400 shadow-[0_0_20px_rgba(251,191,36,0.4)] z-10")
    : group != null && GROUP_BORDER[group]
    ? GROUP_BORDER[group]
    : "border-[#1e1e1e]";

  return (
    <div
      className={`${isFocusMode ? "h-full w-full" : "h-[180px] w-full"} border flex flex-col relative group overflow-hidden select-none bg-[#0d0d0d] transition-all duration-300 ${borderClass}`}
    >
      {isFocusMode && label && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none">
          <span className="text-4xl font-bold text-gray-500/10">{label}</span>
        </div>
      )}

      {(highlighted || densityHighlight) && (
        <div className="absolute inset-0 z-30 pointer-events-none">
          {densityHighlight ? (
            <div className={`absolute top-1 right-1 flex items-center gap-1 border rounded px-1.5 py-0.5 animate-pulse ${
              densityHighlight === "ASK" ? "bg-rose-500/20 border-rose-500/60" : "bg-emerald-500/20 border-emerald-500/60"
            }`}>
              <Layers size={8} className={densityHighlight === "ASK" ? "text-rose-400" : "text-emerald-400"} />
              <span className={`text-[8px] font-black tracking-wider uppercase ${densityHighlight === "ASK" ? "text-rose-400" : "text-emerald-400"}`}>
                {densityHighlight === "ASK" ? t("densityAsk") : t("densityBid")}
              </span>
            </div>
          ) : (
            <div className="absolute top-1 right-1 flex items-center gap-1 bg-amber-400/20 border border-amber-400/60 rounded px-1.5 py-0.5 animate-pulse">
              <Zap size={8} className="text-amber-400" />
              <span className="text-[8px] font-black text-amber-400 tracking-wider uppercase">{t("impulseLabel")}</span>
            </div>
          )}
        </div>
      )}

      {group != null && !(highlighted || densityHighlight) && (
        <div className={`absolute left-0 top-0 bottom-0 w-[3px] z-20 ${GROUP_DOT_BG[group]}`} />
      )}

      {showGroupPicker && onSetGroup && (
        <div className="absolute top-7 left-1 z-50 bg-[#111] border border-[#2a2a2a] rounded shadow-xl p-1.5 flex flex-col gap-0.5 pointer-events-auto"
          onMouseLeave={() => setShowGroupPicker(false)}>
          {([1,2,3,4,5] as const).map((g) => (
            <button
              key={g}
              onClick={() => { onSetGroup(group === g ? null : g); setShowGroupPicker(false); }}
              className={`flex items-center gap-2 px-2 py-1 rounded text-[10px] font-bold transition-all hover:bg-[#1e1e1e] ${group === g ? "text-white" : "text-gray-500"}`}
            >
              <span className={`w-2 h-2 rounded-full ${GROUP_DOT_BG[g]}`} />
              {GROUP_LABELS[g]}
              {group === g && <span className="ml-auto text-[8px] text-gray-600">✓</span>}
            </button>
          ))}
          {group != null && (
            <button
              onClick={() => { onSetGroup(null); setShowGroupPicker(false); }}
              className="flex items-center gap-2 px-2 py-1 rounded text-[10px] font-bold text-gray-700 hover:text-rose-400 hover:bg-[#1e1e1e] transition-all mt-0.5 border-t border-[#1e1e1e] pt-1"
            >
              {t("colorRemove")}
            </button>
          )}
        </div>
      )}

      <div className="absolute top-0 left-0 right-0 z-20 flex items-start justify-between p-1 pointer-events-none">
        <div className="flex flex-wrap gap-1 items-center pointer-events-auto">
          <div
            title={`${t("sourceLabel")}: ${source}`}
            className="flex items-center gap-1.5 backdrop-blur border px-1.5 py-0.5 rounded text-[10px] bg-[#111]/90 border-[#222]"
          >
            <div
              className={`w-1.5 h-1.5 rounded-full ${isPos ? "bg-emerald-500" : "bg-rose-500"}`}
            />
            <span className="font-bold text-gray-200">{symbol}</span>
            <span
              className={`text-[8px] font-bold uppercase ${source.includes("ERR") ? "text-red-500" : "text-gray-600"}`}
            >
              {source}
            </span>
          </div>
          <div
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] border backdrop-blur ${heatmap(stats.change, 1.0, 5.0)}`}
          >
            {isPos ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
            <span className="font-mono">
              {Math.abs(stats.change).toFixed(2)}%
            </span>
          </div>
          {!isFocusMode && (
            <>
              <div
                title={t("range")}
                className={`hidden sm:flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] border backdrop-blur ${heatmap(stats.range, 0.3, 0.8)}`}
              >
                <span className="opacity-50 text-[8px]">R</span>
                {stats.range.toFixed(2)}
              </div>
              <div
                title="NATR"
                className={`hidden sm:flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] border backdrop-blur ${heatmap(stats.natr, 0.5, 1.0)}`}
              >
                <Zap size={8} />
                <span className="font-mono">{stats.natr.toFixed(2)}</span>
              </div>
              <div
                title={t("corrHint")}
                className={`hidden md:flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] border backdrop-blur ${heatmap(stats.correlation, 0.8, 0.95)}`}
              >
                <LinkIcon size={8} />
                <span className="font-mono">
                  {stats.correlation.toFixed(2)}
                </span>
              </div>
            </>
          )}
        </div>

        <div
          className={`flex gap-0.5 items-center backdrop-blur rounded px-1 py-0.5 pointer-events-auto transition-opacity bg-[#0d0d0d]/80 border border-[#1e1e1e] ${isFocusMode ? "opacity-100" : "opacity-0 group-hover:opacity-100"}`}
        >
          <button
            onClick={() => setShowEMA20((v) => !v)}
            title="EMA 20"
            className={`px-1.5 py-0.5 rounded text-[8px] font-bold transition-colors ${showEMA20 ? "text-blue-400 bg-blue-500/20" : "text-gray-600 hover:text-gray-400"}`}
          >
            E20
          </button>
          <button
            onClick={() => setShowEMA50((v) => !v)}
            title="EMA 50"
            className={`px-1.5 py-0.5 rounded text-[8px] font-bold transition-colors ${showEMA50 ? "text-orange-400 bg-orange-500/20" : "text-gray-600 hover:text-gray-400"}`}
          >
            E50
          </button>
          <div className="w-px h-3 bg-[#2a2a2a] mx-0.5" />
          <button
            onClick={() => setDrawMode((m) => (m === "line" ? "none" : "line"))}
            title={t("drawLineHint")}
            className={`p-1 rounded transition-colors ${drawMode === "line" ? "text-sky-400 bg-sky-500/20" : "text-gray-600 hover:text-gray-300"}`}
          >
            <Minus size={10} />
          </button>
          {drawnLines.length > 0 && (
            <button
              onClick={() => setDrawnLines([])}
              title={t("clearLinesHint")}
              className="p-1 rounded text-gray-600 hover:text-rose-400 transition-colors"
            >
              <EyeOff size={10} />
            </button>
          )}
          {!isFocusMode && onSetGroup && (
            <>
              <div className="w-px h-3 bg-[#2a2a2a] mx-0.5" />
              <button
                onClick={() => setShowGroupPicker((v) => !v)}
                title={t("colorGroupHint")}
                className="p-1 rounded transition-colors text-gray-600 hover:text-gray-300 relative"
              >
                <span className={`block w-2 h-2 rounded-full border ${group != null ? `${GROUP_DOT_BG[group]} border-transparent` : "border-gray-600"}`} />
              </button>
            </>
          )}
          {!isFocusMode && (
            <>
              <div className="w-px h-3 bg-[#2a2a2a] mx-0.5" />
              <button
                onClick={onExpand}
                className="p-1 hover:text-blue-500 text-gray-600 transition-colors"
              >
                <Maximize2 size={10} />
              </button>
            </>
          )}
        </div>
      </div>

      <div className="flex-1 w-full relative min-h-0">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 z-0"
          style={{ cursor: "crosshair" }}
        />

        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center z-10 bg-[#0d0d0d]">
            <div className="w-4 h-4 border-2 border-[#2962ff] border-t-transparent rounded-full animate-spin" />
          </div>
        )}

        {activeAlerts.length > 0 && (
          <div className="absolute top-1 right-1 z-20 pointer-events-none">
            <div className="flex items-center gap-1 bg-yellow-500/15 border border-yellow-500/30 rounded px-1 py-0.5">
              <Bell size={7} className="text-yellow-500" />
              <span className="text-[7px] font-bold text-yellow-400">
                {activeAlerts.length}
              </span>
            </div>
          </div>
        )}

        <div className="absolute bottom-6 left-2 text-[9px] z-20 font-mono pointer-events-none text-[#2a2a2a]">
          {stats.vol}
        </div>

        {drawMode === "line" && (
          <div className="absolute bottom-7 left-1/2 -translate-x-1/2 z-20 pointer-events-none">
            <div className="bg-sky-500/15 border border-sky-500/30 text-sky-400 text-[9px] px-2 py-0.5 rounded font-mono whitespace-nowrap">
              {t("drawInstruction")}
            </div>
          </div>
        )}

        {alertPopup && (
          <div
            className="absolute z-50 pointer-events-auto"
            style={{
              top: Math.min(
                alertPopup.y,
                (canvasRef.current?.clientHeight ?? 200) - 56,
              ),
              left: "50%",
              transform: "translateX(-50%)",
            }}
          >
            <div className="bg-[#0f0f0f] border border-yellow-500/40 rounded shadow-[0_0_24px_rgba(234,179,8,0.12)] px-3 py-2 flex items-center gap-2 text-[11px] font-mono whitespace-nowrap">
              <Bell size={11} className="text-yellow-500" />
              <span className="text-gray-500">{t("alertAt")}</span>
              <span className="text-yellow-400 font-bold">
                {alertPopup.price.toFixed(4)}
              </span>
              <button
                onClick={() => {
                  addAlert(symbol, alertPopup.price, stats.price);
                  setAlertPopup(null);
                }}
                className="ml-1 px-2 py-0.5 bg-yellow-500/15 hover:bg-yellow-500/30 border border-yellow-500/40 text-yellow-400 rounded transition-colors font-bold"
              >
                {t("ok")}
              </button>
              <button
                onClick={() => setAlertPopup(null)}
                className="px-1.5 py-0.5 bg-[#1a1a1a] hover:bg-[#222] border border-[#2a2a2a] text-gray-600 hover:text-gray-300 rounded transition-colors"
              >
                ✕
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}