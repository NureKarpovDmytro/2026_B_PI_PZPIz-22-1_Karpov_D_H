"use client";
import React, { useEffect, useState, useRef, useCallback } from "react";
import { Clock, Bell, Trash2, Zap, Rocket, List, ArrowUpDown, ArrowUp, ArrowDown, X } from "lucide-react";
import { useAlerts } from "./AlertContext";
import { useImpulses } from "./ImpulseContext";
import { ToastCard, WINDOW_SECONDS } from "./ImpulseDetector";
import { useLanguage } from "@/lib/i18n";

// --- КОНФИГ ---
const MAX_PERCENT = 2.0;
const SCALE_FACTOR = 50 / MAX_PERCENT;

// 🛑 АНТИ-СПУФИНГ: Плотность должна провисеть минимум 24 секунды (2 цикла сканирования)
const MIN_ALIVE_MS = 24000; 

// Допуск симметрии для детектора маркетмейкеров:
const MM_DIST_TOL = 0.08; 
const MM_VOL_TOL = 0.25;  
const MM_LAYERS_THRESHOLD = 2; 

type DensityItem = {
  id: string;
  symbol: string;
  price: number;
  currentPrice: number;
  volumeUSD: number;
  type: "BID" | "ASK";
  firstSeen: number;
  distancePercent: number;
  exchange: string;
};

interface CoinData {
  symbol: string;
  change: number;
  natr?: number;
  count?: number;
  volume?: number;
}

interface DensityPanelProps {
  activeTab?: "MAP" | "ALERTS" | "MOVERS" | "LISTINGS";
  visibleTickers?: string[];
  primaryExchange?: string;
  allCoins?: CoinData[];
  coinGroups?: Record<string, number>;
}

// ─────────────────────────────────────────────
// ОПТИМИЗАЦИЯ: Изолированный таймер жизни ордера
// ─────────────────────────────────────────────
function TimeAlive({ firstSeen }: { firstSeen: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);
  const ms = Math.max(0, now - firstSeen);
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  return <span>{m > 0 ? `${m}m` : `${s}s`}</span>;
}

function filterMarketMakers(items: DensityItem[]): DensityItem[] {
  const groups = new Map<string, DensityItem[]>();
  for (const item of items) {
    const key = `${item.symbol}:${item.exchange}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(item);
  }

  const mmIds = new Set<string>();

  for (const [, group] of groups) {
    const bids = group.filter((i) => i.type === "BID");
    const asks = group.filter((i) => i.type === "ASK");

    const mmPairs: Array<[DensityItem, DensityItem]> = [];

    for (const bid of bids) {
      const absBidDist = Math.abs(bid.distancePercent);
      for (const ask of asks) {
        const absAskDist = Math.abs(ask.distancePercent);
        const distSymmetry = Math.abs(absBidDist - absAskDist);
        if (distSymmetry > MM_DIST_TOL) continue;

        const maxVol = Math.max(bid.volumeUSD, ask.volumeUSD);
        const volDiff = Math.abs(bid.volumeUSD - ask.volumeUSD) / maxVol;
        if (volDiff > MM_VOL_TOL) continue;

        mmPairs.push([bid, ask]);
      }
    }

    if (mmPairs.length >= MM_LAYERS_THRESHOLD) {
      for (const [bid, ask] of mmPairs) {
        mmIds.add(bid.id);
        mmIds.add(ask.id);
      }
    }
  }

  return items.filter((i) => !mmIds.has(i.id));
}

function pct(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0;
  const idx = (p / 100) * (sorted.length - 1);
  const lo = Math.floor(idx), hi = Math.ceil(idx);
  return lo === hi ? sorted[lo] : sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

// ─────────────────────────────────────────────
// НОВЫЙ АЛГОРИТМ: Фильтрация шума и поиск Аномалий
// ─────────────────────────────────────────────
function analyzeOrderBook(items: DensityItem[]): DensityItem[] {
  if (items.length < 4) return items;

  const vols = items.map(i => i.volumeUSD).sort((a, b) => a - b);
  const p50 = pct(vols, 50); // Медиана (обычный шум стакана)
  const p80 = pct(vols, 80); // Крупные стандартные ордера
  const p95 = pct(vols, 95); // Аномалии

  // УЖЕСТОЧЕНИЕ ЛОГИКИ:
  // Ордер должен быть минимум в 10 раз больше медианы И в 3 раза больше p80
  const singleThr = Math.max(p50 * 10.0, p80 * 3.0);
  // Для плотных кластеров (несколько ордеров рядом) требования чуть ниже
  const clusterThr = Math.max(p50 * 7.0, p80 * 2.0);
  
  // Безусловный проход для гипер-аномалий
  const p95pass = p95 * 2.0;

  const keep = new Set<string>();

  for (const item of items) {
    if (item.volumeUSD >= p95pass) { keep.add(item.id); continue; }
    if (item.volumeUSD >= singleThr) { keep.add(item.id); continue; }

    const neighbors = items.filter(o =>
      o.id !== item.id &&
      Math.abs(o.distancePercent - item.distancePercent) <= 0.12
    );
    if (neighbors.length >= 1) {
      const clVol = item.volumeUSD + neighbors.reduce((s, o) => s + o.volumeUSD, 0);
      if (clVol >= clusterThr) {
        keep.add(item.id);
        neighbors.forEach(o => keep.add(o.id));
      }
    }
  }

  return items.filter(i => keep.has(i.id));
}

export default function DensityPanel({
  activeTab = "MAP",
  visibleTickers = [],
  primaryExchange = "BINANCE",
  allCoins = [],
  coinGroups = {},
}: DensityPanelProps) {
  const { t } = useLanguage();
  const { alerts, removeAlert } = useAlerts();
  const { navigateToSymbol } = useImpulses();
  
  const [densities, setDensities] = useState<DensityItem[]>([]);
  const [now, setNow] = useState(Date.now());
  const [isScanning, setIsScanning] = useState(false);
  const [selectedDensity, setSelectedDensity] = useState<DensityItem | null>(null);

  const pricesRef = useRef<Map<string, number>>(new Map());
  const lastKnownPricesRef = useRef<Map<string, number>>(new Map());
  const trackerRef = useRef(new Map<string, number>());
  const scanIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const scanTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (activeTab !== "MAP" || visibleTickers.length === 0) return;

    let ws: WebSocket | null = null;
    const targets = visibleTickers.slice(0, 30);

    try {
      if (primaryExchange === "BINANCE") {
        const streams = targets
          .map((s) => `${s.toLowerCase()}usdt@miniTicker`)
          .join("/");
        ws = new WebSocket(`wss://fstream.binance.com/stream?streams=${streams}`);
        ws.onmessage = (event) => {
          const msg = JSON.parse(event.data);
          if (msg.stream && msg.data) {
            const symbol = msg.data.s.replace("USDT", "").toUpperCase();
            const price = parseFloat(msg.data.c);
            pricesRef.current.set(symbol, price);
            lastKnownPricesRef.current.set(symbol, price);
          }
        };
      } else if (primaryExchange === "BYBIT") {
        ws = new WebSocket("wss://stream.bybit.com/v5/public/linear");
        ws.onopen = () => {
          ws?.send(
            JSON.stringify({
              op: "subscribe",
              args: targets.map((s) => `tickers.${s}USDT`),
            }),
          );
        };
        ws.onmessage = (event) => {
          const msg = JSON.parse(event.data);
          if (msg.topic?.startsWith("tickers.")) {
            const symbol = msg.topic.split(".")[1].replace("USDT", "");
            const price = parseFloat(msg.data.lastPrice);
            if (!isNaN(price)) pricesRef.current.set(symbol, price);
            lastKnownPricesRef.current.set(symbol, price);
          }
        };
      } else if (primaryExchange === "OKX") {
        ws = new WebSocket("wss://ws.okx.com:8443/ws/v5/public");
        ws.onopen = () => {
          ws?.send(
            JSON.stringify({
              op: "subscribe",
              args: targets.map((s) => ({ channel: "tickers", instId: `${s}-USDT-SWAP` })),
            }),
          );
        };
        ws.onmessage = (event) => {
          const msg = JSON.parse(event.data);
          if (msg.arg?.channel === "tickers" && msg.data) {
            const data = msg.data[0];
            const symbol = data.instId.split("-")[0];
            const price = parseFloat(data.last);
            if (!isNaN(price)) pricesRef.current.set(symbol, price);
            lastKnownPricesRef.current.set(symbol, price);
          }
        };
      }
    } catch (e) {
      console.error("WS Error:", e);
    }

    return () => { ws?.close(); };
  }, [activeTab, visibleTickers, primaryExchange]);

  const scanMarket = useCallback(async () => {
    const targets =
      visibleTickers.length > 0
        ? visibleTickers.slice(0, 30)
        : ["BTC", "ETH", "SOL", "XRP", "DOGE", "PEPE", "WIF", "BNB"];

    const priority = `${primaryExchange},BYBIT,OKX`;
    setIsScanning(true);

    const BATCH_SIZE = 6;
    let allItems: DensityItem[] = [];

    for (let i = 0; i < targets.length; i += BATCH_SIZE) {
      const batch = targets.slice(i, i + BATCH_SIZE);
      const results = await Promise.allSettled(
        batch.map(async (ticker) => {
          const res = await fetch(
            `/api/depth?symbol=${ticker}&priority=${priority}&all=true`,
            { signal: AbortSignal.timeout(6000) },
          );
          if (!res.ok) return [];
          const data = await res.json();
          if (!Array.isArray(data) || data.length === 0) return [];

          let currentPrice =
            pricesRef.current.get(ticker) ||
            lastKnownPricesRef.current.get(ticker) ||
            0;

          if (!currentPrice) {
            const bids = data.filter((d: any) => d.type === "BID").map((d: any) => d.price as number);
            const asks = data.filter((d: any) => d.type === "ASK").map((d: any) => d.price as number);
            if (bids.length > 0 && asks.length > 0) {
              currentPrice = (Math.max(...bids) + Math.min(...asks)) / 2;
            } else if (bids.length > 0) {
              currentPrice = Math.max(...bids);
            } else if (asks.length > 0) {
              currentPrice = Math.min(...asks);
            }
          }

          if (!currentPrice) return [];
          lastKnownPricesRef.current.set(ticker, currentPrice);

          const items: DensityItem[] = [];
          for (const d of data) {
            const percent = ((d.price - currentPrice) / currentPrice) * 100;
            if (Math.abs(percent) > MAX_PERCENT) continue;

            const id = `${ticker}-${d.price}-${d.exchange}`;
            const timestamp = trackerRef.current.get(id) ?? Date.now();
            if (!trackerRef.current.has(id)) trackerRef.current.set(id, timestamp);

            items.push({
              id,
              symbol: ticker,
              price: d.price,
              currentPrice,
              volumeUSD: d.volumeUSD,
              type: d.type,
              firstSeen: timestamp,
              distancePercent: percent,
              exchange: d.exchange,
            });
          }
          return items;
        })
      );

      for (const r of results) {
        if (r.status === "fulfilled") allItems = allItems.concat(r.value);
      }
      
      await new Promise(resolve => setTimeout(resolve, 80));
    }

    const noMM = filterMarketMakers(allItems);

    const bySymbol = new Map<string, DensityItem[]>();
    for (const item of noMM) {
      const key = `${item.symbol}:${item.exchange}`;
      if (!bySymbol.has(key)) bySymbol.set(key, []);
      bySymbol.get(key)!.push(item);
    }
    let filtered: DensityItem[] = [];
    for (const [, group] of bySymbol) {
      filtered = filtered.concat(analyzeOrderBook(group));
    }

    // Если ордер исчез из стакана, он удаляется из трекера, таймер жизни сбрасывается навсегда
    const activeIds = new Set(allItems.map((i) => i.id));
    for (const key of trackerRef.current.keys()) {
      if (!activeIds.has(key)) trackerRef.current.delete(key);
    }

    filtered.sort((a, b) => b.price - a.price);
    setDensities(filtered.slice(0, 60));
    setIsScanning(false);
  }, [visibleTickers, primaryExchange]);

  useEffect(() => {
    if (activeTab !== "MAP") return;

    if (scanTimeoutRef.current) clearTimeout(scanTimeoutRef.current);
    if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);

    scanTimeoutRef.current = setTimeout(() => {
      scanMarket();
      scanIntervalRef.current = setInterval(scanMarket, 12000);
    }, 500);

    return () => {
      if (scanTimeoutRef.current) clearTimeout(scanTimeoutRef.current);
      if (scanIntervalRef.current) clearInterval(scanIntervalRef.current);
    };
  }, [activeTab, scanMarket]);

  const formatVol = (val: number) => {
    if (val >= 1_000_000) return (val / 1_000_000).toFixed(1) + "M";
    return (val / 1000).toFixed(0) + "K";
  };

  if (activeTab === "ALERTS") {
    const activeAlerts = alerts.filter((a) => a.status === "active");
    const triggeredAlerts = alerts.filter((a) => a.status === "triggered");

    return (
      <aside className="w-full h-full bg-[#0d0d0d] flex flex-col border-l border-[#1e1e1e] font-mono">
        <div className="shrink-0 px-3 py-2 border-b border-[#1e1e1e] bg-[#0a0a0a] flex items-center gap-2">
          <Bell size={12} className="text-yellow-500" />
          <span className="text-[11px] font-black text-yellow-400 tracking-widest uppercase">
            {t("alertsTitle")}
          </span>
          {activeAlerts.length > 0 && (
            <span className="ml-auto text-[10px] bg-yellow-500/15 text-yellow-400 border border-yellow-500/30 px-1.5 py-0.5 rounded font-bold">
              {activeAlerts.length}
            </span>
          )}
        </div>

        <div className="flex-1 overflow-y-auto">
          {alerts.length === 0 && (
            <div className="flex items-center justify-center h-full text-gray-700 text-[10px] font-black tracking-widest uppercase animate-pulse">
              {t("noAlerts")}
            </div>
          )}

          {activeAlerts.length > 0 && (
            <div className="px-2 pt-2 pb-1">
              <div className="text-[9px] text-gray-600 uppercase tracking-widest px-1 py-2 font-bold">
                {t("activeAlerts")}
              </div>
              {activeAlerts.map((a) => {
                if (a.targetPrice == null || a.initialPrice == null) return null;
                const isUp = a.targetPrice > a.initialPrice;
                const distPct =
                  ((a.targetPrice - a.initialPrice) / a.initialPrice) * 100;
                return (
                  <div
                    key={a.id}
                    className="mb-2 bg-[#111] border border-[#1e1e1e] rounded p-2 group hover:border-yellow-500/30 transition-all"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`text-[10px] font-black ${isUp ? "text-emerald-500" : "text-rose-500"}`}
                        >
                          {isUp ? "▲" : "▼"}
                        </span>
                        <span className="text-[11px] font-bold text-gray-200">
                          {a.symbol}
                        </span>
                      </div>
                      <button
                        onClick={() => removeAlert(a.id)}
                        className="opacity-0 group-hover:opacity-100 text-gray-600 hover:text-red-500 transition-all"
                      >
                        <Trash2 size={11} />
                      </button>
                    </div>
                    <div className="flex justify-between items-end">
                      <div>
                        <div className="text-[9px] text-gray-600 mb-0.5">
                          {t("fromText")} {a.initialPrice.toFixed(4)}
                        </div>
                        <div className="text-[12px] font-black text-yellow-400 tracking-tight">
                          {a.targetPrice.toFixed(4)}
                        </div>
                      </div>
                      <div
                        className={`text-[11px] font-bold ${isUp ? "text-emerald-400" : "text-rose-400"}`}
                      >
                        {distPct > 0 ? "+" : ""}
                        {distPct.toFixed(2)}%
                      </div>
                    </div>
                    <div className="mt-1.5 h-0.5 bg-[#1e1e1e] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${isUp ? "bg-emerald-500/50" : "bg-rose-500/50"}`}
                        style={{
                          width: `${Math.min(Math.abs(distPct) * 10, 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {triggeredAlerts.length > 0 && (
            <div className="px-2 pb-2">
              <div className="text-[9px] text-gray-600 uppercase tracking-widest px-1 py-2 font-bold">
                {t("triggeredAlerts")}
              </div>
              <div className="space-y-1">
                {triggeredAlerts.map((a) => (
                  <div
                    key={a.id}
                    className="bg-black border border-[#1e1e1e] rounded p-2 opacity-50 flex items-center justify-between group hover:opacity-70 transition-opacity"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] text-emerald-500">✓</span>
                      <span className="text-[10px] text-gray-400 font-bold">
                        {a.symbol}
                      </span>
                      <span className="text-[10px] text-gray-600 font-mono">
                        {a.targetPrice?.toFixed(4) ?? "—"}
                      </span>
                    </div>
                    <button
                      onClick={() => removeAlert(a.id)}
                      className="opacity-0 group-hover:opacity-100 text-gray-700 hover:text-red-500 transition-all"
                    >
                      <Trash2 size={10} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="shrink-0 border-t border-[#1e1e1e] px-3 py-2 bg-[#0a0a0a]">
          <div className="text-[9px] text-gray-700 flex items-center gap-1.5">
            <Bell size={9} className="text-yellow-600/50" />
            {t("alertHint")}
          </div>
        </div>
      </aside>
    );
  }

  if (activeTab === "MOVERS") {
    return <MoversPanel />;
  }

  if (activeTab === "LISTINGS") {
    return <ListingsPanel allCoins={allCoins} primaryExchange={primaryExchange} coinGroups={coinGroups} />;
  }

  if (activeTab !== "MAP") {
    return <div className="flex-1 bg-[#0a0a0a]" />;
  }

  // Только подтвержденные плотности, которые "прожили" больше 20 секунд
  const validDensities = densities.filter(item => (now - item.firstSeen) >= MIN_ALIVE_MS);

  // ── MAP ──
  return (
    <aside className="w-full h-full bg-[#0d0d0d] flex flex-col font-mono relative overflow-hidden border-l border-[#1e1e1e]">
      <div className="flex-1 relative bg-[#0a0a0a] overflow-hidden flex">

        {/* ФОНОВАЯ РАЗМЕТКА КОЛОНОК */}
        <div className="absolute inset-0 grid grid-cols-3 pointer-events-none z-0">
          <div className="border-r border-[#111]" />
          <div className="border-r border-[#111]" />
          <div />
        </div>

        {/* СЕТКА ПРОЦЕНТОВ */}
        <div className="absolute inset-0 flex flex-col justify-center pointer-events-none z-0">
          {[1.5, 1.0, 0.5].map((pct) => (
            <div
              key={`plus-${pct}`}
              className="absolute w-full border-t border-dashed border-[#1a1a1a] flex justify-center"
              style={{ top: `${50 - pct * SCALE_FACTOR}%` }}
            >
              <span className="text-[10px] font-bold text-emerald-500/60 bg-[#0a0a0a] px-2 -translate-y-1/2">
                +{pct}%
              </span>
            </div>
          ))}
          {[0.5, 1.0, 1.5].map((pct) => (
            <div
              key={`minus-${pct}`}
              className="absolute w-full border-t border-dashed border-[#1a1a1a] flex justify-center"
              style={{ top: `${50 + pct * SCALE_FACTOR}%` }}
            >
              <span className="text-[10px] font-bold text-rose-500/60 bg-[#0a0a0a] px-2 -translate-y-1/2">
                -{pct}%
              </span>
            </div>
          ))}
        </div>

        {/* ЦЕНТРАЛЬНАЯ ПОЛОСА */}
        <div className="absolute top-1/2 left-0 w-full z-30 pointer-events-none">
          <div className="absolute w-full border-t border-emerald-500/20 top-0" />
          <div className="flex justify-between items-center w-full px-2 -translate-y-1/2 mt-[1px]">
            <span className="text-[10px] font-black text-emerald-500/30 bg-[#0a0a0a] px-1 uppercase tracking-tighter">
              {t("sizeSmall")}
            </span>
            <div className="px-4 py-0.5 bg-[#0a0a0a] border border-emerald-500/40 rounded-full flex items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.1)]">
              <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[11px] font-black text-emerald-500 tracking-[0.2em] uppercase">
                {t("sizeMedium")}
              </span>
              <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <span className="text-[10px] font-black text-emerald-500/30 bg-[#0a0a0a] px-1 uppercase tracking-tighter">
              {t("sizeLarge")}
            </span>
          </div>
        </div>

        {/* ПЛАШКИ ОРДЕРОВ */}
        <div className="absolute inset-0 z-20 w-full h-full">
          {validDensities.map((item) => {
            const topPos = 50 - item.distancePercent * SCALE_FACTOR;
            if (topPos < -5 || topPos > 105) return null;

            const isAsk = item.type === "ASK";
            const bgColor = isAsk ? "bg-[#450a0a]/95" : "bg-[#064e3b]/95";
            const accentBorder = isAsk ? "border-l-red-500" : "border-l-emerald-500";

            let leftPos = "2%";
            if (item.volumeUSD >= 800_000) leftPos = "68%";
            else if (item.volumeUSD >= 250_000) leftPos = "35%";

            return (
              <div
                key={item.id}
                onClick={() => setSelectedDensity(item)}
                className={`absolute border border-[#1e1e1e] pl-2 pr-1.5 py-1 rounded shadow-lg transition-transform group hover:z-50 hover:scale-[1.03] cursor-pointer ${bgColor} border-l-4 ${accentBorder}`}
                style={{
                  top: `${topPos}%`,
                  left: leftPos,
                  transform: "translateY(-50%)",
                  width: "32%",
                  height: "38px", // Увеличена высота
                }}
              >
                <div className="flex flex-col justify-center h-full">
                  <span className="text-[12px] font-black text-white leading-none tracking-tight mb-0.5">
                    {formatVol(item.volumeUSD)}
                  </span>
                  <div className="flex justify-between items-center overflow-hidden">
                    <span className="text-[9px] font-black text-gray-200 leading-none truncate pr-1 uppercase">
                      <span className="text-gray-400 opacity-60 font-bold">
                        {item.exchange}
                      </span>{" "}
                      • {item.symbol}
                    </span>
                    <span className="text-[8px] text-gray-400 leading-none opacity-60 font-mono">
                      {Math.floor(item.price)}
                    </span>
                  </div>
                </div>
                <div className="absolute top-1 right-1 flex items-center gap-0.5 text-[7px] text-white/40">
                  <Clock size={6} />
                  <TimeAlive firstSeen={item.firstSeen} />
                </div>
              </div>
            );
          })}
        </div>

        {/* НОВЫЙ ПОПАП ДЛЯ ДЕТАЛЕЙ ПЛОТНОСТИ */}
        {selectedDensity && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[100] bg-[#0d0d0d] border border-[#2a2a2a] shadow-[0_0_40px_rgba(0,0,0,0.8)] rounded p-4 w-[220px] pointer-events-auto flex flex-col gap-3">
             <div className="flex items-center justify-between border-b border-[#1e1e1e] pb-2">
                <div className="flex items-center gap-2">
                   <span className={`w-2 h-2 rounded-full ${selectedDensity.type === 'ASK' ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                   <span className="text-[13px] font-black text-white">{selectedDensity.symbol}</span>
                   <span className="text-[9px] text-gray-500 font-mono">{selectedDensity.exchange}</span>
                </div>
                <button onClick={() => setSelectedDensity(null)} className="text-gray-500 hover:text-white transition-colors">
                  <X size={14}/>
                </button>
             </div>

             <div className="flex flex-col gap-1.5 font-mono text-[10px]">
                <div className="flex justify-between">
                  <span className="text-gray-500">Price:</span> 
                  <span className="text-white font-bold">{selectedDensity.price}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Volume:</span> 
                  <span className="text-white font-bold">${Math.round(selectedDensity.volumeUSD).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Distance:</span> 
                  <span className={selectedDensity.distancePercent > 0 ? "text-emerald-400" : "text-rose-400"}>
                    {selectedDensity.distancePercent > 0 ? "+" : ""}{selectedDensity.distancePercent.toFixed(2)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Type:</span> 
                  <span className={selectedDensity.type === 'ASK' ? "text-rose-400" : "text-emerald-400"}>
                    {selectedDensity.type === 'ASK' ? 'Resistance (Ask)' : 'Support (Bid)'}
                  </span>
                </div>
             </div>

             <button
                onClick={() => {
                  const exMap: Record<string, string> = { "BINANCE": "BI-F", "BYBIT": "BY-F", "OKX": "OKX-F" };
                  
                  // Глобальная переменная для передачи стейта между страницами/ререндерами
                  if (typeof window !== "undefined") {
                    (window as any).__pendingDensityHighlight = {
                      symbol: selectedDensity.symbol,
                      type: selectedDensity.type,
                      expires: Date.now() + 4000
                    };
                    
                    // ОТПРАВЛЯЕМ КАСТОМНОЕ СОБЫТИЕ ДЛЯ ТЕКУЩИХ ГРАФИКОВ
                    window.dispatchEvent(new CustomEvent("density-focus", {
                      detail: { symbol: selectedDensity.symbol, type: selectedDensity.type }
                    }));
                  }
                  
                  navigateToSymbol(selectedDensity.symbol, exMap[selectedDensity.exchange] || "BI-F");
                  setSelectedDensity(null);
                }}
                className="mt-1 w-full py-1.5 bg-[#1a1a1a] hover:bg-[#2962ff] text-gray-300 hover:text-white rounded border border-[#2a2a2a] hover:border-[#2962ff] transition-all text-[10px] font-bold tracking-wider uppercase"
             >
                Open Chart
             </button>
          </div>
        )}

        {/* LOADING / EMPTY STATE */}
        {validDensities.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 px-4 text-center">
            <span className="text-gray-800 text-[10px] font-black tracking-widest animate-pulse uppercase">
              {isScanning ? t("clusterScanning") : t("noData")}
            </span>
            {densities.length > 0 && !isScanning && (
              <span className="text-gray-700 text-[8px] font-mono border border-gray-800 rounded px-2 py-0.5">
                Pending confirmation: {densities.length}
              </span>
            )}
          </div>
        )}

        {/* Индикатор обновления */}
        {isScanning && validDensities.length > 0 && (
          <div className="absolute top-2 right-2 z-40 flex items-center gap-1 text-[8px] text-emerald-500/50 font-mono">
            <div className="w-1 h-1 rounded-full bg-emerald-500/50 animate-pulse" />
            upd
          </div>
        )}
      </div>
    </aside>
  );
}

// ─────────────────────────────────────────────
//  MOVERS PANEL — история импульсов
// ─────────────────────────────────────────────
function MoversPanel() {
  const { history, clearHistory, addImpulse, impulseAllCoins, setImpulseAllCoins } = useImpulses();
  const { t } = useLanguage();

  const handleTest = () => {
    addImpulse({
      id: `test-${Date.now()}`,
      symbol: "BTC",
      exchange: "BI-F",
      changePct: 1.42,
      price: 77450,
      timestamp: Date.now(),
    });
  };

  return (
    <aside className="w-full h-full bg-[#0d0d0d] flex flex-col border-l border-[#1e1e1e] font-mono">
      <div className="shrink-0 px-3 py-2 border-b border-[#1e1e1e] bg-[#0a0a0a] flex items-center gap-2">
        <Rocket size={12} className="text-emerald-400" />
        <span className="text-[11px] font-black text-emerald-400 tracking-widest uppercase">
          {t("impulsesTitle")}
        </span>
        {history.length > 0 && (
          <span className="ml-1 text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded font-bold">
            {history.length}
          </span>
        )}
        <div className="ml-auto flex items-center gap-1">
          <button
            onClick={handleTest}
            className="text-[9px] px-2 py-0.5 rounded border border-[#2a2a2a] text-gray-600 hover:text-emerald-400 hover:border-emerald-500/40 transition-all font-bold uppercase tracking-wider"
            title={t("testBtnTitle")}
          >
            {t("testBtn")}
          </button>
          {history.length > 0 && (
            <button
              onClick={clearHistory}
              className="text-[9px] px-2 py-0.5 rounded border border-[#2a2a2a] text-gray-600 hover:text-rose-400 hover:border-rose-500/40 transition-all font-bold uppercase tracking-wider"
            >
              {t("clearBtn")}
            </button>
          )}
        </div>
      </div>

      <div className="shrink-0 px-3 py-1.5 border-b border-[#111] flex items-center gap-3 text-[9px] text-gray-700 font-mono">
        <span>{t("threshold")} <span className="text-gray-500 font-bold">{t("auto")}</span></span>
        <span>{t("window")} <span className="text-gray-500 font-bold">{WINDOW_SECONDS}s</span></span>
        <span>{t("cooldown")} <span className="text-gray-500 font-bold">60s</span></span>
        <button
          onClick={() => setImpulseAllCoins(!impulseAllCoins)}
          title={t("allCoinsTitle")}
          className={`ml-auto flex items-center gap-1.5 px-2 py-0.5 rounded border transition-all font-bold uppercase tracking-wider text-[9px] ${
            impulseAllCoins
              ? "border-emerald-500/50 text-emerald-400 bg-emerald-500/10"
              : "border-[#2a2a2a] text-gray-600 hover:text-gray-400 hover:border-[#444]"
          }`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${impulseAllCoins ? "bg-emerald-400" : "bg-gray-700"}`} />
          {t("allCoins")}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {history.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full gap-3 text-center px-4">
            <Zap size={24} className="text-gray-800" />
            <div className="text-gray-700 text-[10px] font-black tracking-widest uppercase">
              {t("waitingImpulses")}
            </div>
            <div className="text-gray-800 text-[9px]">
              {t("movementHint")}
            </div>
          </div>
        )}

        {history.length > 0 && (
          <div className="p-2 space-y-1">
            {history.map((impulse) => (
              <ToastCard key={impulse.id} impulse={impulse} compact={true} />
            ))}
          </div>
        )}
      </div>
    </aside>
  );
}

// ─────────────────────────────────────────────
//  LISTINGS PANEL — список тикеров скринера
// ─────────────────────────────────────────────
type SortKey = "symbol" | "change" | "natr" | "count" | "volume";
type SortDir = "asc" | "desc";

function formatVolumeShort(v: number): string {
  if (!v) return "—";
  if (v >= 1_000_000_000) return (v / 1_000_000_000).toFixed(1) + "B";
  if (v >= 1_000_000) return (v / 1_000_000).toFixed(0) + "M";
  return (v / 1000).toFixed(0) + "K";
}

function formatCount(n: number): string {
  if (!n) return "—";
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(0) + "K";
  return String(n);
}

const GROUP_DOT: Record<number, string> = {
  1: "bg-blue-500",
  2: "bg-violet-500",
  3: "bg-amber-500",
  4: "bg-rose-500",
  5: "bg-emerald-500",
};

function ListingsPanel({
  allCoins,
  primaryExchange,
  coinGroups = {},
}: {
  allCoins: CoinData[];
  primaryExchange: string;
  coinGroups?: Record<string, number>;
}) {
  const { t } = useLanguage();
  const [sortKey, setSortKey] = useState<SortKey>("volume");
  const [sortDir, setSortDir] = useState<SortDir>("desc");
  const [search, setSearch] = useState("");

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir(key === "symbol" ? "asc" : "desc");
    }
  };

  const sorted = [...allCoins]
    .filter((c) => c.symbol.includes(search.toUpperCase()))
    .sort((a, b) => {
      let av: number | string = 0;
      let bv: number | string = 0;
      if (sortKey === "symbol") { av = a.symbol; bv = b.symbol; }
      else if (sortKey === "change") { av = a.change ?? 0; bv = b.change ?? 0; }
      else if (sortKey === "natr") { av = a.natr ?? 0; bv = b.natr ?? 0; }
      else if (sortKey === "count") { av = a.count ?? 0; bv = b.count ?? 0; }
      else if (sortKey === "volume") { av = a.volume ?? 0; bv = b.volume ?? 0; }
      if (typeof av === "string") return sortDir === "asc" ? av.localeCompare(bv as string) : (bv as string).localeCompare(av);
      return sortDir === "asc" ? (av as number) - (bv as number) : (bv as number) - (av as number);
    });

  const SortIcon = ({ k }: { k: SortKey }) => {
    if (sortKey !== k) return <ArrowUpDown size={8} className="opacity-30" />;
    return sortDir === "asc" ? <ArrowUp size={8} className="text-[#2962ff]" /> : <ArrowDown size={8} className="text-[#2962ff]" />;
  };

  const exLabel = primaryExchange === "BINANCE" ? "BI" : primaryExchange === "BYBIT" ? "BY" : "OKX";

  return (
    <aside className="w-full h-full bg-[#0d0d0d] flex flex-col border-l border-[#1e1e1e] font-mono">
      <div className="shrink-0 px-3 py-2 border-b border-[#1e1e1e] bg-[#0a0a0a] flex items-center gap-2">
        <List size={12} className="text-purple-400" />
        <span className="text-[11px] font-black text-purple-400 tracking-widest uppercase">
          {t("tickersTitle")}
        </span>
        <span className="ml-1 text-[10px] bg-purple-500/15 text-purple-400 border border-purple-500/30 px-1.5 py-0.5 rounded font-bold">
          {sorted.length}
        </span>
        <span className="ml-auto text-[9px] text-gray-600 font-bold uppercase tracking-wider">
          {exLabel}-F
        </span>
      </div>

      <div className="shrink-0 px-2 py-1.5 border-b border-[#111]">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t("searchTicker")}
          className="w-full bg-[#111] border border-[#222] rounded px-2 py-1 text-[10px] text-gray-300 placeholder-gray-700 outline-none focus:border-purple-500/40 transition-colors"
        />
      </div>

      <div className="flex-1 overflow-y-auto">
        <table className="w-full border-collapse text-[10px]">
          <thead className="sticky top-0 bg-[#0a0a0a] z-10">
            <tr className="border-b border-[#1a1a1a]">
              <th
                className="text-left pl-2 py-1.5 text-gray-600 font-bold cursor-pointer hover:text-gray-400 transition-colors select-none"
                onClick={() => handleSort("symbol")}
              >
                <div className="flex items-center gap-1 uppercase tracking-wider text-[9px]">
                  {t("tableTicker")} <SortIcon k="symbol" />
                </div>
              </th>
              <th
                className="text-right py-1.5 text-gray-600 font-bold cursor-pointer hover:text-gray-400 transition-colors select-none"
                onClick={() => handleSort("change")}
              >
                <div className="flex items-center justify-end gap-1 uppercase tracking-wider text-[9px]">
                  {t("tableChange")} <SortIcon k="change" />
                </div>
              </th>
              <th
                className="text-right py-1.5 text-gray-600 font-bold cursor-pointer hover:text-gray-400 transition-colors select-none"
                onClick={() => handleSort("natr")}
              >
                <div className="flex items-center justify-end gap-1 uppercase tracking-wider text-[9px]">
                  {t("tableTicker") === "ТИКЕР" ? "NATR" : "NATR"} <SortIcon k="natr" />
                </div>
              </th>
              <th
                className="text-right py-1.5 text-gray-600 font-bold cursor-pointer hover:text-gray-400 transition-colors select-none"
                onClick={() => handleSort("count")}
              >
                <div className="flex items-center justify-end gap-1 uppercase tracking-wider text-[9px]">
                  {t("tableTrades")} <SortIcon k="count" />
                </div>
              </th>
              <th
                className="text-right pr-2 py-1.5 text-gray-600 font-bold cursor-pointer hover:text-gray-400 transition-colors select-none"
                onClick={() => handleSort("volume")}
              >
                <div className="flex items-center justify-end gap-1 uppercase tracking-wider text-[9px]">
                  {t("tableVol")} <SortIcon k="volume" />
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((coin) => {
              const isPos = coin.change >= 0;
              const absChange = Math.abs(coin.change);
              const changeColor = isPos
                ? absChange > 10 ? "text-emerald-300 font-black" : absChange > 3 ? "text-emerald-400 font-bold" : "text-emerald-600"
                : absChange > 10 ? "text-rose-300 font-black" : absChange > 3 ? "text-rose-400 font-bold" : "text-rose-600";

              return (
                <tr
                  key={coin.symbol}
                  className="border-b border-[#0f0f0f] hover:bg-[#141414] cursor-pointer transition-colors group"
                >
                  <td className="pl-2 py-1.5 font-black text-gray-300 group-hover:text-white tracking-tight">
                    <div className="flex items-center gap-1.5">
                      {coinGroups[coin.symbol] != null && (
                        <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${GROUP_DOT[coinGroups[coin.symbol]]}`} />
                      )}
                      {coin.symbol}
                    </div>
                  </td>
                  <td className={`text-right ${changeColor}`}>
                    {isPos ? "+" : ""}{coin.change.toFixed(1)}
                  </td>
                  <td className="text-right text-gray-500">
                    {coin.natr != null ? coin.natr.toFixed(1) : "—"}
                  </td>
                  <td className="text-right text-gray-600">
                    {formatCount(coin.count ?? 0)}
                  </td>
                  <td className="text-right pr-2 text-gray-500">
                    {formatVolumeShort(coin.volume ?? 0)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {sorted.length === 0 && (
          <div className="flex items-center justify-center h-32 text-gray-700 text-[10px] font-black tracking-widest uppercase">
            {t("noCoinsTab")}
          </div>
        )}
      </div>
    </aside>
  );
}