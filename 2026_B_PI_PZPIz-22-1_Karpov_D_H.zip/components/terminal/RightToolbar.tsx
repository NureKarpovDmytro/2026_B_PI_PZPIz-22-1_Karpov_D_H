"use client";
import React from "react";
import { Map, Rocket, Bell, List, Menu } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

interface RightToolbarProps {
  activePanel: "MAP" | "ALERTS" | "MOVERS" | "LISTINGS";
  setActivePanel: (p: "MAP" | "ALERTS" | "MOVERS" | "LISTINGS") => void;
  toggleSidebar: () => void;
  isPanelOpen: boolean;
}

export default function RightToolbar({
  activePanel,
  setActivePanel,
  toggleSidebar,
  isPanelOpen,
}: RightToolbarProps) {
  const { t } = useLanguage();

  const getButtonClass = (isActive: boolean, activeColorClass: string) => {
    const bgClass = activeColorClass.replace("text-", "bg-");
    return `p-2 rounded flex justify-center transition-all duration-200 relative group mb-2 ${
      isActive
        ? `${activeColorClass} ${bgClass}/10`
        : "text-gray-500 hover:text-gray-300 hover:bg-[#1e1e1e]"
    }`;
  };

  return (
    <aside className="w-10 bg-[#0a0a0a] border-l border-[#1e1e1e] flex flex-col items-center py-2 shrink-0 z-30">
      {/* */}
      <div className="mb-4 border-b border-[#1e1e1e] pb-2 w-full flex justify-center">
        <button
          onClick={toggleSidebar}
          className={`p-2 transition-colors ${isPanelOpen ? "text-white" : "text-gray-500 hover:text-white"}`}
        >
          <Menu size={20} />
        </button>
      </div>

      <div className="flex flex-col w-full px-1">
        {/* 1.  */}
        <button
          onClick={() => {
            setActivePanel("MAP");
            if (!isPanelOpen) toggleSidebar();
          }}
          className={getButtonClass(activePanel === "MAP", "text-[#2962ff]")}
          title={t("densityMap")}
        >
          <Map size={20} />
          {activePanel === "MAP" && isPanelOpen && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-[#2962ff] rounded-r"></div>
          )}
        </button>

        {/* 2. */}
        <button
          onClick={() => {
            setActivePanel("ALERTS");
            if (!isPanelOpen) toggleSidebar();
          }}
          className={getButtonClass(
            activePanel === "ALERTS",
            "text-yellow-400",
          )}
          title={t("alertsTab")}
        >
          <Bell size={20} />
          {activePanel === "ALERTS" && isPanelOpen && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-yellow-400 rounded-r"></div>
          )}
        </button>

        {/* 3. */}
        <button
          onClick={() => {
            setActivePanel("MOVERS");
            if (!isPanelOpen) toggleSidebar();
          }}
          className={getButtonClass(
            activePanel === "MOVERS",
            "text-emerald-400",
          )}
          title={t("moversTab")}
        >
          <Rocket size={20} />
          {activePanel === "MOVERS" && isPanelOpen && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-emerald-400 rounded-r"></div>
          )}
        </button>

        {/* 4. */}
        <button
          onClick={() => {
            setActivePanel("LISTINGS");
            if (!isPanelOpen) toggleSidebar();
          }}
          className={getButtonClass(
            activePanel === "LISTINGS",
            "text-purple-400",
          )}
          title={t("listingsTab")}
        >
          <List size={20} />
          {activePanel === "LISTINGS" && isPanelOpen && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-purple-400 rounded-r"></div>
          )}
        </button>
      </div>

      <div className="flex-1"></div>
    </aside>
  );
}