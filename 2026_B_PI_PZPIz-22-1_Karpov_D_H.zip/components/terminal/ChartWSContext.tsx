"use client";
// ChartWSContext.tsx

import React, { createContext, useContext, useEffect, useRef } from "react";

type TickCallback = (candle: {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  value: number;
  color: string;
}) => void;

interface ChartWSContextValue {
  subscribe: (symbol: string, interval: string, cb: TickCallback) => () => void;
}

const ChartWSContext = createContext<ChartWSContextValue>({
  subscribe: () => () => {},
});

class WSManager {
  private subscribers = new Map<string, Set<TickCallback>>();
  private sockets: WebSocket[] = [];
  private timers: ReturnType<typeof setTimeout>[] = [];
  private active = false;
  private currentExchange = "";
  private currentSymbols: string[] = [];
  private currentInterval = "";

  notify(symbol: string, interval: string, candle: any) {
    const key = `${symbol}:${interval}`;
    this.subscribers.get(key)?.forEach((cb) => cb(candle));
  }

  subscribe(symbol: string, interval: string, cb: TickCallback): () => void {
    const key = `${symbol}:${interval}`;
    if (!this.subscribers.has(key)) this.subscribers.set(key, new Set());
    this.subscribers.get(key)!.add(cb);
    return () => {
      this.subscribers.get(key)?.delete(cb);
    };
  }

  connect(exchange: string, symbols: string[], interval: string) {
    if (
      exchange === this.currentExchange &&
      interval === this.currentInterval &&
      JSON.stringify(symbols) === JSON.stringify(this.currentSymbols)
    ) {
      return;
    }

    this.currentExchange = exchange;
    this.currentSymbols = [...symbols];
    this.currentInterval = interval;

    this.closeAll();
    this.active = true;

    if (symbols.length === 0) return;

    console.log(
      `[WSManager] connect: ${exchange}, ${symbols.length} symbols, ${interval}`,
    );

    if (exchange === "BINANCE") {
      this.connectBinance(symbols, interval);
    } else if (exchange === "BYBIT") {
      this.connectBybit(symbols, interval);
    } else if (exchange === "OKX") {
      this.connectOKX(symbols, interval);
    }
  }

  private connectBinance(symbols: string[], interval: string) {
    const CHUNK = 30;
    for (let i = 0; i < symbols.length; i += CHUNK) {
      const chunk = symbols.slice(i, i + CHUNK);
      const delay = i === 0 ? 0 : (i / CHUNK) * 150;
      this.openBinanceWS(chunk, interval, delay);
    }
  }

  private openBinanceWS(chunk: string[], interval: string, delay: number) {
    const t = setTimeout(() => {
      if (!this.active) return;
      const streams = chunk
        .map((s) => `${s.toLowerCase()}usdt@kline_${interval}`)
        .join("/");
      const ws = new WebSocket(
        `wss://fstream.binance.com/stream?streams=${streams}`,
      );
      this.sockets.push(ws);
      ws.onopen = () =>
        console.log(`[WSManager] Binance open, ${chunk.length} symbols`);
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (!msg.data?.k) return;
          const k = msg.data.k;
          const sym = k.s.replace("USDT", "").toUpperCase();
          this.notify(sym, interval, {
            time: k.t / 1000,
            open: +k.o,
            high: +k.h,
            low: +k.l,
            close: +k.c,
            value: +k.q,
            color: +k.c >= +k.o ? "#26a69a" : "#ef5350",
          });
        } catch {}
      };
      ws.onclose = () => {
        if (this.active) {
          const t2 = setTimeout(
            () => this.openBinanceWS(chunk, interval, 0),
            3000,
          );
          this.timers.push(t2);
        }
      };
      ws.onerror = () => {
        try {
          ws.close();
        } catch {}
      };
    }, delay);
    this.timers.push(t);
  }

  private connectBybit(symbols: string[], interval: string) {
    const iMap: Record<string, string> = {
      "1m": "1",
      "5m": "5",
      "15m": "15",
      "1h": "60",
      "4h": "240",
      "1d": "D",
    };
    const iv = iMap[interval] ?? "15";
    const CHUNK = 10;
    for (let i = 0; i < symbols.length; i += CHUNK) {
      const chunk = symbols.slice(i, i + CHUNK);
      const delay = i === 0 ? 0 : (i / CHUNK) * 200;
      this.openBybitWS(chunk, iv, interval, delay);
    }
  }

  private openBybitWS(
    chunk: string[],
    iv: string,
    interval: string,
    delay: number,
  ) {
    const t = setTimeout(() => {
      if (!this.active) return;
      const ws = new WebSocket("wss://stream.bybit.com/v5/public/linear");
      this.sockets.push(ws);
      ws.onopen = () => {
        console.log(`[WSManager] Bybit open, ${chunk.length} symbols`);
        ws.send(
          JSON.stringify({
            op: "subscribe",
            args: chunk.map((s) => `kline.${iv}.${s}USDT`),
          }),
        );
      };
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (!msg.topic?.startsWith("kline.") || !msg.data?.[0]) return;
          const k = msg.data[0];
          const sym = msg.topic.split(".")[2].replace("USDT", "");
          this.notify(sym, interval, {
            time: +k.start / 1000,
            open: +k.open,
            high: +k.high,
            low: +k.low,
            close: +k.close,
            value: +(k.turnover ?? k.volume),
            color: +k.close >= +k.open ? "#26a69a" : "#ef5350",
          });
        } catch {}
      };
      ws.onclose = () => {
        if (this.active) {
          const t2 = setTimeout(
            () => this.openBybitWS(chunk, iv, interval, 0),
            3000,
          );
          this.timers.push(t2);
        }
      };
      ws.onerror = () => {
        try {
          ws.close();
        } catch {}
      };
    }, delay);
    this.timers.push(t);
  }

  private connectOKX(symbols: string[], interval: string) {
    const iMap: Record<string, string> = {
      "1m": "1m",
      "5m": "5m",
      "15m": "15m",
      "1h": "1H",
      "4h": "4H",
      "1d": "1D",
    };
    const iv = iMap[interval] ?? "15m";
    const CHUNK = 10;
    for (let i = 0; i < symbols.length; i += CHUNK) {
      const chunk = symbols.slice(i, i + CHUNK);
      const delay = i === 0 ? 0 : (i / CHUNK) * 200;
      this.openOKXWS(chunk, iv, interval, delay);
    }
  }

  private openOKXWS(
    chunk: string[],
    iv: string,
    interval: string,
    delay: number,
  ) {
    const t = setTimeout(() => {
      if (!this.active) return;
      const ws = new WebSocket("wss://ws.okx.com:8443/ws/v5/public");
      this.sockets.push(ws);
      ws.onopen = () => {
        console.log(`[WSManager] OKX open, ${chunk.length} symbols`);
        ws.send(
          JSON.stringify({
            op: "subscribe",
            args: chunk.map((s) => ({
              channel: `candle${iv}`,
              instId: `${s}-USDT-SWAP`,
            })),
          }),
        );
      };
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          if (!msg.arg?.channel?.startsWith("candle") || !msg.data?.[0]) return;
          const k = msg.data[0];
          const sym = msg.arg.instId.split("-")[0];
          this.notify(sym, interval, {
            time: +k[0] / 1000,
            open: +k[1],
            high: +k[2],
            low: +k[3],
            close: +k[4],
            value: +(k[6] ?? k[5]),
            color: +k[4] >= +k[1] ? "#26a69a" : "#ef5350",
          });
        } catch {}
      };
      ws.onclose = () => {
        if (this.active) {
          const t2 = setTimeout(
            () => this.openOKXWS(chunk, iv, interval, 0),
            3000,
          );
          this.timers.push(t2);
        }
      };
      ws.onerror = () => {
        try {
          ws.close();
        } catch {}
      };
    }, delay);
    this.timers.push(t);
  }

  closeAll() {
    this.active = false;
    this.timers.forEach((t) => clearTimeout(t));
    this.timers = [];
    this.sockets.forEach((w) => {
      try {
        w.close();
      } catch {}
    });
    this.sockets = [];
  }
}

const wsManager: WSManager =
  (globalThis as any).__wsManager ??
  ((globalThis as any).__wsManager = new WSManager());

export function useChartWS(symbol: string, interval: string, cb: TickCallback) {
  const { subscribe } = useContext(ChartWSContext);
  const cbRef = useRef(cb);
  cbRef.current = cb;

  useEffect(() => {
    const unsub = subscribe(symbol, interval, (candle) =>
      cbRef.current(candle),
    );
    return unsub;
  }, [symbol, interval, subscribe]);
}

interface Props {
  children: React.ReactNode;
  primaryExchange: string;
  visibleSymbols: string[];
  globalInterval: string;
}

export function ChartWSProvider({
  children,
  primaryExchange,
  visibleSymbols,
  globalInterval,
}: Props) {
  const prevParamsRef = useRef({
    exchange: "",
    symbols: [] as string[],
    interval: "",
  });

  useEffect(() => {
    const prev = prevParamsRef.current;
    const symbolsChanged =
      JSON.stringify(visibleSymbols) !== JSON.stringify(prev.symbols);
    const exchangeChanged = primaryExchange !== prev.exchange;
    const intervalChanged = globalInterval !== prev.interval;

    if (!symbolsChanged && !exchangeChanged && !intervalChanged) return;

    prevParamsRef.current = {
      exchange: primaryExchange,
      symbols: [...visibleSymbols],
      interval: globalInterval,
    };

    wsManager.connect(primaryExchange, visibleSymbols, globalInterval);
  });

  const contextValue = useRef<ChartWSContextValue>({
    subscribe: (symbol, interval, cb) =>
      wsManager.subscribe(symbol, interval, cb),
  });

  return (
    <ChartWSContext.Provider value={contextValue.current}>
      {children}
    </ChartWSContext.Provider>
  );
}
