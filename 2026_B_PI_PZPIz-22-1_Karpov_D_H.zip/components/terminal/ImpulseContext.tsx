"use client";
import React, { createContext, useContext, useState, useCallback, useRef } from "react";

export interface Impulse {
  id: string;
  symbol: string;
  exchange: string;
  changePct: number;
  price: number;
  timestamp: number;
}

type ToastCallback = (impulse: Impulse) => void;
type NavigateCallback = (symbol: string, exchange: string) => void;

interface ImpulseContextValue {
  history: Impulse[];
  addImpulse: (impulse: Impulse) => void;
  clearHistory: () => void;
  impulseAllCoins: boolean;
  setImpulseAllCoins: (v: boolean) => void;
  navigateToSymbol: (symbol: string, exchange: string) => void;
  _registerNavigateCallback: (cb: NavigateCallback) => () => void;
  _registerToastCallback: (cb: ToastCallback) => () => void;
}

const ImpulseContext = createContext<ImpulseContextValue>({
  history: [],
  addImpulse: () => {},
  clearHistory: () => {},
  impulseAllCoins: false,
  setImpulseAllCoins: () => {},
  navigateToSymbol: () => {},
  _registerNavigateCallback: () => () => {},
  _registerToastCallback: () => () => {},
});

export function ImpulseProvider({ children }: { children: React.ReactNode }) {
  const [history, setHistory] = useState<Impulse[]>([]);
  const [impulseAllCoins, setImpulseAllCoins] = useState(false);
  const toastCallbackRef = useRef<ToastCallback | null>(null);
  const navigateCallbackRef = useRef<NavigateCallback | null>(null);

  const addImpulse = useCallback((impulse: Impulse) => {
    setHistory((prev) => [impulse, ...prev].slice(0, 100));
    toastCallbackRef.current?.(impulse);
  }, []);

  const clearHistory = useCallback(() => setHistory([]), []);

  const navigateToSymbol = useCallback((symbol: string, exchange: string) => {
    navigateCallbackRef.current?.(symbol, exchange);
  }, []);

  const _registerNavigateCallback = useCallback((cb: NavigateCallback) => {
    navigateCallbackRef.current = cb;
    return () => { navigateCallbackRef.current = null; };
  }, []);

  const _registerToastCallback = useCallback((cb: ToastCallback) => {
    toastCallbackRef.current = cb;
    return () => { toastCallbackRef.current = null; };
  }, []);

  return (
    <ImpulseContext.Provider value={{
      history, addImpulse, clearHistory,
      impulseAllCoins, setImpulseAllCoins,
      navigateToSymbol, _registerNavigateCallback,
      _registerToastCallback,
    }}>
      {children}
    </ImpulseContext.Provider>
  );
}

export function useImpulses() {
  return useContext(ImpulseContext);
}