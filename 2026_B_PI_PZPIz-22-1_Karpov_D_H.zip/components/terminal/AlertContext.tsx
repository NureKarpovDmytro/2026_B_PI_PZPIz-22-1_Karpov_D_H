"use client";
import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  ReactNode,
} from "react";

export type Alert = {
  id: string;
  symbol: string;
  targetPrice: number;
  initialPrice: number;
  direction: "up" | "down";
  status: "active" | "triggered";
  createdAt: number;
};

interface AlertContextType {
  alerts: Alert[];
  addAlert: (symbol: string, targetPrice: number, currentPrice: number) => void;
  removeAlert: (id: string) => void;
  triggerAlert: (id: string, currentPrice?: number) => void;
}

const AlertContext = createContext<AlertContextType | undefined>(undefined);


const ALERT_SOUND_PATH = "/sounds/alert.wav";

function playAlertSound() {
  try {
    const audio = new Audio(ALERT_SOUND_PATH);
    audio.volume = 0.6;
    audio.play().catch(() => {
      try {
        const AC = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AC();
        const playTone = (freq: number, startTime: number) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.type = "sine";
          osc.frequency.setValueAtTime(freq, startTime);
          gain.gain.setValueAtTime(0.08, startTime);
          gain.gain.exponentialRampToValueAtTime(0.00001, startTime + 0.25);
          osc.start(startTime);
          osc.stop(startTime + 0.25);
        };
        playTone(880, ctx.currentTime);
        playTone(1100, ctx.currentTime + 0.28);
      } catch {}
    });
  } catch {}
}

function notifyTelegram(
  symbol: string,
  price: number,
  direction: "up" | "down",
) {
  fetch("/api/alerts/trigger", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ symbol, price, direction }),
  }).catch(() => {});
}

export function AlertProvider({ children }: { children: ReactNode }) {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem("priceAlerts");
    if (saved) setAlerts(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("priceAlerts", JSON.stringify(alerts));
  }, [alerts]);

  const addAlert = (
    symbol: string,
    targetPrice: number,
    currentPrice: number,
  ) => {
    const newAlert: Alert = {
      id: `alert-${symbol}-${Date.now()}`,
      symbol,
      targetPrice,
      initialPrice: currentPrice,
      direction: targetPrice > currentPrice ? "up" : "down",
      status: "active",
      createdAt: Date.now(),
    };
    setAlerts((prev) => [...prev, newAlert]);
  };

  const triggerAlert = (id: string, currentPrice?: number) => {
    setAlerts((prev) => {
      const alert = prev.find((a) => a.id === id);
      if (alert && alert.status === "active") {
        playAlertSound();
        notifyTelegram(
          alert.symbol,
          currentPrice ?? alert.targetPrice,
          alert.direction,
        );
      }
      return prev.map((a) => (a.id === id ? { ...a, status: "triggered" } : a));
    });
  };

  const removeAlert = (id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  return (
    <AlertContext.Provider
      value={{ alerts, addAlert, removeAlert, triggerAlert }}
    >
      {children}
    </AlertContext.Provider>
  );
}

export const useAlerts = () => {
  const context = useContext(AlertContext);
  if (!context) throw new Error("useAlerts must be used within AlertProvider");
  return context;
};
