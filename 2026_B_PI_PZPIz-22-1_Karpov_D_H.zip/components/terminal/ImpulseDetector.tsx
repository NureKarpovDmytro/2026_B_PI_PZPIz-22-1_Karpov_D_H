"use client";
import React, { useEffect, useRef, useState, useCallback } from "react";
import { Zap } from "lucide-react";
import { useImpulses } from "./ImpulseContext";
import type { Impulse } from "./ImpulseContext";
import { useLanguage } from "@/lib/i18n"; 


export const WINDOW_SECONDS_DEFAULT = 30;
export const COOLDOWN_SECONDS_DEFAULT = 60;
export const MIN_THRESHOLD_DEFAULT = 0.5;
export const MAX_THRESHOLD_DEFAULT = 3.0;
export const THRESHOLD_MULTIPLIER_DEFAULT = 2.5;


export const WINDOW_SECONDS = WINDOW_SECONDS_DEFAULT;

const MAX_TOASTS = 5;
const TOAST_TTL = 8000;
const CUSTOM_SOUND_PATH = "/sounds/impulse.wav";

interface PricePoint {
  price: number;
  time: number;
}

interface ImpulseDetectorProps {
  visibleTickers: string[];
  primaryExchange: string;
  windowSeconds?: number;
  cooldownSeconds?: number;
  minThresholdPct?: number;
  maxThresholdPct?: number;
  soundEnabled?: boolean;
  soundVolume?: number;
}

function playImpulseSound(isUp: boolean, volume = 0.4) {
  const audio = new Audio(CUSTOM_SOUND_PATH);
  audio.volume = volume;
  audio.play().catch(() => {
    try {
      const AC = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AC();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      const freq = isUp ? 660 : 440;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(isUp ? 880 : 330, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(volume * 0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.00001, ctx.currentTime + 0.4);
      osc.start();
      osc.stop(ctx.currentTime + 0.4);
    } catch {}
  });
}

export default function ImpulseDetector({
  visibleTickers,
  windowSeconds = WINDOW_SECONDS_DEFAULT,
  cooldownSeconds = COOLDOWN_SECONDS_DEFAULT,
  minThresholdPct = MIN_THRESHOLD_DEFAULT,
  maxThresholdPct = MAX_THRESHOLD_DEFAULT,
  soundEnabled = true,
  soundVolume = 0.4,
}: ImpulseDetectorProps) {
  const [toasts, setToasts] = useState<Impulse[]>([]);
  const { addImpulse: addToHistory, _registerToastCallback } = useImpulses();

  const settingsRef = useRef({ windowSeconds, cooldownSeconds, minThresholdPct, maxThresholdPct, soundEnabled, soundVolume });
  useEffect(() => {
    settingsRef.current = { windowSeconds, cooldownSeconds, minThresholdPct, maxThresholdPct, soundEnabled, soundVolume };
  }, [windowSeconds, cooldownSeconds, minThresholdPct, maxThresholdPct, soundEnabled, soundVolume]);

  const priceWindowRef = useRef<Map<string, PricePoint[]>>(new Map());
  const cooldownRef = useRef<Map<string, number>>(new Map());
  const volatilityRef = useRef<Map<string, number[]>>(new Map());

  const showToast = useCallback((impulse: Impulse) => {
    const { soundEnabled, soundVolume } = settingsRef.current;
    if (soundEnabled) playImpulseSound(impulse.changePct > 0, soundVolume);
    setToasts((prev) => [impulse, ...prev].slice(0, MAX_TOASTS));
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== impulse.id));
    }, TOAST_TTL);
  }, []);

  useEffect(() => {
    const unregister = _registerToastCallback(showToast);
    return unregister;
  }, [_registerToastCallback, showToast]);

  const fireImpulse = useCallback(
    (impulse: Impulse) => { addToHistory(impulse); },
    [addToHistory],
  );

  const handlePrice = useCallback(
    (symbol: string, price: number, exchange: string) => {
      const now = Date.now();
      const { windowSeconds, cooldownSeconds, minThresholdPct, maxThresholdPct } = settingsRef.current;

      const lastSignal = cooldownRef.current.get(symbol) ?? 0;
      if (now - lastSignal < cooldownSeconds * 1000) return;

      const win = priceWindowRef.current.get(symbol) ?? [];
      win.push({ price, time: now });
      const cutoff = now - windowSeconds * 1000;
      const fresh = win.filter((p) => p.time >= cutoff);
      priceWindowRef.current.set(symbol, fresh);

      if (fresh.length < 3) return;

      const volBuf = volatilityRef.current.get(symbol) ?? [];
      const prev = fresh[fresh.length - 2];
      const curr = fresh[fresh.length - 1];
      if (prev && prev.price > 0) {
        const stepPct = Math.abs((curr.price - prev.price) / prev.price) * 100;
        volBuf.push(stepPct);
        if (volBuf.length > 20) volBuf.shift();
        volatilityRef.current.set(symbol, volBuf);
      }

      const avgStep = volBuf.length >= 5
        ? volBuf.reduce((a, b) => a + b, 0) / volBuf.length
        : null;
      const threshold = avgStep !== null
        ? Math.min(maxThresholdPct, Math.max(minThresholdPct, avgStep * THRESHOLD_MULTIPLIER_DEFAULT))
        : minThresholdPct;

      const oldest = fresh[0].price;
      const changePct = ((price - oldest) / oldest) * 100;

      if (Math.abs(changePct) >= threshold) {
        cooldownRef.current.set(symbol, now);
        priceWindowRef.current.set(symbol, []);
        volatilityRef.current.set(symbol, []);
        fireImpulse({ id: `${symbol}-${now}`, symbol, exchange, changePct, price, timestamp: now });
      }
    },
    [fireImpulse],
  );

  
  const handlePriceRef = useRef(handlePrice);
  useEffect(() => { handlePriceRef.current = handlePrice; });

  
  useEffect(() => {
    if (visibleTickers.length === 0) return;
    const targets = visibleTickers.slice(0, 40);

    // ─ BINANCE FUTURES ─
    let wsBi: WebSocket | null = null;
    let retryBi: ReturnType<typeof setTimeout> | null = null;
    let activeBi = true;
    const connectBi = () => {
      if (!activeBi) return;
      try {
        const streams = targets.map((s) => `${s.toLowerCase()}usdt@miniTicker`).join("/");
        wsBi = new WebSocket(`wss://fstream.binance.com/stream?streams=${streams}`);
        wsBi.onmessage = (e) => {
          const msg = JSON.parse(e.data);
          if (msg.stream && msg.data) {
            const sym = msg.data.s.replace("USDT", "").toUpperCase();
            const price = parseFloat(msg.data.c);
            if (!isNaN(price)) handlePriceRef.current(sym, price, "BI-F");
          }
        };
        wsBi.onclose = () => { if (activeBi) retryBi = setTimeout(connectBi, 4000); };
        wsBi.onerror = () => wsBi?.close();
      } catch {}
    };

    // ─ BYBIT LINEAR ─
    let wsBY: WebSocket | null = null;
    let retryBY: ReturnType<typeof setTimeout> | null = null;
    let activeBY = true;
    const connectBY = () => {
      if (!activeBY) return;
      try {
        wsBY = new WebSocket("wss://stream.bybit.com/v5/public/linear");
        wsBY.onopen = () => {
          wsBY?.send(JSON.stringify({
            op: "subscribe",
            args: targets.map((s) => `tickers.${s}USDT`),
          }));
        };
        wsBY.onmessage = (e) => {
          const msg = JSON.parse(e.data);
          if (msg.topic?.startsWith("tickers.") && msg.data?.lastPrice) {
            const sym = msg.topic.split(".")[1].replace("USDT", "");
            const price = parseFloat(msg.data.lastPrice);
            if (!isNaN(price)) handlePriceRef.current(sym, price, "BY-F");
          }
        };
        wsBY.onclose = () => { if (activeBY) retryBY = setTimeout(connectBY, 4000); };
        wsBY.onerror = () => wsBY?.close();
      } catch {}
    };

    // ─ OKX SWAP ─
    let wsOKX: WebSocket | null = null;
    let retryOKX: ReturnType<typeof setTimeout> | null = null;
    let activeOKX = true;
    const connectOKX = () => {
      if (!activeOKX) return;
      try {
        wsOKX = new WebSocket("wss://ws.okx.com:8443/ws/v5/public");
        wsOKX.onopen = () => {
          wsOKX?.send(JSON.stringify({
            op: "subscribe",
            args: targets.map((s) => ({ channel: "tickers", instId: `${s}-USDT-SWAP` })),
          }));
        };
        wsOKX.onmessage = (e) => {
          const msg = JSON.parse(e.data);
          if (msg.arg?.channel === "tickers" && msg.data?.[0]) {
            const sym = msg.data[0].instId.split("-")[0];
            const price = parseFloat(msg.data[0].last);
            if (!isNaN(price)) handlePriceRef.current(sym, price, "OKX-F");
          }
        };
        wsOKX.onclose = () => { if (activeOKX) retryOKX = setTimeout(connectOKX, 4000); };
        wsOKX.onerror = () => wsOKX?.close();
      } catch {}
    };

    connectBi();
    connectBY();
    connectOKX();

    return () => {
      activeBi = false; activeBY = false; activeOKX = false;
      if (retryBi) clearTimeout(retryBi);
      if (retryBY) clearTimeout(retryBY);
      if (retryOKX) clearTimeout(retryOKX);
      wsBi?.close(); wsBY?.close(); wsOKX?.close();
    };
  }, [visibleTickers]); 

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-14 z-[9999] flex flex-col-reverse gap-2 pointer-events-none">
      {toasts.map((toast) => (
        <ToastCard key={toast.id} impulse={toast} ttl={TOAST_TTL} />
      ))}
      <style>{`
        @keyframes shrink { from { width: 100%; } to { width: 0%; } }
      `}</style>
    </div>
  );
}

export function ToastCard({
  impulse,
  ttl,
  compact = false,
}: {
  impulse: Impulse;
  ttl?: number;
  compact?: boolean;
}) {
  const { navigateToSymbol } = useImpulses();
  const { t } = useLanguage(); 
  const isUp = impulse.changePct > 0;
  const borderColor = isUp ? "border-emerald-500" : "border-rose-500";
  const glowColor = isUp
    ? "shadow-[0_0_16px_rgba(16,185,129,0.25)]"
    : "shadow-[0_0_16px_rgba(239,68,68,0.25)]";
  const pctColor = isUp ? "text-emerald-400" : "text-rose-400";

  const handleClick = () => navigateToSymbol(impulse.symbol, impulse.exchange);

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}:${d.getSeconds().toString().padStart(2, "0")}`;
  };

  const formatPrice = (p: number) =>
    p < 0.01 ? p.toFixed(6) : p < 1 ? p.toFixed(4) : p < 100 ? p.toFixed(2) : p.toFixed(0);

  if (compact) {
    return (
      <div
        onClick={handleClick}
        className={`flex items-center justify-between px-2 py-1.5 rounded border-l-2 ${
          isUp ? "border-l-emerald-500 bg-emerald-500/5" : "border-l-rose-500 bg-rose-500/5"
        } hover:brightness-125 transition-all cursor-pointer`}>
        <div className="flex items-center gap-2 min-w-0">
          <Zap size={9} className={isUp ? "text-emerald-400 shrink-0" : "text-rose-400 shrink-0"} />
          <span className="text-[12px] font-black text-white truncate">{impulse.symbol}</span>
          <span className={`text-[11px] font-bold ${pctColor}`}>
            {isUp ? "+" : ""}{impulse.changePct.toFixed(2)}%
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-[9px] text-gray-600 font-mono">{impulse.exchange}</span>
          <span className="text-[9px] text-gray-700 font-mono">{formatTime(impulse.timestamp)}</span>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={handleClick}
      className={`pointer-events-auto flex flex-col bg-[#0d0d0d]/95 backdrop-blur border ${borderColor} ${glowColor} rounded px-4 py-3 min-w-[190px] cursor-pointer hover:brightness-110 transition-all`}>
      <div className="flex items-center justify-between gap-4 mb-1.5">
        <div className="flex items-center gap-2">
          <Zap size={12} className={isUp ? "text-emerald-400" : "text-rose-400"} />
          <span className="text-[17px] font-black text-white tracking-tight leading-none">{impulse.symbol}</span>
        </div>
        <span className="text-[10px] text-gray-500 font-mono font-bold">{impulse.exchange}</span>
      </div>
      <div className={`text-[15px] font-black ${pctColor} leading-none`}>
        {isUp ? "+" : ""}{impulse.changePct.toFixed(2)}%
        <span className="text-[10px] text-gray-600 font-normal ml-1">{t("inTime")} {WINDOW_SECONDS}s</span>
      </div>
      <div className="text-[10px] text-gray-600 font-mono mt-1">{formatPrice(impulse.price)}</div>
      {ttl && (
        <div className="mt-2 h-0.5 bg-[#1e1e1e] rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full ${isUp ? "bg-emerald-500/40" : "bg-rose-500/40"}`}
            style={{ animation: `shrink ${ttl}ms linear forwards` }}
          />
        </div>
      )}
    </div>
  );
}