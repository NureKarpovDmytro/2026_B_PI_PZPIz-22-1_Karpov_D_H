'use client';

import React, { useState } from 'react';
import { Settings, LayoutGrid, Search } from 'lucide-react';


type CoinRow = {
  ticker: string;
  change: number;
  range: number;
  natr: number;
  vol: string;
};


const MOCK_COINS: CoinRow[] = [
  { ticker: 'ETH', change: 0.5, range: 0.4, natr: 0.2, vol: '18B' },
  { ticker: 'BTC', change: 0.6, range: 0.2, natr: 0.1, vol: '18B' },
  { ticker: 'SOL', change: 0.4, range: 0.2, natr: 0.1, vol: '3B' },
  { ticker: 'RIVER', change: -3.7, range: 13.0, natr: 8.1, vol: '2B' }, 
  { ticker: 'HANA', change: 15.2, range: 4.9, natr: 6.5, vol: '337M' },
  { ticker: 'DUSK', change: -13.3, range: 0.8, natr: 1.2, vol: '232M' },
  { ticker: 'XRP', change: -0.2, range: 0.1, natr: 0.2, vol: '800M' },
  { ticker: 'DOGE', change: 4.2, range: 1.5, natr: 2.1, vol: '1.2B' },
  { ticker: 'SUI', change: -1.1, range: 0.6, natr: 0.8, vol: '400M' },
  { ticker: 'PEPE', change: 5.5, range: 2.2, natr: 3.0, vol: '900M' },
  { ticker: 'APT', change: 0.1, range: 0.3, natr: 0.4, vol: '150M' },
  { ticker: 'ARB', change: -0.5, range: 0.4, natr: 0.5, vol: '120M' },
  { ticker: 'LDO', change: 1.2, range: 0.7, natr: 0.9, vol: '200M' },
  { ticker: 'OP', change: -0.8, range: 0.5, natr: 0.6, vol: '180M' },
  { ticker: 'TIA', change: 2.3, range: 1.1, natr: 1.5, vol: '300M' },
];

export default function Sidebar() {
  const [activeTab, setActiveTab] = useState<'list' | 'impulses' | 'funding'>('list');

  return (
    <aside className="w-80 border-l border-[#1e1e1e] bg-[#0d0d0d] flex flex-col h-full text-[11px] font-mono shrink-0">
      
      {/* Хедер  */}
      <div className="flex items-center justify-between p-2 border-b border-[#1e1e1e] bg-[#111]">
        <div className="flex items-center gap-2 text-gray-400">
           <LayoutGrid size={14} />
           <span className="font-bold text-white">Coin list ({MOCK_COINS.length})</span>
        </div>
        <div className="flex gap-2">
            <button className="text-gray-500 hover:text-white"><Search size={14} /></button>
            <button className="text-gray-500 hover:text-white"><Settings size={14} /></button>
        </div>
      </div>

      {/* Таблица */}
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-[#0d0d0d] text-gray-500 uppercase text-[9px] z-10">
              <tr>
                <th className="pl-2 py-2 font-normal">Ticker</th>
                <th className="text-right py-2 font-normal">Change</th>
                <th className="text-right py-2 font-normal">Range</th>
                <th className="text-right py-2 font-normal">NATR</th>
                <th className="text-right pr-2 py-2 font-normal">Vol</th>
              </tr>
            </thead>
            <tbody>
              {MOCK_COINS.map((coin, idx) => {
                const isPos = coin.change > 0;
                const isHighRange = coin.range > 5.0; 
                
                return (
                  <tr key={idx} className="border-b border-[#131313] hover:bg-[#1a1a1a] cursor-pointer group transition-colors">
                    <td className="py-1.5 pl-2 font-bold text-gray-300 group-hover:text-white">
                      {coin.ticker}
                    </td>
                    <td className={`text-right ${isPos ? 'text-emerald-500' : 'text-rose-500'}`}>
                      {coin.change.toFixed(1)}
                    </td>
                    <td className={`text-right ${isHighRange ? 'text-emerald-400 font-bold' : 'text-gray-400'}`}>
                      {coin.range.toFixed(1)}
                    </td>
                    <td className={`text-right ${coin.natr > 1 ? 'text-gray-200' : 'text-gray-500'}`}>
                      {coin.natr.toFixed(1)}
                    </td>
                    <td className="text-right pr-2 text-gray-500">
                      {coin.vol}
                    </td>
                  </tr>
                );
              })}
            </tbody>
        </table>
      </div>
      
      {/* */}
      <div className="h-40 border-t border-[#1e1e1e] flex flex-col">
         <div className="flex items-center justify-between px-2 py-1 bg-[#111] border-b border-[#1e1e1e]">
            <span className="text-gray-400 font-bold">Impulses (1M &gt; 5%)</span>
         </div>
         <div className="flex-1 overflow-auto p-1">
             {/*  */}
             <div className="flex justify-between px-2 py-1 text-gray-300 hover:bg-[#1a1a1a] cursor-pointer">
                 <span className="font-bold">RIVER</span>
                 <span className="text-emerald-500">+8%</span>
                 <span className="text-gray-500">1m</span>
             </div>
         </div>
      </div>

    </aside>
  );
}