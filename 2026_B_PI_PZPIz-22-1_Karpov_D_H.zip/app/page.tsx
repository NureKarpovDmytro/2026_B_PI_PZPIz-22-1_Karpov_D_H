"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import { useRouter } from "next/navigation";
import RightToolbar from "@/components/terminal/RightToolbar";
import RealChartCard from "@/components/RealChartCard";
import DensityPanel from "@/components/terminal/DensityPanel";
import ImpulseDetector from "@/components/terminal/ImpulseDetector";
import { ChartWSProvider } from "@/components/terminal/ChartWSContext";
import {
  Settings,
  Maximize,
  Minimize,
  Loader2,
  X,
  ChevronLeft,
  ChevronRight,
  UserCircle,
  LogIn,
  BarChart2,
  Globe,
} from "lucide-react";
import { AlertProvider } from "@/components/terminal/AlertContext";
import { ImpulseProvider, useImpulses } from "@/components/terminal/ImpulseContext";
import { useAuth } from "@/lib/useAuth";
import { useLanguage } from "@/lib/i18n";

export const GROUP_COLORS: Record<number, { border: string; bg: string; dot: string; label: string }> = {
  1: { border: "border-blue-500",   bg: "bg-blue-500/10",   dot: "bg-blue-500",   label: "Синяя"    },
  2: { border: "border-violet-500", bg: "bg-violet-500/10", dot: "bg-violet-500", label: "Фиолет."  },
  3: { border: "border-amber-500",  bg: "bg-amber-500/10",  dot: "bg-amber-500",  label: "Жёлтая"   },
  4: { border: "border-rose-500",   bg: "bg-rose-500/10",   dot: "bg-rose-500",   label: "Красная"  },
  5: { border: "border-emerald-500",bg: "bg-emerald-500/10",dot: "bg-emerald-500",label: "Зелёная"  },
};
const TIMEFRAMES = [
  { label: "1M", value: "1m" },
  { label: "5M", value: "5m" },
  { label: "15M", value: "15m" },
  { label: "1H", value: "1h" },
  { label: "4H", value: "4h" },
  { label: "D", value: "1d" },
];

export default function Page() {
  return (
    <AlertProvider>
      <ImpulseProvider>
        <PageInner />
      </ImpulseProvider>
    </AlertProvider>
  );
}

function PageInner() {
  const router = useRouter();
  const { user } = useAuth();
  const { t, lang, setLang } = useLanguage();
  const [globalInterval, setGlobalInterval] = useState("15m");
  const [expandedCoin, setExpandedCoin] = useState<string | null>(null);
  const [allCoins, setAllCoins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // UI STATES
  const [minVolumeM, setMinVolumeM] = useState(0);
  const isDark = true; // тёмная тема
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [primaryExchange, setPrimaryExchange] = useState("BINANCE");

  // SIDEBAR & PAGINATION
  const [page, setPage] = useState(1);
  const [sortMode, setSortMode] = useState<"volume" | "change_desc" | "change_asc" | "natr">("volume");
  const [activePanel, setActivePanel] = useState<
    "MAP" | "ALERTS" | "MOVERS" | "LISTINGS"
  >("MAP");
  const [isPanelOpen, setIsPanelOpen] = useState(true);

  const { impulseAllCoins, _registerNavigateCallback, history } = useImpulses();

  // ─── (localStorage) ──────────────────────────────────
  const [showSettings, setShowSettings] = useState(false);
  const [impWindowSec, setImpWindowSec] = useState(() => {
    try { return Number(localStorage.getItem("vtc_imp_window") ?? 30); } catch { return 30; }
  });
  const [impCooldownSec, setImpCooldownSec] = useState(() => {
    try { return Number(localStorage.getItem("vtc_imp_cooldown") ?? 60); } catch { return 60; }
  });
  const [impMinThreshold, setImpMinThreshold] = useState(() => {
    try { return Number(localStorage.getItem("vtc_imp_min_thr") ?? 0.5); } catch { return 0.5; }
  });
  const [impMaxThreshold, setImpMaxThreshold] = useState(() => {
    try { return Number(localStorage.getItem("vtc_imp_max_thr") ?? 3.0); } catch { return 3.0; }
  });
  const [soundEnabled, setSoundEnabled] = useState(() => {
    try { return localStorage.getItem("vtc_sound") !== "false"; } catch { return true; }
  });
  const [soundVolume, setSoundVolume] = useState(() => {
    try { return Number(localStorage.getItem("vtc_sound_vol") ?? 0.4); } catch { return 0.4; }
  });

  const [indicatorSettings, setIndicatorSettings] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("vtc_indicators") ?? "{}");
    } catch { return {}; }
  });
  const updateIndicator = (key: string, val: boolean | number) => {
    setIndicatorSettings((prev: Record<string, boolean | number>) => {
      const next = { ...prev, [key]: val };
      localStorage.setItem("vtc_indicators", JSON.stringify(next));
      return next;
    });
  };
  const indSettings = {
    sessions: !!indicatorSettings.sessions,
    sessionDays: Number(indicatorSettings.sessionDays ?? 1),
    bb: !!indicatorSettings.bb,
    rsi: !!indicatorSettings.rsi,
    macd: !!indicatorSettings.macd,
  };

  const saveImpSettings = (patch: Record<string, number | boolean>) => {
    const map: Record<string, string> = {
      impWindowSec: "vtc_imp_window", impCooldownSec: "vtc_imp_cooldown",
      impMinThreshold: "vtc_imp_min_thr", impMaxThreshold: "vtc_imp_max_thr",
      soundEnabled: "vtc_sound", soundVolume: "vtc_sound_vol",
    };
    Object.entries(patch).forEach(([k, v]) => {
      if (map[k]) localStorage.setItem(map[k], String(v));
    });
  };

  const [coinGroups, setCoinGroupsState] = useState<Record<string, number>>(() => {
    try { return JSON.parse(localStorage.getItem("vtc_coin_groups") ?? "{}"); } catch { return {}; }
  });
  const setCoinGroup = (symbol: string, group: number | null) => {
    setCoinGroupsState((prev) => {
      const next = { ...prev };
      if (group === null) delete next[symbol]; else next[symbol] = group;
      localStorage.setItem("vtc_coin_groups", JSON.stringify(next));
      return next;
    });
  };

  // SCRUBBER
  const isDragging = useRef(false);
  const startX = useRef(0);
  const startVal = useRef(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    startX.current = e.clientX;
    startVal.current = minVolumeM;
    document.body.style.cursor = "ew-resize";
    document.body.style.userSelect = "none";
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
  };
  const handleMouseMove = (e: MouseEvent) => {
    if (!isDragging.current) return;
    const delta = e.clientX - startX.current;
    setMinVolumeM(
      Math.max(0, Math.min(1000, startVal.current + Math.round(delta))),
    );
  };
  const handleMouseUp = () => {
    isDragging.current = false;
    document.body.style.cursor = "default";
    document.body.style.userSelect = "auto";
    window.removeEventListener("mousemove", handleMouseMove);
    window.removeEventListener("mouseup", handleMouseUp);
  };

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(console.error);
      setIsFullScreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
        setIsFullScreen(false);
      }
    }
  };
const toggleLanguage = () => {
    const langs: ("en" | "uk" | "ru" | "zh" | "es" | "pt")[] = ["en", "uk", "ru", "zh", "es", "pt"];
    const nextIdx = (langs.indexOf(lang) + 1) % langs.length;
    setLang(langs[nextIdx]);
  };

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const res = await fetch(`/api/top-coins`);
        if (!res.ok) {
          setAllCoins([]);
          return;
        }
        const data = await res.json();
        if (Array.isArray(data)) setAllCoins(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [primaryExchange]);

  const fullFilteredList = useMemo(() => {
    if (allCoins.length === 0) return [];
    const filtered = allCoins.filter((c) => c.volume / 1000000 >= minVolumeM);

    const sorted = [...filtered].sort((a, b) => {
      if (sortMode === "volume") return (b.volume ?? 0) - (a.volume ?? 0);
      if (sortMode === "change_desc") return (b.change ?? 0) - (a.change ?? 0);
      if (sortMode === "change_asc") return (a.change ?? 0) - (b.change ?? 0);
      if (sortMode === "natr") return (b.natr ?? 0) - (a.natr ?? 0);
      return 0;
    });

    if (sortMode === "volume") {
      const btc = sorted.find((c) => c.symbol === "BTC");
      const eth = sorted.find((c) => c.symbol === "ETH");
      const others = sorted.filter((c) => c.symbol !== "BTC" && c.symbol !== "ETH");
      return [btc, eth, ...others].filter(Boolean);
    }
    return sorted;
  }, [allCoins, minVolumeM, sortMode]);

  const [highlightedSymbols, setHighlightedSymbols] = useState<Set<string>>(new Set());
  const highlightTimersRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  const fullFilteredListRef = useRef(fullFilteredList);
  useEffect(() => { fullFilteredListRef.current = fullFilteredList; }, [fullFilteredList]);

  const addHighlight = (symbol: string) => {
    const existing = highlightTimersRef.current.get(symbol);
    if (existing) clearTimeout(existing);
    setHighlightedSymbols((prev) => new Set([...prev, symbol]));
    const timer = setTimeout(() => {
      setHighlightedSymbols((prev) => { const n = new Set(prev); n.delete(symbol); return n; });
      highlightTimersRef.current.delete(symbol);
    }, 3000);
    highlightTimersRef.current.set(symbol, timer);
  };

  const setPrimaryExchangeRef = useRef(setPrimaryExchange);
  useEffect(() => { setPrimaryExchangeRef.current = setPrimaryExchange; }, [setPrimaryExchange]);
  const primaryExchangeRef = useRef(primaryExchange);
  useEffect(() => { primaryExchangeRef.current = primaryExchange; }, [primaryExchange]);

  useEffect(() => {
    const PAGE_SIZE = 24;
    const unregister = _registerNavigateCallback((symbol, exchange) => {
      const exchangeMap: Record<string, string> = { "BI-F": "BINANCE", "BY-F": "BYBIT", "OKX-F": "OKX" };
      const targetExchange = exchangeMap[exchange] ?? "BINANCE";
      const needsSwitch = targetExchange !== primaryExchangeRef.current;
      if (needsSwitch) setPrimaryExchangeRef.current(targetExchange);

      setTimeout(() => {
        const list = fullFilteredListRef.current;
        const idx = list.findIndex((c) => c.symbol === symbol);
        if (idx === -1) return;
        const targetPage = Math.floor(idx / PAGE_SIZE) + 1;
        setPage(targetPage);
        addHighlight(symbol);
      }, needsSwitch ? 800 : 0);
    });
    return unregister;
  }, [_registerNavigateCallback]);

  const lastImpulseId = history[0]?.id;
  useEffect(() => {
    if (!history[0]) return;
    const symbol = history[0].symbol;
    const onPage = paginatedTickers.some((c) => c.symbol === symbol);
    if (!onPage) return;
    addHighlight(symbol);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastImpulseId]);

  const paginatedTickers = useMemo(() => {
    const PAGE_SIZE = 24;
    const start = (page - 1) * PAGE_SIZE;
    return fullFilteredList.slice(start, start + PAGE_SIZE);
  }, [fullFilteredList, page]);

  const allSymbols = useMemo(
    () => fullFilteredList.map((c) => c.symbol),
    [fullFilteredList],
  );


  const impulseTargets = useMemo(
    () =>
      [...(impulseAllCoins ? allCoins : fullFilteredList)]
        .sort((a, b) => (b.volume ?? 0) - (a.volume ?? 0))
        .slice(0, 40)
        .map((c) => c.symbol),
    [impulseAllCoins, allCoins, fullFilteredList],
  );

  const bgClass = isDark
    ? "bg-[#050505] text-white"
    : "bg-[#f3f4f6] text-gray-900";
  const headerClass = isDark
    ? "bg-[#0a0a0a] border-[#1e1e1e]"
    : "bg-white border-gray-200 shadow-sm";
  const btnHover = isDark
    ? "hover:bg-[#1e1e1e] hover:text-white text-gray-500"
    : "hover:bg-gray-100 hover:text-black text-gray-500";

  return (
    <ChartWSProvider primaryExchange={primaryExchange} visibleSymbols={allSymbols} globalInterval={globalInterval}>
    <>
      <div
        className={`flex h-screen w-screen overflow-hidden font-sans select-none transition-colors duration-300 ${bgClass}`}
      >
        <div
          className={`flex h-screen w-screen overflow-hidden font-sans select-none transition-colors duration-300 ${bgClass}`}
        >
          <div className="flex-1 flex flex-col min-w-0 relative">
            <header
              className={`h-12 border-b flex items-center justify-between px-4 shrink-0 z-20 transition-colors duration-300 ${headerClass}`}
            >
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2 select-none group cursor-pointer">
                  <span
                    className={`text-xl font-bold tracking-tighter italic ${isDark ? "text-white" : "text-black"}`}
                  >
                    VTC <span className="text-[#2962ff]">Screen</span>
                  </span>
                </div>
                <div
                  className={`h-5 w-[1px] ${isDark ? "bg-[#222]" : "bg-gray-300"}`}
                ></div>
                <div className="flex gap-1">
                  {TIMEFRAMES.map((tf) => (
                    <button
                      key={tf.value}
                      onClick={() => setGlobalInterval(tf.value)}
                      className={`text-[11px] px-2 py-1 rounded font-medium transition-all ${globalInterval === tf.value ? "bg-[#2962ff] text-white shadow-md" : isDark ? "text-gray-500 hover:text-gray-300 hover:bg-[#1e1e1e]" : "text-gray-500 hover:text-black hover:bg-gray-100"}`}
                    >
                      {tf.label}
                    </button>
                  ))}
                </div>

                <div
                  className={`flex items-center gap-2 px-2 py-1 rounded border cursor-ew-resize transition-all group relative overflow-hidden ${isDark ? "bg-[#111] border-[#222] hover:border-[#444]" : "bg-white border-gray-200 hover:border-gray-300 shadow-sm"}`}
                  onMouseDown={handleMouseDown}
                  title="Drag to change Min Volume"
                >
                  <div
                    className="absolute left-0 top-0 bottom-0 bg-blue-600/10 pointer-events-none transition-all duration-75"
                    style={{
                      width: `${Math.min(100, (minVolumeM / 1000) * 100)}%`,
                    }}
                  />
                  <span className="text-[10px] text-gray-400 font-bold z-10">
                    VOL &gt;
                  </span>
                  <span
                    className={`text-[11px] font-bold font-mono z-10 min-w-[30px] text-right ${isDark ? "text-white" : "text-black"}`}
                  >
                    {minVolumeM}M
                  </span>
                </div>

                <div className={`flex gap-1`}>
                  {["BINANCE", "BYBIT", "OKX"].map((ex) => (
                    <button
                      key={ex}
                      onClick={() => setPrimaryExchange(ex)}
                      className={`text-[10px] px-2 py-1 rounded font-medium transition-all ${primaryExchange === ex ? "bg-[#2962ff] text-white shadow-md" : isDark ? "text-gray-500 hover:text-gray-300 hover:bg-[#1e1e1e]" : "text-gray-500 hover:text-black hover:bg-gray-100"}`}
                    >
                      {ex.slice(0, 2)}
                    </button>
                  ))}
                </div>

                <div className={`flex gap-0.5 items-center px-1 py-0.5 rounded border ${isDark ? "bg-[#111] border-[#222]" : "bg-white border-gray-200"}`}>
                  {([
                    { key: "volume",      label: "VOL" },
                    { key: "change_desc", label: "+%"  },
                    { key: "change_asc",  label: "-%"  },
                    { key: "natr",        label: "ATR" },
                  ] as const).map(({ key, label }) => (
                    <button
                      key={key}
                      onClick={() => { setSortMode(key); setPage(1); }}
                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold transition-all ${sortMode === key ? "bg-[#2962ff] text-white" : isDark ? "text-gray-600 hover:text-gray-300" : "text-gray-400 hover:text-black"}`}
                    >
                      {label}
                    </button>
                  ))}
                </div>

                <div
                  className={`flex items-center gap-1 px-1 py-0.5 rounded border ${isDark ? "bg-[#111] border-[#222]" : "bg-white border-gray-200"}`}
                >
                  <button
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page === 1}
                    className={`p-1 rounded ${btnHover} disabled:opacity-30`}
                  >
                    <ChevronLeft size={14} />
                  </button>
                  <span className={`text-[10px] font-mono w-6 text-center font-bold transition-colors ${highlightedSymbols.size > 0 ? "text-amber-400" : ""}`}>
                    {page}
                  </span>
                  <button
                    onClick={() => setPage((p) => p + 1)}
                    className={`p-1 rounded ${btnHover}`}
                  >
                    <ChevronRight size={14} />
                  </button>
                </div>
              </div>

              {/**/}
              <button
                onClick={() => router.push("/formations")}
                className={`flex items-center gap-1.5 px-3 py-1 rounded border text-[11px] font-bold transition-all ${
                  isDark
                    ? "bg-[#111] border-[#222] text-gray-400 hover:text-white hover:border-[#2962ff]/60 hover:bg-[#2962ff]/10"
                    : "bg-white border-gray-200 text-gray-500 hover:text-black hover:border-blue-400"
                }`}
              >
                <BarChart2 size={13} />
                {t("formations")}
              </button>

              <div className="flex items-center gap-1">
                {/**/}
                <button
                  onClick={toggleLanguage}
                  title="Change Language"
                  className={`flex items-center gap-1 p-2 rounded-md transition-all ${btnHover}`}
                >
                  <Globe size={18} />
                  <span className="text-[10px] font-bold">{lang.toUpperCase()}</span>
                </button>

                <button
                  onClick={() => setShowSettings(true)}
                  className={`p-2 rounded-md transition-all ${btnHover}`}
                >
                  <Settings size={18} />
                </button>
                {/* */}
                {user ? (
                  <button
                    onClick={() => router.push("/profile")}
                    title={user.name}
                    className={`p-2 rounded-md transition-all relative ${btnHover}`}
                  >
                    <UserCircle size={18} />
                    {user.role === "premium" && (
                      <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-amber-400 rounded-full" />
                    )}
                  </button>
                ) : (
                  <button
                    onClick={() => router.push("/login")}
                    title={t("login")}
                    className={`p-2 rounded-md transition-all ${btnHover}`}
                  >
                    <LogIn size={18} />
                  </button>
                )}
                {/* */}
                <button
                  onClick={toggleFullScreen}
                  className={`p-2 rounded-md transition-all ${btnHover}`}
                >
                  {isFullScreen ? <Minimize size={18} /> : <Maximize size={18} />}
                </button>
              </div>
            </header>

            <main
              className={`flex-1 p-1 overflow-y-auto custom-scrollbar relative ${bgClass}`}
            >
              {loading && (
                <div
                  className={`absolute inset-0 flex flex-col items-center justify-center z-50 ${bgClass}`}
                >
                  <Loader2
                    size={32}
                    className="animate-spin mb-2 text-[#2962ff]"
                  />
                  <span className="text-xs opacity-50">
                    {t("scanning")}
                  </span>
                </div>
              )}

              {!loading && paginatedTickers.length === 0 && (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-500 gap-2">
                  <span>{t("noCoins", { page })}</span>
                  <button
                    onClick={() => setPage(1)}
                    className="text-xs bg-[#2962ff] text-white px-4 py-1.5 rounded hover:bg-blue-700"
                  >
                    {t("backToPage1")}
                  </button>
                </div>
              )}

              {!loading && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-1 pb-20">
                  {paginatedTickers.map((coin) => (
                    <RealChartCard
                      key={coin.symbol}
                      symbol={coin.symbol}
                      interval={globalInterval}
                      onExpand={() => setExpandedCoin(coin.symbol)}
                      isDark={isDark}
                      primaryExchange={primaryExchange}
                      highlighted={highlightedSymbols.has(coin.symbol)}
                      group={coinGroups[coin.symbol] ?? null}
                      onSetGroup={(g) => setCoinGroup(coin.symbol, g)}
                      indicators={indSettings}
                    />
                  ))}
                </div>
              )}
            </main>

            {expandedCoin && (
              <div
                className={`absolute inset-0 z-50 flex flex-col animate-in fade-in duration-200 ${bgClass}`}
              >
                <div
                  className={`h-12 border-b flex items-center justify-between px-4 ${headerClass}`}
                >
                  <div className="flex items-center gap-4">
                    <span className="text-xl font-bold tracking-tight">
                      {expandedCoin}
                    </span>
                    <span className="text-xs bg-[#2962ff] text-white px-2 py-0.5 rounded">
                      {t("focusMode")}
                    </span>
                  </div>
                  <button
                    onClick={() => setExpandedCoin(null)}
                    className={`p-2 rounded hover:bg-red-500 hover:text-white transition-colors ${btnHover}`}
                  >
                    <X size={20} />
                  </button>
                </div>
                {/* FOCUS MODE GRID */}
                <div className="flex-1 grid grid-cols-2 grid-rows-2 gap-1 p-1">
                  <RealChartCard
                    symbol={expandedCoin}
                    interval="5m"
                    isDark={isDark}
                    primaryExchange={primaryExchange}
                    isFocusMode={true}
                    label="5M"
                  />
                  <RealChartCard
                    symbol={expandedCoin}
                    interval="1h"
                    isDark={isDark}
                    primaryExchange={primaryExchange}
                    isFocusMode={true}
                    label="1H"
                  />
                  <RealChartCard
                    symbol={expandedCoin}
                    interval="4h"
                    isDark={isDark}
                    primaryExchange={primaryExchange}
                    isFocusMode={true}
                    label="4H"
                  />
                  <RealChartCard
                    symbol={expandedCoin}
                    interval="1d"
                    isDark={isDark}
                    primaryExchange={primaryExchange}
                    isFocusMode={true}
                    label="1D"
                  />
                </div>
              </div>
            )}
          </div>

          <div
            className={`flex h-full transition-all duration-300 ${isPanelOpen ? "w-80" : "w-0"} overflow-hidden border-l border-[#1e1e1e]`}
          >
            <DensityPanel
              activeTab={activePanel}
              visibleTickers={allSymbols}
              primaryExchange={primaryExchange}
              coinGroups={coinGroups}
              allCoins={fullFilteredList.map((c) => ({
                symbol: c.symbol,
                
                change: parseFloat(
                  c.priceChangePercent ??
                  (c.price24hPcnt != null ? String(parseFloat(c.price24hPcnt) * 100) : null) ??
                  c.change ??
                  "0"
                ),
                natr: c.natr ?? null,
                
                count: c.trades ?? null,
                
                volume: parseFloat(c.quoteVolume ?? c.turnover24h ?? c.volume ?? "0"),
              }))}
            />
          </div>

          <RightToolbar
            activePanel={activePanel}
            setActivePanel={(p) => {
              if (activePanel === p && isPanelOpen) {
                setIsPanelOpen(false);
              } else {
                setActivePanel(p);
                setIsPanelOpen(true);
              }
            }}
            toggleSidebar={() => setIsPanelOpen(!isPanelOpen)}
            isPanelOpen={isPanelOpen}
          />
        </div>
      </div>
      <ImpulseDetector
        visibleTickers={impulseTargets}
        primaryExchange={primaryExchange}
        windowSeconds={impWindowSec}
        cooldownSeconds={impCooldownSec}
        minThresholdPct={impMinThreshold}
        maxThresholdPct={impMaxThreshold}
        soundEnabled={soundEnabled}
        soundVolume={soundVolume}
      />

      {/* */}
      {showSettings && (
        <div
          className="fixed inset-0 z-[10000] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowSettings(false)}
        >
          <div
            className="bg-[#0d0d0d] border border-[#2a2a2a] rounded-xl shadow-2xl w-full max-w-md font-sans"
            onClick={(e) => e.stopPropagation()}
          >
            {/* */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#1e1e1e]">
              <div className="flex items-center gap-2">
                <Settings size={14} className="text-gray-400" />
                <span className="text-[13px] font-black text-white uppercase tracking-widest">{t("settings")}</span>
              </div>
              <button onClick={() => setShowSettings(false)} className="text-gray-600 hover:text-white transition-colors">
                <X size={16} />
              </button>
            </div>

            <div className="p-5 space-y-6 max-h-[75vh] overflow-y-auto">

              {/*  */}
              <section>
                <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-3">{t("screener")}</p>
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-gray-500 mb-1">{t("defaultExchange")}</label>
                    <div className="flex gap-1">
                      {["BINANCE","BYBIT","OKX"].map((ex) => (
                        <button key={ex}
                          onClick={() => setPrimaryExchange(ex)}
                          className={`flex-1 py-1.5 rounded text-[11px] font-bold transition-all ${primaryExchange === ex ? "bg-[#2962ff] text-white" : "bg-[#111] border border-[#222] text-gray-500 hover:text-gray-300"}`}
                        >{ex.slice(0,2)}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 mb-1">
                      {t("minVolume")} <span className="text-gray-300 font-bold">{minVolumeM}M$</span>
                    </label>
                    <input type="range" min={0} max={500} step={10} value={minVolumeM}
                      onChange={(e) => setMinVolumeM(+e.target.value)}
                      className="w-full accent-[#2962ff]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 mb-1">{t("timeframe")}</label>
                    <div className="flex gap-1 flex-wrap">
                      {[{l:"1M",v:"1m"},{l:"5M",v:"5m"},{l:"15M",v:"15m"},{l:"1H",v:"1h"},{l:"4H",v:"4h"},{l:"D",v:"1d"}].map(({l,v}) => (
                        <button key={v}
                          onClick={() => setGlobalInterval(v)}
                          className={`px-2.5 py-1 rounded text-[11px] font-bold transition-all ${globalInterval === v ? "bg-[#2962ff] text-white" : "bg-[#111] border border-[#222] text-gray-500 hover:text-gray-300"}`}
                        >{l}</button>
                      ))}
                    </div>
                  </div>
                </div>
              </section>

              <div className="border-t border-[#1e1e1e]" />

              {/*  */}
              <section>
                <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-3">{t("impulseDetector")}</p>
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-gray-500 mb-1">
                      {t("analysisWindow")} <span className="text-gray-300 font-bold">{impWindowSec}s</span>
                    </label>
                    <input type="range" min={10} max={120} step={5} value={impWindowSec}
                      onChange={(e) => { setImpWindowSec(+e.target.value); saveImpSettings({impWindowSec: +e.target.value}); }}
                      className="w-full accent-[#2962ff]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 mb-1">
                      {t("cooldown")} <span className="text-gray-300 font-bold">{impCooldownSec}s</span>
                    </label>
                    <input type="range" min={10} max={300} step={10} value={impCooldownSec}
                      onChange={(e) => { setImpCooldownSec(+e.target.value); saveImpSettings({impCooldownSec: +e.target.value}); }}
                      className="w-full accent-[#2962ff]"
                    />
                  </div>
                  <div className="flex gap-3">
                    <div className="flex-1">
                      <label className="block text-[11px] text-gray-500 mb-1">
                        {t("minThreshold")} <span className="text-gray-300 font-bold">{impMinThreshold}%</span>
                      </label>
                      <input type="range" min={0.1} max={2} step={0.1} value={impMinThreshold}
                        onChange={(e) => { setImpMinThreshold(+e.target.value); saveImpSettings({impMinThreshold: +e.target.value}); }}
                        className="w-full accent-[#2962ff]"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="block text-[11px] text-gray-500 mb-1">
                        {t("maxThreshold")} <span className="text-gray-300 font-bold">{impMaxThreshold}%</span>
                      </label>
                      <input type="range" min={1} max={10} step={0.5} value={impMaxThreshold}
                        onChange={(e) => { setImpMaxThreshold(+e.target.value); saveImpSettings({impMaxThreshold: +e.target.value}); }}
                        className="w-full accent-[#2962ff]"
                      />
                    </div>
                  </div>
                </div>
              </section>

              <div className="border-t border-[#1e1e1e]" />

              {/* */}
              <section>
                <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-3">{t("indicators")}</p>
                <div className="space-y-2">
                  {[
                    { key: "sessions", label: t("tradingSessions"), sub: t("sessionSub") },
                    { key: "bb",       label: "Bollinger Bands", sub: "Period 20 · σ×2" },
                    { key: "rsi",      label: "RSI",             sub: "Period 14 · 30/70" },
                    { key: "macd",     label: "MACD",            sub: "12/26/9" },
                  ].map(({ key, label, sub }) => (
                    <div key={key} className="flex items-center justify-between py-1">
                      <div>
                        <span className="text-[12px] text-gray-300 font-bold">{label}</span>
                        <span className="ml-2 text-[10px] text-gray-600">{sub}</span>
                      </div>
                      <button
                        onClick={() => updateIndicator(key, !indicatorSettings[key])}
                        className={`relative w-10 h-5 rounded-full transition-colors shrink-0 ${indicatorSettings[key] ? "bg-[#2962ff]" : "bg-[#333]"}`}
                      >
                        <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${indicatorSettings[key] ? "left-5" : "left-0.5"}`} />
                      </button>
                    </div>
                  ))}
                  {indicatorSettings.sessions && (
                    <div className="ml-0 pl-0 pt-1">
                      <label className="block text-[11px] text-gray-500 mb-1">
                        {t("sessionDays")} <span className="text-gray-300 font-bold">{indicatorSettings.sessionDays ?? 1}</span>
                      </label>
                      <input
                        type="range" min={1} max={7} step={1}
                        value={indicatorSettings.sessionDays ?? 1}
                        onChange={(e) => updateIndicator("sessionDays", +e.target.value)}
                        className="w-full accent-[#2962ff]"
                      />
                      <div className="flex justify-between text-[9px] text-gray-700 mt-0.5">
                        <span>{t("day1")}</span><span>{t("day7")}</span>
                      </div>
                    </div>
                  )}
                </div>
              </section>

              <div className="border-t border-[#1e1e1e]" />
              <section>
                <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-3">{t("sound")}</p>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] text-gray-400">{t("soundOnImpulse")}</span>
                    <button
                      onClick={() => { setSoundEnabled(!soundEnabled); saveImpSettings({soundEnabled: !soundEnabled}); }}
                      className={`relative w-10 h-5 rounded-full transition-colors ${soundEnabled ? "bg-[#2962ff]" : "bg-[#333]"}`}
                    >
                      <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${soundEnabled ? "left-5" : "left-0.5"}`} />
                    </button>
                  </div>
                  {soundEnabled && (
                    <div>
                      <label className="block text-[11px] text-gray-500 mb-1">
                        {t("volume")} <span className="text-gray-300 font-bold">{Math.round(soundVolume * 100)}%</span>
                      </label>
                      <input type="range" min={0} max={1} step={0.05} value={soundVolume}
                        onChange={(e) => { setSoundVolume(+e.target.value); saveImpSettings({soundVolume: +e.target.value}); }}
                        className="w-full accent-[#2962ff]"
                      />
                    </div>
                  )}
                </div>
              </section>
            </div>

            <div className="px-5 py-3 border-t border-[#1e1e1e] flex justify-end">
              <button
                onClick={() => setShowSettings(false)}
                className="px-4 py-1.5 bg-[#2962ff] hover:bg-[#1e4fd8] text-white text-[12px] font-bold rounded transition-colors"
              >
                {t("done")}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
    </ChartWSProvider>
  );
}