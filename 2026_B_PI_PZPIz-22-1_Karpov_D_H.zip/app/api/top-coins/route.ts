// top-coins/route.ts

import { NextResponse } from "next/server";

export const revalidate = 60;

interface CoinData {
  symbol: string;
  volume: number;
  change: number;
  price: number;
  natr: number;   // (high - low) / close * 100
  trades: number; 
}

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
  Accept: "application/json",
};

async function fetchWithTimeout(url: string) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(url, {
      headers: HEADERS,
      signal: controller.signal,
      next: { revalidate: 60 },
    });
    clearTimeout(id);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    return await res.json();
  } catch (e) {
    clearTimeout(id);
    throw e;
  }
}


const BLOCKLIST = new Set([
  "ALPACA", "ALPHA", "BNX", "XAG", "XAU", "CL",
  "PORT3", 
]);

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const preferredExchange = (searchParams.get("exchange") ?? "BINANCE").toUpperCase();

  try {
    let rawData: any[] = [];
    let source = "NONE";

    if (preferredExchange === "BYBIT") {
      try {
        const bybitRes = await fetchWithTimeout(
          "https://api.bybit.com/v5/market/tickers?category=linear",
        );
        if (bybitRes.retCode === 0) {
          rawData = bybitRes.result.list;
          source = "BYBIT";
        }
      } catch {
        try {
          rawData = await fetchWithTimeout("https://fapi.binance.com/fapi/v1/ticker/24hr");
          source = "BINANCE";
        } catch { console.error("All exchanges failed"); }
      }
    } else if (preferredExchange === "OKX") {
      try {
        const okxRes = await fetchWithTimeout(
          "https://www.okx.com/api/v5/market/tickers?instType=SWAP",
        );
        if (okxRes.code === "0" && Array.isArray(okxRes.data)) {
          rawData = okxRes.data;
          source = "OKX";
        }
      } catch {
        try {
          rawData = await fetchWithTimeout("https://fapi.binance.com/fapi/v1/ticker/24hr");
          source = "BINANCE";
        } catch { console.error("OKX fallback failed"); }
      }
    } else {
      try {
        rawData = await fetchWithTimeout("https://fapi.binance.com/fapi/v1/ticker/24hr");
        source = "BINANCE";
      } catch {
        try {
          const bybitRes = await fetchWithTimeout(
            "https://api.bybit.com/v5/market/tickers?category=linear",
          );
          if (bybitRes.retCode === 0) {
            rawData = bybitRes.result.list;
            source = "BYBIT";
          }
        } catch { console.error("All exchanges failed"); }
      }
    }

    if (!rawData || rawData.length === 0) {
      return NextResponse.json([], { status: 200 });
    }

    let coins: CoinData[] = [];

    if (source === "BINANCE") {
      coins = rawData
        .filter((t: any) => t.symbol.endsWith("USDT") && !t.symbol.includes("_"))
        .filter((t: any) => /^[A-Z0-9]+USDT$/.test(t.symbol))
        .filter((t: any) => !/\d$/.test(t.symbol.replace("USDT", "")))
        .filter((t: any) => parseFloat(t.quoteVolume) > 50_000_000)
        .filter((t: any) => parseInt(t.count ?? "9999") > 1000)
        .filter((t: any) => Math.abs(parseFloat(t.priceChangePercent)) > 0.01)
        .filter((t: any) => !BLOCKLIST.has(t.symbol.replace("USDT", "")))
        .filter((t: any) => parseFloat(t.lastPrice) > 0)
        .map((t: any) => {
          const high = parseFloat(t.highPrice);
          const low = parseFloat(t.lowPrice);
          const close = parseFloat(t.lastPrice);
          return {
            symbol: t.symbol.replace("USDT", ""),
            volume: parseFloat(t.quoteVolume),
            change: parseFloat(t.priceChangePercent),
            price: close,
            natr: close > 0 ? ((high - low) / close) * 100 : 0,
            trades: parseInt(t.count ?? "0"),
          };
        });
    } else if (source === "BYBIT") {
      coins = rawData
        .filter((t: any) => t.symbol.endsWith("USDT") && !t.symbol.includes("_"))
        .filter((t: any) => /^[A-Z0-9]+USDT$/.test(t.symbol))
        .filter((t: any) => !/\d$/.test(t.symbol.replace("USDT", "")))
        .filter((t: any) => parseFloat(t.turnover24h) > 10_000_000) 
        .filter((t: any) => Math.abs(parseFloat(t.price24hPcnt)) > 0.0001)
        .filter((t: any) => !BLOCKLIST.has(t.symbol.replace("USDT", "")))
        .filter((t: any) => parseFloat(t.lastPrice) > 0)
        .map((t: any) => {
          const high = parseFloat(t.highPrice24h);
          const low = parseFloat(t.lowPrice24h);
          const close = parseFloat(t.lastPrice);
          return {
            symbol: t.symbol.replace("USDT", ""),
            volume: parseFloat(t.turnover24h),
            change: parseFloat(t.price24hPcnt) * 100,
            price: close,
            natr: close > 0 ? ((high - low) / close) * 100 : 0,
            trades: 0,
          };
        });
    } else if (source === "OKX") {
      coins = rawData
        .filter((t: any) => t.instId?.endsWith("-USDT-SWAP"))
        .filter((t: any) => {
          const base = t.instId.split("-")[0];
          return /^[A-Z0-9]+$/.test(base) && !/\d$/.test(base);
        })
        .filter((t: any) => parseFloat(t.volCcy24h) > 10_000_000)
        .filter((t: any) => Math.abs(parseFloat(t.sodUtc8)) > 0.0001)
        .filter((t: any) => !BLOCKLIST.has(t.instId.split("-")[0]))
        .filter((t: any) => parseFloat(t.last) > 0)
        .map((t: any) => {
          const base = t.instId.split("-")[0];
          const high = parseFloat(t.high24h);
          const low = parseFloat(t.low24h);
          const close = parseFloat(t.last);
          const open = parseFloat(t.sodUtc8);
          const changePct = open > 0 ? ((close - open) / open) * 100 : 0;
          return {
            symbol: base,
            volume: parseFloat(t.volCcy24h),
            change: changePct,
            price: close,
            natr: close > 0 ? ((high - low) / close) * 100 : 0,
            trades: 0,
          };
        });
    }

    coins.sort((a, b) => b.volume - a.volume);

    const btc = coins.find((c) => c.symbol === "BTC");
    const eth = coins.find((c) => c.symbol === "ETH");
    const others = coins.filter(
      (c) => c.symbol !== "BTC" && c.symbol !== "ETH",
    );

    const result = [btc, eth, ...others].filter(Boolean);

    return NextResponse.json(result);
  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json([], { status: 200 });
  }
}