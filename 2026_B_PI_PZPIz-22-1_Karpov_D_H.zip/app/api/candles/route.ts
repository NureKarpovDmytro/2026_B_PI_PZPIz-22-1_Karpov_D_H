// candles/route.ts

import { NextResponse } from "next/server";

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
};

let candlesCache: Map<string, { data: any; time: number }> =
  (global as any).candlesCache || ((global as any).candlesCache = new Map());
const CACHE_TTL = 3000;

let btcCache: { time: number; closes: number[] } | null = null;

async function fetchWithTimeout(url: string) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(url, {
      headers: HEADERS,
      signal: controller.signal,
    });
    clearTimeout(id);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    return await res.json();
  } catch (e) {
    clearTimeout(id);
    throw e;
  }
}

// ==================== FETCH FUNCTIONS ====================

// BINANCE FUTURES 
async function getBiF(symbol: string, interval: string, endTime?: number, limit = 1500) {
  let url = `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}USDT&interval=${interval}&limit=${Math.min(limit, 1500)}`;
  if (endTime) url += `&endTime=${endTime}`;
  return await fetchWithTimeout(url);
}

// BINANCE SPOT 
async function getBiS(symbol: string, interval: string, endTime?: number, limit = 1500) {
  let allData: any[] = [];
  let currentEndTime = endTime;
  let remaining = limit;

  while (remaining > 0) {
    const batch = Math.min(remaining, 1000);
    let url = `https://api.binance.com/api/v3/klines?symbol=${symbol}USDT&interval=${interval}&limit=${batch}`;
    if (currentEndTime) url += `&endTime=${currentEndTime}`;

    const data = await fetchWithTimeout(url);
    if (!data || data.length === 0) break;

    allData = data.concat(allData);
    remaining -= data.length;
    currentEndTime = data[0][0] - 1;

    if (data.length < batch) break;
  }
  return allData;
}

// BYBIT FUTURES 
async function getByF(symbol: string, interval: string, endTime?: number, limit = 1500) {
  const map: Record<string, string> = { "1m": "1", "5m": "5", "15m": "15", "1h": "60", "4h": "240", "1d": "D" };
  const i = map[interval] || "15";
  let allData: any[] = [];
  let currentEnd = endTime;
  let remaining = limit;

  while (remaining > 0) {
    const batch = Math.min(remaining, 200);
    let url = `https://api.bybit.com/v5/market/kline?category=linear&symbol=${symbol}USDT&interval=${i}&limit=${batch}`;
    if (currentEnd) url += `&end=${currentEnd}`;

    const json = await fetchWithTimeout(url);
    if (json.retCode !== 0) throw new Error("Bybit error");
    const list = json.result.list;
    if (!list || list.length === 0) break;

    allData = allData.concat(list);
    remaining -= list.length;
    currentEnd = parseInt(list[list.length - 1][0]) - 1;

    if (list.length < batch) break;
  }
  return allData.reverse();
}

// BYBIT SPOT 
async function getByS(symbol: string, interval: string, endTime?: number, limit = 1500) {
  const map: Record<string, string> = { "1m": "1", "5m": "5", "15m": "15", "1h": "60", "4h": "240", "1d": "D" };
  const i = map[interval] || "15";
  let allData: any[] = [];
  let currentEnd = endTime;
  let remaining = limit;

  while (remaining > 0) {
    const batch = Math.min(remaining, 200);
    let url = `https://api.bybit.com/v5/market/kline?category=spot&symbol=${symbol}USDT&interval=${i}&limit=${batch}`;
    if (currentEnd) url += `&end=${currentEnd}`;

    const json = await fetchWithTimeout(url);
    if (json.retCode !== 0) throw new Error("Bybit error");
    const list = json.result.list;
    if (!list || list.length === 0) break;

    allData = allData.concat(list);
    remaining -= list.length;
    currentEnd = parseInt(list[list.length - 1][0]) - 1;

    if (list.length < batch) break;
  }
  return allData.reverse();
}

// OKX FUTURES 
async function getOkxF(symbol: string, interval: string, endTime?: number, limit = 1500) {
  const map: Record<string, string> = { "1m": "1m", "5m": "5m", "15m": "15m", "1h": "1H", "4h": "4H", "1d": "1D" };
  const i = map[interval] || "15m";
  let allData: any[] = [];
  let currentAfter = endTime;
  let remaining = limit;

  while (remaining > 0) {
    const batch = Math.min(remaining, 300);
    let url = `https://www.okx.com/api/v5/market/candles?instId=${symbol}-USDT-SWAP&bar=${i}&limit=${batch}`;
    if (currentAfter) url += `&after=${currentAfter}`;

    const json = await fetchWithTimeout(url);
    if (json.code !== "0") throw new Error("OKX error");
    const data = json.data;
    if (!data || data.length === 0) break;

    allData = allData.concat(data);
    remaining -= data.length;
    currentAfter = parseInt(data[data.length - 1][0]);

    if (data.length < batch) break;
  }
  return allData.reverse();
}

// OKX SPOT 
async function getOkxS(symbol: string, interval: string, endTime?: number, limit = 1500) {
  const map: Record<string, string> = { "1m": "1m", "5m": "5m", "15m": "15m", "1h": "1H", "4h": "4H", "1d": "1D" };
  const i = map[interval] || "15m";
  let allData: any[] = [];
  let currentAfter = endTime;
  let remaining = limit;

  while (remaining > 0) {
    const batch = Math.min(remaining, 300);
    let url = `https://www.okx.com/api/v5/market/candles?instId=${symbol}-USDT&bar=${i}&limit=${batch}`;
    if (currentAfter) url += `&after=${currentAfter}`;

    const json = await fetchWithTimeout(url);
    if (json.code !== "0") throw new Error("OKX error");
    const data = json.data;
    if (!data || data.length === 0) break;

    allData = allData.concat(data);
    remaining -= data.length;
    currentAfter = parseInt(data[data.length - 1][0]);

    if (data.length < batch) break;
  }
  return allData.reverse();
}


function normalize(rawData: any[], source: string) {
  return rawData.map((c: any) => {
    let valueUsd = 0;

    if (source.startsWith("BI-")) {
      valueUsd = parseFloat(c[7] ?? c[5] ?? "0");
    } else if (source.startsWith("BY-")) {
      valueUsd = parseFloat(c[6] ?? c[5] ?? "0");
    } else if (source.startsWith("OKX-")) {
      valueUsd = parseFloat(c[6] ?? c[5] ?? "0");
    } else {
      valueUsd = parseFloat(c[5] ?? "0");
    }

    return {
      time: parseInt(c[0]) / 1000,
      open: parseFloat(c[1]),
      high: parseFloat(c[2]),
      low: parseFloat(c[3]),
      close: parseFloat(c[4]),
      value: valueUsd,           
      color: parseFloat(c[4]) >= parseFloat(c[1]) ? "#26a69a" : "#ef5350",
    };
  });
}

function calculateCorrelation(x: number[], y: number[]) {
  const n = Math.min(x.length, y.length);
  if (n < 2) return 0;
  const xS = x.slice(-n);
  const yS = y.slice(-n);
  const meanX = xS.reduce((a, b) => a + b) / n;
  const meanY = yS.reduce((a, b) => a + b) / n;
  const num = xS.reduce((sum, xi, i) => sum + (xi - meanX) * (yS[i] - meanY), 0);
  const denX = Math.sqrt(xS.reduce((sum, xi) => sum + Math.pow(xi - meanX, 2), 0));
  const denY = Math.sqrt(yS.reduce((sum, yi) => sum + Math.pow(yi - meanY, 2), 0));
  if (denX === 0 || denY === 0) return 0;
  return num / (denX * denY);
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get("symbol");
  const interval = searchParams.get("interval") || "15m";
  const priorityStr = searchParams.get("priority") || "BINANCE,BYBIT,OKX";
  const endTimeParam = searchParams.get("endTime");
  const endTime = endTimeParam ? parseInt(endTimeParam) : undefined;
  const limitParam = searchParams.get("limit");
  
  const candleLimit = limitParam ? Math.min(2500, Math.max(50, parseInt(limitParam))) : 300;

  if (!symbol) return NextResponse.json({ candles: [], stats: null });

  const cacheKey = `${symbol}_${interval}_${priorityStr}${endTime ? `_${endTime}` : ""}_${candleLimit}`;
  if (!endTime) {
    const cached = candlesCache.get(cacheKey);
    if (cached && Date.now() - cached.time < CACHE_TTL) {
      return NextResponse.json(cached.data);
    }
  }

  let rawData = null;
  let source = "OFFLINE";

  const priority = priorityStr.split(",").map((p) => p.trim().toUpperCase());

  const exchangeSteps = {
    BINANCE: [
      { id: "BI-F", fn: () => getBiF(symbol, interval, endTime, candleLimit) },
      { id: "BI-S", fn: () => getBiS(symbol, interval, endTime, candleLimit) },
    ],
    BYBIT: [
      { id: "BY-F", fn: () => getByF(symbol, interval, endTime, candleLimit) },
      { id: "BY-S", fn: () => getByS(symbol, interval, endTime, candleLimit) },
    ],
    OKX: [
      { id: "OKX-F", fn: () => getOkxF(symbol, interval, endTime, candleLimit) },
      { id: "OKX-S", fn: () => getOkxS(symbol, interval, endTime, candleLimit) },
    ],
  };

  const steps: { id: string; fn: () => Promise<any> }[] = [];
  for (const exch of priority) {
    if (exchangeSteps[exch as keyof typeof exchangeSteps]) {
      steps.push(...exchangeSteps[exch as keyof typeof exchangeSteps]);
    }
  }

  for (const step of steps) {
    try {
      rawData = await step.fn();
      if (Array.isArray(rawData) && rawData.length > 0) {
        source = step.id;
        break;
      }
    } catch (e) {
      continue;
    }
  }

  if (!rawData) {
    return NextResponse.json({ candles: [], source: "NODATA", stats: null });
  }

  const candles = normalize(rawData, source);

  if (endTime) {
    return NextResponse.json({ candles, source });
  }

  const last = candles[candles.length - 1];
  const len = candles.length;

  if (symbol !== "BTC") {
    const now = Date.now();
    if (!btcCache || now - btcCache.time > 60000) {
      try {
        const btcRaw = await getBiF("BTC", interval, undefined, 300);
        btcCache = {
          time: now,
          closes: btcRaw.map((c: any) => parseFloat(c[4])),
        };
      } catch (e) {}
    }
  }

  const change = ((last.close - candles[0].open) / candles[0].open) * 100;
  const high = Math.max(...candles.map((c) => c.high));
  const low = Math.min(...candles.map((c) => c.low));

  const volVal = last.value; 
  let volStr = volVal.toFixed(0);
  if (volVal > 1000000) volStr = (volVal / 1000000).toFixed(1) + "M";
  else if (volVal > 1000) volStr = (volVal / 1000).toFixed(0) + "K";

  let rangeSum = 0;
  const rangePeriod = 5;
  const startRange = Math.max(0, len - rangePeriod);
  for (let i = startRange; i < len; i++) {
    rangeSum += ((candles[i].high - candles[i].low) / candles[i].open) * 100;
  }
  const range = rangeSum / (len - startRange || 1);

  let trSum = 0;
  const atrPeriod = 14;
  const startAtr = Math.max(1, len - atrPeriod);
  for (let i = startAtr; i < len; i++) {
    const h = candles[i].high;
    const l = candles[i].low;
    const pc = candles[i - 1].close;
    const tr = Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc));
    trSum += tr;
  }
  const atr = trSum / (len - startAtr || 1);
  const natr = (atr / last.close) * 100;

  let correlation = 0;
  if (symbol === "BTC") correlation = 1;
  else if (btcCache && btcCache.closes.length > 0) {
    const coinCloses = candles.map((c) => c.close);
    correlation = calculateCorrelation(coinCloses, btcCache.closes);
  }

  const stats = {
    price: last.close,
    change,
    high,
    low,
    vol: volStr,
    range,
    natr,
    correlation,
  };

  const response = { candles, source, stats };
  candlesCache.set(cacheKey, { data: response, time: Date.now() });

  return NextResponse.json(response);
}