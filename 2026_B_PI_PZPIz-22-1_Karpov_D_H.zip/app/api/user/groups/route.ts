import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { GroupsDB } from "@/lib/db";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({});
  const groups = GroupsDB.getByUser(user.id);
  const map: Record<string, number> = {};
  groups.forEach((g) => { map[g.symbol] = g.group; });
  return NextResponse.json(map);
}

export async function POST(req: NextRequest) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Не авторизовано" }, { status: 401 });
  const groups = await req.json();
  GroupsDB.saveAll(user.id, groups);
  return NextResponse.json({ ok: true });
}
