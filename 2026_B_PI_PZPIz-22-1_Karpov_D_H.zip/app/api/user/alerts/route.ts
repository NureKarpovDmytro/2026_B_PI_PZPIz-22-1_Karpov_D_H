import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { AlertsDB } from "@/lib/db";
import { generateId } from "@/lib/auth";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json([]);
  return NextResponse.json(AlertsDB.getByUser(user.id));
}

export async function POST(req: NextRequest) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { symbol, price, direction } = await req.json();
  const alert = {
    id: generateId(),
    userId: user.id,
    symbol,
    price,
    direction,
    createdAt: new Date().toISOString(),
    triggered: false,
  };
  AlertsDB.create(alert);
  return NextResponse.json(alert);
}

export async function DELETE(req: NextRequest) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Не авторизован" }, { status: 401 });
  const { id } = await req.json();
  AlertsDB.delete(id, user.id);
  return NextResponse.json({ ok: true });
}
