// app/api/user/premium/route.ts


import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { UsersDB } from "@/lib/db";

export async function POST() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Не авторизовано" }, { status: 401 });

  UsersDB.update(user.id, { role: "premium" });

  return NextResponse.json({ ok: true, role: "premium" });
}
