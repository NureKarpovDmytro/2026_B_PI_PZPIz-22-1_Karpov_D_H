import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { UsersDB } from "@/lib/db";
import { createSession, generateId, SESSION_COOKIE, SESSION_DURATION_DAYS } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const { email, name, password } = await req.json();

    if (!email || !name || !password) {
      return NextResponse.json({ error: "Заповни всі поля" }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: "Пароль мінімум 6 символів" }, { status: 400 });
    }

    const existing = UsersDB.findByEmail(email.toLowerCase());
    if (existing) {
      return NextResponse.json({ error: "Email вже зайнятий" }, { status: 409 });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const user = {
      id: generateId(),
      email: email.toLowerCase(),
      name,
      passwordHash,
      role: "free" as const,
      createdAt: new Date().toISOString(),
    };

    UsersDB.create(user);

    const token = await createSession(user.id);

    const response = NextResponse.json({
      user: { id: user.id, email: user.email, name: user.name, role: user.role },
    });

    response.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: SESSION_DURATION_DAYS * 24 * 60 * 60,
      path: "/",
    });

    return response;
  } catch (e) {
    console.error(e);
    return NextResponse.json({ error: "Помилка сервера" }, { status: 500 });
  }
}
