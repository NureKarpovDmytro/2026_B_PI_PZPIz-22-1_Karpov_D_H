// depth/route.ts
import { NextResponse } from "next/server";

const HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
};

let depthCache: Map<string, { data: any; time: number }> =
  (global as any).depthCache || ((global as any).depthCache = new Map());
const CACHE_TTL = 3000;

async function fetchWithTimeout(url: string) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(url, {
      headers: HEADERS,
      signal: controller.signal,
    });
    clearTimeout(id);
    if (!res.ok) throw new Error(`Status ${res.status}`);
    return await res.json();
  } catch (e) {
    clearTimeout(id);
    throw e;
  }
}

// BINANCE FUTURES DEPTH
async function getBinanceDepth(symbol: string) {
  const url = `https://fapi.binance.com/fapi/v1/depth?symbol=${symbol}USDT&limit=100`;
  return await fetchWithTimeout(url);
}

// BYBIT FUTURES DEPTH
async function getBybitDepth(symbol: string) {
  const url = `https://api.bybit.com/v5/market/orderbook?category=linear&symbol=${symbol}USDT&limit=100`;
  const json = await fetchWithTimeout(url);
  if (json.retCode !== 0) throw new Error("Bybit error");
  return { bids: json.result.b, asks: json.result.a };
}

// OKX FUTURES DEPTH
async function getOkxDepth(symbol: string) {
  const url = `https://www.okx.com/api/v5/market/books?instId=${symbol}-USDT-SWAP&sz=100`;
  const json = await fetchWithTimeout(url);
  if (json.code !== "0") throw new Error("OKX error");
  const book = json.data[0];
  return { bids: book.bids, asks: book.asks };
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get("symbol");
  const priorityStr = searchParams.get("priority") || "BINANCE,BYBIT,OKX";
  const all = searchParams.get("all") === "true";

  if (!symbol) return NextResponse.json([]);

  const cacheKey = `${symbol}_${priorityStr}_${all}`;
  const cached = depthCache.get(cacheKey);
  if (cached && Date.now() - cached.time < CACHE_TTL) {
    return NextResponse.json(cached.data);
  }

  const priority = priorityStr.split(",").map((p) => p.trim().toUpperCase());

  const exchangeSteps: {
    [key: string]: { id: string; fn: () => Promise<any> };
  } = {
    BINANCE: { id: "BI-F", fn: () => getBinanceDepth(symbol) },
    BYBIT: { id: "BY-F", fn: () => getBybitDepth(symbol) },
    OKX: { id: "OKX-F", fn: () => getOkxDepth(symbol) },
  };

  let allWhales: any[] = [];

  if (all) {
    for (const exch of Object.keys(exchangeSteps)) {
      try {
        const data = await exchangeSteps[exch].fn();
        if (data && Array.isArray(data.bids) && data.bids.length > 0) {
          const findWhales = (orders: string[][], type: "BID" | "ASK") => {
            return orders
              .map(([priceStr, amountStr]) => {
                const price = parseFloat(priceStr);
                const amount = parseFloat(amountStr);
                const volumeUSD = price * amount;
                return {
                  price,
                  amount,
                  volumeUSD,
                  type,
                  exchange: exchangeSteps[exch].id,
                };
              })
              .filter((o) => o.volumeUSD > 50000)
              .sort((a, b) => b.volumeUSD - a.volumeUSD)
              .slice(0, 3);
          };

          const bids = findWhales(data.bids, "BID");
          const asks = findWhales(data.asks, "ASK");
          allWhales.push(...asks, ...bids);
        }
      } catch (e) {
        continue;
      }
    }
  } else {
    let data: { bids: string[][]; asks: string[][] } | null = null;
    let source = "NODATA";

    const steps: { id: string; fn: () => Promise<any> }[] = [];
    for (const exch of priority) {
      if (exchangeSteps[exch]) {
        steps.push(exchangeSteps[exch]);
      }
    }

    for (const step of steps) {
      try {
        data = await step.fn();
        if (data && Array.isArray(data.bids) && data.bids.length > 0) {
          source = step.id;
          break;
        }
      } catch (e) {
        continue;
      }
    }

    if (!data) return NextResponse.json([]);

    const findWhales = (orders: string[][], type: "BID" | "ASK") => {
      return orders
        .map(([priceStr, amountStr]) => {
          const price = parseFloat(priceStr);
          const amount = parseFloat(amountStr);
          const volumeUSD = price * amount;
          return { price, amount, volumeUSD, type, exchange: source };
        })
        .filter((o) => o.volumeUSD > 50000)
        .sort((a, b) => b.volumeUSD - a.volumeUSD)
        .slice(0, 3);
    };

    const bids = findWhales(data.bids, "BID");
    const asks = findWhales(data.asks, "ASK");

    allWhales = [...asks, ...bids];
  }

  depthCache.set(cacheKey, { data: allWhales, time: Date.now() });

  return NextResponse.json(allWhales);
}
