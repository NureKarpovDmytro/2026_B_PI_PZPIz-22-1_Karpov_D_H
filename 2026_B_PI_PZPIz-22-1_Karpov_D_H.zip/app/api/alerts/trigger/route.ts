// app/api/alerts/trigger/route.ts
// Клиент дёргает этот endpoint когда алерт срабатывает на экране.
// Мы находим пользователя по сессии и отправляем TG уведомление (только premium).

import { NextRequest, NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { sendTelegramMessage } from "@/lib/telegram";

export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser();

    // Не авторизован или нет Telegram — тихо игнорируем
    if (!user || !user.telegramChatId) {
      return NextResponse.json({ ok: false, reason: "no_telegram" });
    }

    // TG уведомления только для premium
    if (user.role !== "premium") {
      return NextResponse.json({ ok: false, reason: "not_premium" });
    }

    const { symbol, price, direction } = await req.json();

    const dir = direction === "up" ? "📈 вверх" : "📉 вниз";
    const priceStr =
      price < 0.01
        ? price.toFixed(6)
        : price < 1
          ? price.toFixed(4)
          : price < 100
            ? price.toFixed(2)
            : price.toFixed(0);

    const text =
      `🔔 <b>Алерт сработал!</b>\n\n` +
      `Монета: <b>${symbol}</b>\n` +
      `Цена: <b>${priceStr}</b>\n` +
      `Направление: ${dir}\n\n` +
      `<i>VTC Screen</i>`;

    const sent = await sendTelegramMessage(user.telegramChatId, text);

    return NextResponse.json({ ok: sent });
  } catch (e) {
    console.error("Alert trigger error:", e);
    return NextResponse.json({ ok: false });
  }
}
