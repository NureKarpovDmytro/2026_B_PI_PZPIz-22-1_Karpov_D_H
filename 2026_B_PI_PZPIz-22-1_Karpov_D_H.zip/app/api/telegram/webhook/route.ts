// app/api/telegram/webhook/route.ts

import { NextRequest, NextResponse } from "next/server";
import { TelegramCodesDB, UsersDB } from "@/lib/db";
import { sendTelegramMessage } from "@/lib/telegram";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const message = body?.message;
    if (!message) return NextResponse.json({ ok: true });

    const chatId = String(message.chat?.id);
    const text: string = message.text ?? "";
    const firstName: string = message.from?.first_name ?? "Test1";

    if (text.startsWith("/start")) {
      const parts = text.split(" ");
      const code = parts[1]?.trim();

      if (!code) {
        await sendTelegramMessage(
          chatId,
          `👋 Привет, ${firstName}!\n\nЯ бот <b>VTC Screen</b> — повідомляю про спрацювання цінових алертів.\n\nЩоб прив'язати обліковий запис, перейдіть до <b>Профіль → Telegram</b> у скринері та натисніть <b>Прив'язати</b>.`,
        );
        return NextResponse.json({ ok: true });
      }

      const linkEntry = TelegramCodesDB.consumeByCode(code);

      if (!linkEntry) {
        await sendTelegramMessage(
          chatId,
          `❌ Код застарілий або вже використаний.\n\nОтримай новий код у профілі скринера.`,
        );
        return NextResponse.json({ ok: true });
      }

      UsersDB.update(linkEntry.userId, { telegramChatId: chatId });

      const user = UsersDB.findById(linkEntry.userId);
      await sendTelegramMessage(
        chatId,
        `✅ <b>Telegram успішно прив'язаний!</b>\n\nАккаунт: ${user?.email ?? "—"}\nТариф: ${user?.role === "premium" ? "⭐ Premium" : "Free"}\n\n${
          user?.role === "premium"
            ? "Повідомлення про спрацювання алертів надходитимуть сюди автоматично."
            : "⚠️ Повідомлення доступні лише на тарифі <b>Premium</b>."
        }`,
      );

      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("TG webhook error:", e);
    return NextResponse.json({ ok: true });
  }
}
