// app/api/telegram/connect/route.ts


import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { TelegramCodesDB, UsersDB } from "@/lib/db";
import crypto from "crypto";

const BOT_USERNAME = process.env.NEXT_PUBLIC_TG_BOT_USERNAME ?? "vtcscreen_bot";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Не авторизовано" }, { status: 401 });

  const code = crypto.randomBytes(8).toString("hex");
  TelegramCodesDB.create(user.id, code);

  const link = `https://t.me/${BOT_USERNAME}?start=${code}`;

  return NextResponse.json({
    link,
    code,
    expiresIn: 900, 
    alreadyLinked: !!user.telegramChatId,
  });
}

export async function DELETE() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Не авторизовано" }, { status: 401 });

  UsersDB.update(user.id, { telegramChatId: undefined });
  return NextResponse.json({ ok: true });
}
