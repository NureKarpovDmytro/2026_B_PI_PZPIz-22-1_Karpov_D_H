"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error);
        return;
      }
      router.push("/");
      router.refresh();
    } catch {
      setError("Помилка з'єднання");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* */}
        <div className="text-center mb-8">
          <span className="text-2xl font-bold tracking-tighter italic text-white">
            VTC <span className="text-[#2962ff]">Screen</span>
          </span>
          <p className="text-gray-600 text-xs mt-1 font-mono uppercase tracking-widest">
            Вхід до облікового запису
          </p>
        </div>

        <div className="bg-[#0d0d0d] border border-[#1e1e1e] rounded-lg p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-1.5">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="trader@example.com"
                required
                className="w-full bg-[#111] border border-[#222] rounded px-3 py-2 text-[13px] text-gray-200 placeholder-gray-700 outline-none focus:border-[#2962ff]/60 transition-colors"
              />
            </div>

            <div>
              <label className="block text-[11px] text-gray-500 font-bold uppercase tracking-widest mb-1.5">
                Пароль
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full bg-[#111] border border-[#222] rounded px-3 py-2 text-[13px] text-gray-200 placeholder-gray-700 outline-none focus:border-[#2962ff]/60 transition-colors"
              />
            </div>

            {error && (
              <div className="bg-rose-500/10 border border-rose-500/30 rounded px-3 py-2 text-[12px] text-rose-400">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#2962ff] hover:bg-[#1e4fd8] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-[13px] py-2.5 rounded transition-colors"
            >
              {loading ? "Входим..." : "Войти"}
            </button>
          </form>

          <div className="mt-4 pt-4 border-t border-[#1e1e1e] text-center">
            <span className="text-[12px] text-gray-600">
              Немає облікового запису?{" "}
            </span>
            <Link
              href="/register"
              className="text-[12px] text-[#2962ff] hover:text-blue-400 font-bold transition-colors"
            >
              Зареєструватися
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
