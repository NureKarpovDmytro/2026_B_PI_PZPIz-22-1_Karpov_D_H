"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  Activity,
  Layers,
  Zap,
  BarChart2,
  Target,
  ChevronDown,
  X,
  Maximize2,
  Globe,
} from "lucide-react";
import { detectFormations } from "@/lib/formations";
import { useLanguage, type Language } from "@/lib/i18n";

const LOCALE_MAP: Record<Language, string> = {
  en: "en-US",
  uk: "uk-UA",
  ru: "ru-RU",
  zh: "zh-CN",
  es: "es-ES",
  pt: "pt-PT",
};

interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

type FormationType =
  | "breakout"
  | "bounce"
  | "retest"
  | "bos"
  | "consolidation"
  | "volume_spike"
  | "trend_level";

interface FormationAnnotation {
  type: "hline" | "hzone" | "trendline" | "arrow" | "label";
  color: string;
  price?: number;
  price2?: number;
  time1?: number;
  priceA?: number;
  time2?: number;
  priceB?: number;
  time?: number;
  text?: string;
  direction?: "up" | "down";
}

interface FormationResult {
  symbol: string;
  exchange: string;
  interval: string;
  type: FormationType;
  direction: "bull" | "bear" | "neutral";
  strength: 1 | 2 | 3;
  description: string;
  timestamp: number;
  candles: Candle[];
  allCandles: Candle[];
  annotations: FormationAnnotation[];
  stats?: { change: number; vol: string };
}

// ─────────────────────────────────────────────

const getFormationConfig = (
  t: any,
): Record<
  FormationType,
  {
    label: string;
    icon: React.ReactNode;
    accentColor: string;
    badgeClass: string;
  }
> => ({
  breakout: {
    label: t("formBreakout"),
    icon: <Zap size={10} />,
    accentColor: "#facc15",
    badgeClass: "text-yellow-400 border-yellow-500/30 bg-yellow-500/10",
  },
  bounce: {
    label: t("formBounce"),
    icon: <Target size={10} />,
    accentColor: "#60a5fa",
    badgeClass: "text-blue-400 border-blue-500/30 bg-blue-500/10",
  },
  retest: {
    label: t("formRetest"),
    icon: <RefreshCw size={10} />,
    accentColor: "#a78bfa",
    badgeClass: "text-violet-400 border-violet-500/30 bg-violet-500/10",
  },
  bos: {
    label: t("formBos"),
    icon: <Activity size={10} />,
    accentColor: "#f87171",
    badgeClass: "text-rose-400 border-rose-500/30 bg-rose-500/10",
  },
  consolidation: {
    label: t("formConsolidation"),
    icon: <Layers size={10} />,
    accentColor: "#22d3ee",
    badgeClass: "text-cyan-400 border-cyan-500/30 bg-cyan-500/10",
  },
  volume_spike: {
    label: t("formVolSpike"),
    icon: <BarChart2 size={10} />,
    accentColor: "#fb923c",
    badgeClass: "text-orange-400 border-orange-500/30 bg-orange-500/10",
  },
  trend_level: {
    label: t("formTrendLevel"),
    icon: <TrendingUp size={10} />,
    accentColor: "#34d399",
    badgeClass: "text-emerald-400 border-emerald-500/30 bg-emerald-500/10",
  },
});

const ALL_TYPES: FormationType[] = [
  "breakout",
  "bounce",
  "retest",
  "bos",
  "consolidation",
  "volume_spike",
  "trend_level",
];
const ALL_EXCHANGES = ["BINANCE", "BYBIT", "OKX"];
const INTERVALS = ["1m", "5m", "15m", "1h", "4h"];

// ─────────────────────────────────────────────

function MiniChart({ result }: { result: FormationResult }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container || !result.allCandles.length) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const isMacroView = result.allCandles.length > 150; 
    let startIdx = 0;

    if (isMacroView) {
      startIdx = Math.max(0, result.allCandles.length - 270);
    } else {
      let oldestTime = Infinity;
      for (const ann of result.annotations) {
        if (ann.time1 && ann.time1 < oldestTime) oldestTime = ann.time1;
        if (ann.time && ann.time < oldestTime) oldestTime = ann.time;
      }

      if (oldestTime !== Infinity) {
        startIdx = result.allCandles.findIndex((c) => c.time === oldestTime);
        if (startIdx === -1)
          startIdx = Math.max(0, result.allCandles.length - 80);
      } else {
        startIdx = Math.max(0, result.allCandles.length - 80);
      }
    }

    const safeStartIdx = Math.max(0, startIdx - 30);
    const candles = result.allCandles.slice(safeStartIdx);
    // ===================================

    const dpr = window.devicePixelRatio || 1;
    const rect = container.getBoundingClientRect();
    const W = rect.width || 280;
    const H = rect.height || 140;

    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.width = W + "px";
    canvas.style.height = H + "px";
    ctx.scale(dpr, dpr);

    const PAD = { t: 8, b: 20, l: 4, r: 50 };
    const chartW = W - PAD.l - PAD.r;
    const chartH = H - PAD.t - PAD.b;

    const hi = Math.max(...candles.map((c) => c.high));
    const lo = Math.min(...candles.map((c) => c.low));
    const pad = (hi - lo) * 0.08 || 0.0001;
    const priceMax = hi + pad;
    const priceMin = lo - pad;

    const px = (i: number) => PAD.l + (i / (candles.length - 1 || 1)) * chartW;
    const py = (p: number) =>
      PAD.t + ((priceMax - p) / (priceMax - priceMin || 0.0001)) * chartH;
    const candleW = Math.max(0.5, (chartW / candles.length) * 0.75);

    const timeToLocalIdx = (time: number): number => {
      let best = candles.length - 1;
      let bestDiff = Infinity;
      for (let i = 0; i < candles.length; i++) {
        const diff = Math.abs(candles[i].time - time);
        if (diff < bestDiff) {
          bestDiff = diff;
          best = i;
        }
      }
      return best;
    };

    ctx.fillStyle = "#0d0d0d";
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "#1a1a1a";
    ctx.lineWidth = 0.5;
    for (let i = 0; i <= 3; i++) {
      const y = PAD.t + (i / 3) * chartH;
      ctx.beginPath();
      ctx.moveTo(PAD.l, y);
      ctx.lineTo(W - PAD.r, y);
      ctx.stroke();
    }

    for (const ann of result.annotations) {
      if (ann.type === "hzone" && ann.price != null && ann.price2 != null) {
        const y1 = py(Math.max(ann.price, ann.price2));
        const y2 = py(Math.min(ann.price, ann.price2));
        ctx.fillStyle = ann.color;

        let startX = PAD.l;
        let endX = PAD.l + chartW;

        if (ann.time1 != null && ann.time2 != null) {
          startX = px(timeToLocalIdx(ann.time1));
          endX = px(timeToLocalIdx(ann.time2));
        }

        const xPos = Math.min(startX, endX);
        const width = Math.max(1, Math.abs(endX - startX));
        ctx.fillRect(xPos, y1, width, Math.max(1, y2 - y1));
      }

      if (
        ann.type === "trendline" &&
        ann.time1 != null &&
        ann.priceA != null &&
        ann.time2 != null &&
        ann.priceB != null
      ) {
        const li1 = timeToLocalIdx(ann.time1);
        const li2 = timeToLocalIdx(ann.time2);
        ctx.strokeStyle = ann.color;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(px(li1), py(ann.priceA));
        ctx.lineTo(px(li2), py(ann.priceB));
        ctx.stroke();
      }
    }

    for (let i = 0; i < candles.length; i++) {
      const c = candles[i];
      const x = px(i);
      const isUp = c.close >= c.open;
      const col = isUp ? "#26a69a" : "#ef5350";
      const bTop = py(Math.max(c.open, c.close));
      const bBot = py(Math.min(c.open, c.close));
      const bH = Math.max(1, bBot - bTop);
      ctx.strokeStyle = col;
      ctx.lineWidth = 1;
      ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(x, py(c.high));
      ctx.lineTo(x, py(c.low));
      ctx.stroke();
      ctx.fillStyle = col;
      ctx.fillRect(x - candleW / 2, bTop, candleW, bH);
    }

    ctx.font = "bold 9px 'JetBrains Mono', monospace";
    for (const ann of result.annotations) {
      if (ann.type === "hline" && ann.price != null) {
        const y = py(ann.price);
        if (y < -2 || y > H + 2) continue;

        let startX = PAD.l;
        let endX = W - PAD.r;

        if (ann.time1 != null && ann.time2 != null) {
          startX = px(timeToLocalIdx(ann.time1));
          endX = px(timeToLocalIdx(ann.time2));
        }

        ctx.strokeStyle = ann.color;
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 3]);
        ctx.beginPath();
        ctx.moveTo(startX, y);
        ctx.lineTo(endX, y);
        ctx.stroke();
        ctx.setLineDash([]);

        const lbl =
          ann.price < 0.0001
            ? ann.price.toFixed(8)
            : ann.price < 0.01
              ? ann.price.toFixed(6)
              : ann.price < 1
                ? ann.price.toFixed(4)
                : ann.price < 100
                  ? ann.price.toFixed(2)
                  : ann.price.toFixed(0);
        ctx.fillStyle = ann.color;
        ctx.textAlign = "left";
        ctx.fillText(lbl, W - PAD.r + 3, y + 3);
      }

      if (ann.type === "arrow" && ann.time != null) {
        const li = timeToLocalIdx(ann.time);
        const c = candles[li];
        const x = px(li);
        const isUp = ann.direction === "up";
        const baseY = isUp ? py(c.low) + 8 : py(c.high) - 8;
        const tipY = isUp ? baseY - 10 : baseY + 10;
        ctx.fillStyle = ann.color;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(x, tipY);
        ctx.lineTo(x - 5, baseY);
        ctx.lineTo(x + 5, baseY);
        ctx.closePath();
        ctx.fill();
      }
    }

    ctx.fillStyle = "#444";
    ctx.font = "8px monospace";
    ctx.textAlign = "center";
    ctx.setLineDash([]);
    const fmt = (ts: number) => {
      const d = new Date(ts * 1000);
      return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
    };
    if (candles.length > 1) {
      ctx.fillText(fmt(candles[0].time), PAD.l + 14, H - 5);
      ctx.fillText(
        fmt(candles[candles.length - 1].time),
        W - PAD.r - 14,
        H - 5,
      );
    }
  }, [result]);

  return (
    <div ref={containerRef} className="w-full h-full">
      <canvas
        ref={canvasRef}
        style={{ display: "block", width: "100%", height: "100% " }}
      />
    </div>
  );
}

// ─────────────────────────────────────────────
//  КОМПОНЕНТ КАРТИ
// ─────────────────────────────────────────────
function FormationCard({
  result,
  onOpenFocus,
}: {
  result: FormationResult;
  onOpenFocus: () => void;
}) {
  const [isMacro, setIsMacro] = useState(false);
  const { t } = useLanguage();
  const config = getFormationConfig(t);
  const cfg = config[result.type];

  const displayResult = {
    ...result,
    allCandles: isMacro ? result.allCandles : result.allCandles.slice(-80),
  };

  return (
    <div
      className={`bg-[#0d0d0d] border ${isMacro ? "border-[#2962ff]" : "border-[#1e1e1e]"} rounded-lg overflow-hidden hover:border-[#2962ff]/50 transition-all group flex flex-col cursor-pointer relative`}
      onClick={() => setIsMacro(!isMacro)}
    >
      <div className="h-[140px] w-full bg-[#0a0a0a] relative pointer-events-none">
        <MiniChart result={displayResult} />
        {isMacro && (
          <div className="absolute top-2 right-2 bg-[#2962ff]/20 border border-[#2962ff]/50 text-[#2962ff] text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider backdrop-blur-sm">
            MACRO
          </div>
        )}
      </div>

      <div className="p-2.5">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <span className="text-[14px] font-black text-white">
              {result.symbol}
            </span>
            {result.stats && (
              <span
                className={`text-[10px] font-bold font-mono ${result.stats.change >= 0 ? "text-emerald-400" : "text-rose-400"}`}
              >
                {result.stats.change > 0 ? "+" : ""}
                {result.stats.change.toFixed(2)}%
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onOpenFocus();
              }}
              className="p-1 text-gray-600 hover:text-white hover:bg-[#222] rounded transition-colors"
              title={t("openDetail")}
            >
              <Maximize2 size={12} />
            </button>
            <div className="flex items-center gap-1">
              <span className="text-[9px] text-amber-400">
                {"★".repeat(result.strength)}
                {"☆".repeat(3 - result.strength)}
              </span>
              {result.direction === "bull" && (
                <TrendingUp size={10} className="text-emerald-400" />
              )}
              {result.direction === "bear" && (
                <TrendingDown size={10} className="text-rose-400" />
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 mb-1">
          <span
            className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded border text-[9px] font-bold ${cfg.badgeClass}`}
          >
            {cfg.icon}
            {cfg.label}
          </span>
          <span className="text-[9px] text-gray-700 font-mono">
            {result.interval.toUpperCase()}
          </span>
        </div>

        <p className="text-[10px] text-gray-500 leading-snug mb-1.5">
          {result.description}
        </p>

        <div className="flex items-center justify-between">
          <span className="text-[9px] text-gray-700 font-mono">
            {result.exchange}
          </span>
          {result.stats && (
            <span className="text-[9px] text-gray-600 font-mono">
              Vol: {result.stats.vol}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
//  ФОКУС-МОД
// ─────────────────────────────────────────────
function FocusModal({
  result,
  onClose,
}: {
  result: FormationResult;
  onClose: () => void;
}) {
  const { t } = useLanguage();
  const config = getFormationConfig(t);
  const cfg = config[result.type];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#0d0d0d] border border-[#2a2a2a] rounded-xl overflow-hidden w-full max-w-4xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#1e1e1e]">
          <div className="flex items-center gap-3">
            <span className="text-[18px] font-black text-white">
              {result.symbol}
            </span>
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[10px] font-bold ${cfg.badgeClass}`}
            >
              {cfg.icon}
              {cfg.label}
            </span>
            <span className="text-[10px] text-gray-600 font-mono">
              {result.interval.toUpperCase()}
            </span>
            <span className="text-[10px] text-gray-600 font-mono">
              {result.exchange}
            </span>
            <span className="text-[11px] text-amber-400">
              {"★".repeat(result.strength)}
              {"☆".repeat(3 - result.strength)}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-500 hover:text-white hover:bg-[#222] rounded transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="h-[460px] w-full bg-[#0a0a0a]">
          <MiniChart result={result} />
        </div>

        <div className="px-4 py-3 border-t border-[#1e1e1e]">
          <p className="text-[12px] text-gray-400">{result.description}</p>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
//  Сторінка
// ─────────────────────────────────────────────
export default function FormationsPage() {
  const router = useRouter();
  const { t, lang, setLang } = useLanguage();

  const [results, setResults] = useState<FormationResult[]>([]);
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [enabledTypes, setEnabledTypes] = useState<Set<FormationType>>(
    new Set(["breakout"]),
  );
  const [filterDir, setFilterDir] = useState<"all" | "bull" | "bear">("all");
  const [filterStr, setFilterStr] = useState<0 | 1 | 2 | 3>(0);
  const [selectedIntervals, setSelectedIntervals] = useState<Set<string>>(
    new Set(["15m"]),
  );
  const [selectedExchanges, setSelectedExchanges] = useState<Set<string>>(
    new Set(["BINANCE", "BYBIT", "OKX"]),
  );
  const [lastScanned, setLastScanned] = useState<string | null>(null);
  const [focusResult, setFocusResult] = useState<FormationResult | null>(null);
  const abortRef = useRef(false);

  const [minVolumeFilter, setMinVolumeFilter] = useState<number>(0);
  const [priceChangeFilter, setPriceChangeFilter] = useState<
    "all" | "up" | "down"
  >("all");
  const [sortBy, setSortBy] = useState<
    "strength" | "change_up" | "change_down" | "volume"
  >("strength");

  const config = getFormationConfig(t);

  const toggleLanguage = () => {
    const langs: ("en" | "uk" | "ru" | "zh" | "es" | "pt")[] = [
      "en",
      "uk",
      "ru",
      "zh",
      "es",
      "pt",
    ];
    const nextIdx = (langs.indexOf(lang) + 1) % langs.length;
    setLang(langs[nextIdx]);
  };

  const toggleType = (t: FormationType) =>
    setEnabledTypes((prev) => {
      const n = new Set(prev);
      n.has(t) ? n.delete(t) : n.add(t);
      return n;
    });
  const toggleInterval = (iv: string) =>
    setSelectedIntervals((prev) => {
      const n = new Set(prev);
      n.has(iv) ? n.delete(iv) : n.add(iv);
      return n;
    });
  const toggleExchange = (ex: string) =>
    setSelectedExchanges((prev) => {
      const n = new Set(prev);
      n.has(ex) ? n.delete(ex) : n.add(ex);
      return n;
    });

  const scan = useCallback(async () => {
    setScanning(true);
    setResults([]);
    abortRef.current = false;

    const coinLists = await Promise.allSettled(
      Array.from(selectedExchanges).map((ex: string) =>
        fetch(`/api/top-coins?exchange=${ex}`)
          .then((r) => r.json())
          .then((d) => ({ ex, coins: Array.isArray(d) ? d : [] })),
      ),
    );

    type Task = {
      symbol: string;
      exchange: string;
      interval: string;
      volume: number;
    };
    const bestExchange = new Map<
      string,
      { exchange: string; volume: number }
    >();

    for (const res of coinLists) {
      if (res.status !== "fulfilled") continue;
      const { ex, coins } = res.value;
      for (const coin of coins as any[]) {
        const key = coin.symbol;
        const vol = coin.volume ?? 0;
        const cur = bestExchange.get(key);
        if (!cur || vol > cur.volume)
          bestExchange.set(key, { exchange: ex, volume: vol });
      }
    }

    const tasks: Task[] = [];
    for (const [symbol, { exchange, volume }] of bestExchange) {
      for (const iv of selectedIntervals) {
        tasks.push({ symbol, exchange, interval: iv, volume });
      }
    }

    tasks.sort((a, b) => b.volume - a.volume);

    setProgress({ done: 0, total: tasks.length });
    const allResults: FormationResult[] = [];

    const BATCH = 8;
    for (let i = 0; i < tasks.length; i += BATCH) {
      if (abortRef.current) break;
      const batch = tasks.slice(i, i + BATCH);

      await Promise.allSettled(
        batch.map(async ({ symbol, exchange, interval }) => {
          try {
            const priority =
              exchange === "BYBIT"
                ? "BYBIT"
                : exchange === "OKX"
                  ? "OKX"
                  : "BINANCE";

            const r = await fetch(
              `/api/candles?symbol=${symbol}&interval=${interval}&priority=${priority}&limit=1500`,
            );
            const data = await r.json();
            if (!data.candles?.length) return;

            const candles: Candle[] = data.candles.map((c: any) => ({
              time: parseFloat(c.time),
              open: parseFloat(c.open),
              high: parseFloat(c.high),
              low: parseFloat(c.low),
              close: parseFloat(c.close),
              volume: parseFloat(c.value ?? c.volume ?? 0),
            }));

            const found = detectFormations(
              candles,
              symbol,
              `${exchange.slice(0, 2)}-F`,
              interval,
              Array.from(enabledTypes),
              lang,
            );

            if (found.length) {
              const enriched = found.map((f) => ({ ...f, stats: data.stats }));
              allResults.push(...enriched);
              setResults([...allResults]);
            }
          } catch {}
        }),
      );

      setProgress({
        done: Math.min(i + BATCH, tasks.length),
        total: tasks.length,
      });
      await new Promise((r) => setTimeout(r, 40));
    }

    const deduped = new Map<string, FormationResult>();
    for (const r of allResults) {
      const key = `${r.symbol}:${r.type}:${r.interval}:${r.direction}`;
      const existing = deduped.get(key);
      if (
        !existing ||
        r.strength > existing.strength ||
        (r.strength === existing.strength &&
          (r.stats?.change ?? 0) > (existing.stats?.change ?? 0))
      ) {
        deduped.set(key, r);
      }
    }
    const finalResults = Array.from(deduped.values());

    setResults(finalResults);
    setLastScanned(new Date().toLocaleTimeString(LOCALE_MAP[lang]));
    setScanning(false);
    setProgress({ done: 0, total: 0 });
  }, [selectedIntervals, selectedExchanges, enabledTypes, lang]);

  useEffect(() => {
    scan();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = results.filter((r) => {
    if (!enabledTypes.has(r.type)) return false;
    if (filterDir !== "all" && r.direction !== filterDir) return false;
    if (filterStr !== 0 && r.strength < filterStr) return false;

    if (r.stats) {
      if (priceChangeFilter === "up" && r.stats.change < 0) return false;
      if (priceChangeFilter === "down" && r.stats.change > 0) return false;

      if (minVolumeFilter > 0) {
        const volStr = r.stats.vol;
        let vol = 0;
        if (volStr.endsWith("M")) vol = parseFloat(volStr) * 1000000;
        else if (volStr.endsWith("K")) vol = parseFloat(volStr) * 1000;
        else vol = parseFloat(volStr);

        if (vol < minVolumeFilter * 1000000) return false;
      }
    }
    return true;
  });

  const pct =
    progress.total > 0 ? Math.round((progress.done / progress.total) * 100) : 0;

  return (
    <div className="h-screen bg-[#050505] text-white font-sans flex flex-col overflow-hidden">
      {focusResult && (
        <FocusModal result={focusResult} onClose={() => setFocusResult(null)} />
      )}

      <header className="h-12 border-b border-[#1e1e1e] bg-[#0a0a0a] flex items-center px-4 gap-3 shrink-0">
        <button
          onClick={() => router.push("/")}
          className="flex items-center gap-1.5 text-gray-500 hover:text-white transition-colors"
        >
          <ArrowLeft size={14} />
          <span className="text-xl font-bold tracking-tighter italic text-white">
            VTC <span className="text-[#2962ff]">Screen</span>
          </span>
        </button>
        <span className="text-gray-700">/</span>
        <span className="text-[13px] font-bold text-gray-300 flex items-center gap-1.5">
          <BarChart2 size={13} className="text-[#2962ff]" />{" "}
          {t("formationsScanner")}
        </span>

        <div className="ml-auto flex items-center gap-2">
          {/*  */}
          <button
            onClick={toggleLanguage}
            title="Change Language"
            className="flex items-center gap-1 p-2 rounded-md transition-all hover:bg-[#1e1e1e] hover:text-white text-gray-500 mr-2"
          >
            <Globe size={16} />
            <span className="text-[10px] font-bold">{lang.toUpperCase()}</span>
          </button>

          <div className="flex gap-1">
            {INTERVALS.map((iv) => (
              <button
                key={iv}
                onClick={() => toggleInterval(iv)}
                className={`text-[10px] px-2 py-1 rounded font-bold transition-all ${
                  selectedIntervals.has(iv)
                    ? "bg-[#2962ff] text-white"
                    : "bg-[#111] border border-[#222] text-gray-500 hover:text-gray-300"
                }`}
              >
                {iv.toUpperCase()}
              </button>
            ))}
          </div>
          <button
            onClick={
              scanning
                ? () => {
                    abortRef.current = true;
                  }
                : scan
            }
            className={`flex items-center gap-2 px-4 py-1.5 rounded font-bold text-[12px] transition-all ${
              scanning
                ? "bg-rose-500/20 border border-rose-500/40 text-rose-400"
                : "bg-[#2962ff] hover:bg-[#1e4fd8] text-white"
            }`}
          >
            <RefreshCw size={12} className={scanning ? "animate-spin" : ""} />
            {scanning ? `${t("stop")} (${pct}%)` : t("rescan")}
          </button>
        </div>
      </header>

      {scanning && (
        <div className="h-0.5 bg-[#1e1e1e]">
          <div
            className="h-full bg-[#2962ff] transition-all duration-300"
            style={{ width: `${pct}%` }}
          />
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        <aside className="w-52 shrink-0 border-r border-[#1e1e1e] bg-[#0a0a0a] overflow-y-auto p-3 flex flex-col gap-4">
          <div>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-2">
              {t("exchanges")}
            </p>
            <div className="flex gap-1">
              {ALL_EXCHANGES.map((ex) => (
                <button
                  key={ex}
                  onClick={() => toggleExchange(ex)}
                  className={`flex-1 py-1 rounded text-[10px] font-bold transition-all ${selectedExchanges.has(ex) ? "bg-[#2962ff] text-white" : "bg-[#111] text-gray-500 hover:text-gray-300"}`}
                >
                  {ex}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-2">
              {t("minVol24h")}
            </p>
            <div className="flex gap-1 mb-2">
              {[0, 10, 50, 100].map((val) => (
                <button
                  key={val}
                  onClick={() => setMinVolumeFilter(val)}
                  className={`flex-1 py-1 rounded text-[10px] font-bold transition-all ${minVolumeFilter === val ? "bg-[#2962ff] text-white" : "bg-[#111] text-gray-500 hover:text-gray-300"}`}
                >
                  {val === 0 ? t("all") : `>${val}M`}
                </button>
              ))}
            </div>
            <input
              type="range"
              min={0}
              max={500}
              step={10}
              value={minVolumeFilter}
              onChange={(e) => setMinVolumeFilter(Number(e.target.value))}
              className="w-full h-1 accent-[#2962ff] cursor-pointer"
            />
            <div className="flex justify-between text-[8px] text-gray-700 mt-0.5 font-mono">
              <span>0</span>
              <span className="text-gray-400 font-bold">
                {minVolumeFilter > 0 ? `>${minVolumeFilter}M` : t("all")}
              </span>
              <span>500M</span>
            </div>
          </div>

          <div>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-2">
              {t("priceTrend24h")}
            </p>
            <div className="flex gap-1 mb-2">
              {(["all", "up", "down"] as const).map((v) => (
                <button
                  key={v}
                  onClick={() => setPriceChangeFilter(v)}
                  className={`flex-1 py-1 rounded text-[10px] font-bold transition-all ${priceChangeFilter === v ? "bg-[#2962ff] text-white" : "bg-[#111] text-gray-500 hover:text-gray-300"}`}
                >
                  {v === "all" ? t("any") : v === "up" ? "> 0%" : "< 0%"}
                </button>
              ))}
            </div>
          </div>

          <div className="w-full h-px bg-[#1e1e1e] my-1" />

          <div>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-2">
              {t("formations")}
            </p>
            <div className="space-y-0.5">
              {ALL_TYPES.map((tKey) => {
                const cfg = config[tKey];
                const cnt = filtered.filter((r) => r.type === tKey).length;
                const on = enabledTypes.has(tKey);
                return (
                  <button
                    key={tKey}
                    onClick={() => toggleType(tKey)}
                    className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-left transition-all ${on ? "bg-[#1a1a1a] border border-[#2a2a2a]" : "opacity-40 hover:opacity-60"}`}
                  >
                    <span
                      className={
                        on ? cfg.badgeClass.split(" ")[0] : "text-gray-600"
                      }
                    >
                      {cfg.icon}
                    </span>
                    <span className="text-[11px] text-gray-300 flex-1 leading-tight">
                      {cfg.label}
                    </span>
                    {cnt > 0 && (
                      <span className="text-[9px] bg-[#2962ff]/20 text-[#2962ff] px-1 rounded font-bold">
                        {cnt}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-2">
              {t("minStrength")}
            </p>
            <div className="flex gap-1">
              {([0, 1, 2, 3] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => setFilterStr(s)}
                  className={`flex-1 py-1 rounded text-[10px] font-bold transition-all ${filterStr === s ? "bg-[#2962ff] text-white" : "bg-[#111] text-gray-500 hover:text-gray-300"}`}
                >
                  {s === 0 ? t("all") : "★".repeat(s)}
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="text-[10px] font-black text-gray-600 uppercase tracking-widest mb-2">
              {t("sorting")}
            </p>
            <div className="space-y-0.5">
              {(
                [
                  { key: "strength", label: t("byStrength"), icon: "★" },
                  { key: "volume", label: t("byVolume"), icon: "↑$" },
                  { key: "change_up", label: t("topGainers"), icon: "▲" },
                  { key: "change_down", label: t("topLosers"), icon: "▼" },
                ] as const
              ).map(({ key, label, icon }) => (
                <button
                  key={key}
                  onClick={() => setSortBy(key)}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-left transition-all text-[11px] font-bold ${sortBy === key ? "bg-[#2962ff] text-white" : "text-gray-500 hover:text-gray-300 bg-[#111]"}`}
                >
                  <span className="font-mono text-[10px] w-4 text-center">
                    {icon}
                  </span>
                  {label}
                </button>
              ))}
            </div>
          </div>
        </aside>

        <main className="flex-1 overflow-y-auto p-3">
          {!scanning && results.length === 0 && (
            <div className="flex flex-col items-center justify-center h-80 gap-3 text-center">
              <BarChart2 size={40} className="text-gray-800" />
              <div className="text-gray-600 text-[13px] font-bold">
                {t("clickRescan")}
              </div>
            </div>
          )}

          {filtered.length > 0 && (
            <div className="flex items-center gap-3 mb-3">
              <span className="text-[12px] text-gray-400 font-bold">
                {t("found")}{" "}
                <span className="text-white">{filtered.length}</span>
                {results.length !== filtered.length && (
                  <span className="text-gray-600 ml-1">
                    {t("outOf", { total: results.length })}
                  </span>
                )}
              </span>
              {ALL_EXCHANGES.map((ex) => {
                const cnt = filtered.filter((r) =>
                  r.exchange.startsWith(ex.slice(0, 2)),
                ).length;
                return cnt > 0 ? (
                  <span
                    key={ex}
                    className="text-[9px] bg-[#1e1e1e] text-gray-500 border border-[#2a2a2a] px-1.5 py-0.5 rounded font-mono"
                  >
                    {ex.slice(0, 2)}: {cnt}
                  </span>
                ) : null;
              })}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2">
            {filtered
              .sort((a, b) => {
                const volNum = (s?: string) => {
                  if (!s) return 0;
                  if (s.endsWith("M")) return parseFloat(s) * 1e6;
                  if (s.endsWith("K")) return parseFloat(s) * 1e3;
                  return parseFloat(s) || 0;
                };
                if (sortBy === "strength")
                  return b.strength - a.strength || b.timestamp - a.timestamp;
                if (sortBy === "volume")
                  return volNum(b.stats?.vol) - volNum(a.stats?.vol);
                if (sortBy === "change_up")
                  return (b.stats?.change ?? 0) - (a.stats?.change ?? 0);
                if (sortBy === "change_down")
                  return (a.stats?.change ?? 0) - (b.stats?.change ?? 0);
                return 0;
              })
              .map((r, i) => (
                <FormationCard
                  key={`${r.symbol}-${r.type}-${r.interval}-${i}`}
                  result={r}
                  onOpenFocus={() => setFocusResult(r)}
                />
              ))}
          </div>
        </main>
      </div>
    </div>
  );
}
