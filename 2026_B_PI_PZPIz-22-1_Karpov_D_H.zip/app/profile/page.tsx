"use client";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  UserCircle,
  LogOut,
  Crown,
  Link,
  Unlink,
  Copy,
  CheckCheck,
  ExternalLink,
  ArrowLeft,
} from "lucide-react";

interface UserData {
  id: string;
  email: string;
  name: string;
  role: "free" | "premium";
  telegramChatId?: string;
}

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  // TG linking state
  const [tgLink, setTgLink] = useState<string | null>(null);
  const [tgLoading, setTgLoading] = useState(false);
  const [tgCopied, setTgCopied] = useState(false);
  const [tgExpiry, setTgExpiry] = useState<number>(0);
  const [tgLinked, setTgLinked] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (!d.user) {
          router.push("/login");
          return;
        }
        setUser(d.user);
        setTgLinked(!!d.user.telegramChatId);
      })
      .finally(() => setLoading(false));
  }, [router]);

  useEffect(() => {
    if (tgExpiry <= 0) return;
    const t = setInterval(() => setTgExpiry((v) => Math.max(0, v - 1)), 1000);
    return () => clearInterval(t);
  }, [tgExpiry]);

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  };

  const handleGetTgLink = async () => {
    setTgLoading(true);
    try {
      const r = await fetch("/api/telegram/connect");
      const d = await r.json();
      if (d.link) {
        setTgLink(d.link);
        setTgExpiry(d.expiresIn ?? 900);
      }
    } catch {}
    setTgLoading(false);
  };

  const handleUnlinkTg = async () => {
    await fetch("/api/telegram/connect", { method: "DELETE" });
    setTgLinked(false);
    setTgLink(null);
    setUser((u) => (u ? { ...u, telegramChatId: undefined } : u));
  };

  const handleCopyLink = () => {
    if (!tgLink) return;
    navigator.clipboard.writeText(tgLink);
    setTgCopied(true);
    setTimeout(() => setTgCopied(false), 2000);
  };

  useEffect(() => {
    if (!tgLink || tgLinked) return;
    const interval = setInterval(async () => {
      const r = await fetch("/api/auth/me");
      const d = await r.json();
      if (d.user?.telegramChatId) {
        setTgLinked(true);
        setUser(d.user);
        setTgLink(null);
        clearInterval(interval);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [tgLink, tgLinked]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-[#2962ff] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return null;

  const isPremium = user.role === "premium";

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans">
      <div className="max-w-lg mx-auto px-4 py-8">
        {/* */}
        <button
          onClick={() => router.push("/")}
          className="flex items-center gap-2 text-gray-500 hover:text-white text-[13px] mb-6 transition-colors"
        >
          <ArrowLeft size={14} />
          Скринер
        </button>

        {/**/}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-14 h-14 rounded-full bg-[#111] border border-[#2a2a2a] flex items-center justify-center">
            <UserCircle size={32} className="text-gray-500" />
          </div>
          <div>
            <div className="text-[18px] font-black text-white">{user.name}</div>
            <div className="text-[12px] text-gray-500">{user.email}</div>
          </div>
          <div className="ml-auto">
            {isPremium ? (
              <span className="flex items-center gap-1.5 bg-amber-500/15 border border-amber-500/30 text-amber-400 text-[11px] font-black px-3 py-1 rounded-full">
                <Crown size={11} />
                Premium
              </span>
            ) : (
              <span className="text-[11px] text-gray-600 border border-[#222] px-3 py-1 rounded-full">
                Free
              </span>
            )}
          </div>
        </div>

        {/* */}
        <section className="bg-[#0d0d0d] border border-[#1e1e1e] rounded-xl p-5 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-[13px] font-black text-white">
                Telegram повідомлення
              </p>
              <p className="text-[11px] text-gray-600 mt-0.5">
                {isPremium
                  ? "Алерты приходят мгновенно в Telegram"
                  : "Доступно на тарифе Premium"}
              </p>
            </div>
            {!isPremium && (
              <span className="text-[9px] bg-amber-500/15 text-amber-500 border border-amber-500/30 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
                Premium
              </span>
            )}
          </div>

          {tgLinked ? (
            <div className="flex items-center justify-between bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-4 py-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[12px] text-emerald-400 font-bold">
                  Прив'язан
                </span>
              </div>
              <button
                onClick={handleUnlinkTg}
                className="flex items-center gap-1.5 text-[11px] text-gray-600 hover:text-rose-400 transition-colors"
              >
                <Unlink size={12} />
                Відв'язати
              </button>
            </div>
          ) : tgLink ? (
            <div className="space-y-3">
              <div className="bg-[#111] border border-[#2a2a2a] rounded-lg p-3">
                <p className="text-[11px] text-gray-400 mb-2">
                  1. Натисніть кнопку нижче або скопіюй посилання
                </p>
                <p className="text-[11px] text-gray-400 mb-3">
                  2. В Telegram натисни <b className="text-white">Start</b> —
                  бот підтвердить прив'язку
                </p>
                <div className="flex gap-2">
                  <a
                    href={tgLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 bg-[#229ED9] hover:bg-[#1a8bbf] text-white text-[12px] font-bold py-2 rounded-lg transition-colors"
                  >
                    <ExternalLink size={13} />
                    Відкрити в Telegram
                  </a>
                  <button
                    onClick={handleCopyLink}
                    className="flex items-center gap-1.5 bg-[#1a1a1a] hover:bg-[#222] border border-[#2a2a2a] text-gray-400 hover:text-white text-[12px] px-3 rounded-lg transition-colors"
                  >
                    {tgCopied ? (
                      <CheckCheck size={13} className="text-emerald-400" />
                    ) : (
                      <Copy size={13} />
                    )}
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <div className="flex items-center gap-1.5 text-gray-600">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                  Чекаю на прив'язку...
                </div>
                <span className="text-gray-700 font-mono">
                  {tgExpiry > 0
                    ? `${Math.floor(tgExpiry / 60)}:${String(tgExpiry % 60).padStart(2, "0")}`
                    : "Час вичерпано"}
                </span>
              </div>
            </div>
          ) : (
            <button
              onClick={handleGetTgLink}
              disabled={tgLoading}
              className="w-full flex items-center justify-center gap-2 bg-[#111] hover:bg-[#161616] border border-[#2a2a2a] hover:border-[#3a3a3a] text-[13px] font-bold text-gray-300 py-2.5 rounded-lg transition-all disabled:opacity-50"
            >
              <Link size={14} />
              {tgLoading ? "Генерую посилання..." : "Прив'язати Telegram"}
            </button>
          )}
        </section>

        {/*  */}
        {!isPremium && (
          <section className="bg-gradient-to-br from-amber-950/30 to-[#0d0d0d] border border-amber-500/20 rounded-xl p-5 mb-4">
            <div className="flex items-center gap-2 mb-3">
              <Crown size={14} className="text-amber-400" />
              <p className="text-[13px] font-black text-amber-400">Premium</p>
            </div>
            <p className="text-[12px] text-gray-400 mb-4 leading-relaxed">
              Миттєві Telegram повідомлення про алерти. Повідомлення приходять
              протягом секунди після перетину ціни.
            </p>
            <button
              onClick={async () => {
                await fetch("/api/user/premium", { method: "POST" });
                const r = await fetch("/api/auth/me");
                const d = await r.json();
                if (d.user) setUser(d.user);
              }}
              className="w-full bg-amber-500 hover:bg-amber-400 text-black text-[13px] font-black py-2.5 rounded-lg transition-colors"
            >
              Активувати Premium
            </button>
          </section>
        )}

        {/* */}
        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 text-gray-600 hover:text-rose-400 text-[13px] py-3 transition-colors"
        >
          <LogOut size={14} />
          Вийти
        </button>
      </div>
    </div>
  );
}
